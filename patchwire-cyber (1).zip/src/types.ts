export enum PaymentStatus {
  PENDING = "Pending",
  APPROVED = "Approved",
  REJECTED = "Rejected"
}

export enum TrackDifficulty {
  BEGINNER = "Beginner",
  INTERMEDIATE = "Intermediate",
  ADVANCED = "Advanced",
  EXPERT = "Expert"
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  role: "admin" | "student";
  createdAt: string;
  xp: number;
}

export interface Lesson {
  id: string;
  title: string;
  type: "video" | "lab" | "pdf" | "quiz";
  duration: string;
  contentUrl?: string; // Mock or real link for video/pdf
  labDescription?: string;
  labInstructions?: string;
  quizQuestions?: QuizQuestion[];
  isLocked?: boolean;
  isFree?: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface Module {
  id: string;
  title: string;
  description: string;
  lessons: Lesson[];
}

export interface CourseTrack {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  price: number; // In INR (₹)
  difficulty: TrackDifficulty;
  duration: string; // e.g. "8 Weeks"
  skills: string[];
  modules: Module[];
  careerOutcomes: string[];
  bannerImage: string;
  enrolledCount: number;
}

export interface Progress {
  userId: string;
  trackId: string;
  completedLessons: string[]; // List of completed lesson IDs
  lastAccessed: string;
  quizScores: { [lessonId: string]: number }; // Score percentage
}

export interface Certificate {
  id: string; // Unique Certificate ID, e.g. PWC-2026-XXXX
  userId: string;
  userName: string;
  trackId: string;
  trackTitle: string;
  issueDate: string;
  qrCodeUrl: string; // Dynamic verification URL representation
  assessmentScores?: { [lessonTitle: string]: number }; // Dynamic record of final assessment quiz titles and their scores
}

export interface PaymentRecord {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  trackId: string;
  trackTitle: string;
  amount: number;
  utr: string; // UPI Transaction Reference ID
  screenshotUrl: string; // Base64 or mock image url
  status: PaymentStatus;
  createdAt: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  iconName: string;
  unlockedAt?: string;
}

export interface NotificationRecord {
  id: string;
  userId: string; // "all" for general announcements
  title: string;
  message: string;
  type: "info" | "success" | "warning" | "alert";
  isRead: boolean;
  createdAt: string;
}

export interface LeaderboardEntry {
  userId: string;
  userName: string;
  avatarUrl?: string;
  xp: number;
  labsCompleted: number;
  badgesCount: number;
  rank?: number;
}

export interface ForumPost {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  avatarUrl?: string;
  channel: string; // e.g. "#general-discussion", "#lab-help"
  title: string;
  content: string;
  upvotes: number;
  replies: ForumReply[];
  createdAt: string;
}

export interface ForumReply {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  avatarUrl?: string;
  content: string;
  createdAt: string;
}

export interface AccessCode {
  id: string;
  code: string;
  trackId: string; // Course Track ID or Bundle ID, e.g., "soc-basics", or "ultimate-pack", or "all"
  status: "active" | "disabled";
  usedBy?: string; // User ID of the student who claimed it
  usedAt?: string; // Timestamp when used
  createdAt: string;
}

export interface Review {
  id: string;
  studentName: string;
  studentTrack: string;
  rating: number; // 1 to 5 stars
  content: string;
  date: string;
  avatarUrl?: string;
  isVerified: boolean;
}


