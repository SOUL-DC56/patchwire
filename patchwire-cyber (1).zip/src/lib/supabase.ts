import { 
  User, CourseTrack, Progress, Certificate, PaymentRecord, 
  NotificationRecord, LeaderboardEntry, ForumPost, PaymentStatus, 
  TrackDifficulty, Lesson, Badge, AccessCode, Review
} from "../types";
import { CYBER_TRACKS } from "../data/tracks";

// Try to grab credentials from meta env
const SUPABASE_URL = (import.meta as any).env?.VITE_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || "";

export const isRealSupabaseConfigured = SUPABASE_URL !== "" && SUPABASE_ANON_KEY !== "";

// Initialize real client if keys are present
export let realSupabase: any = null;

if (isRealSupabaseConfigured) {
  import("@supabase/supabase-js")
    .then(({ createClient }) => {
      realSupabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    })
    .catch((err) => {
      console.error("Failed to load Supabase client dynamically:", err);
    });
}

// Local Storage Fallback DB class
const BUNDLE_CONSTITUENTS: Record<string, string[]> = {
  "soc-grc-bundle": ["soc-analyst", "grc"],
  "red-team-bundle": ["vapt", "digital-forensics"],
  "ultimate-pack": ["soc-analyst", "vapt", "grc", "digital-forensics", "cloud-security-advanced"]
};

class LocalDatabase {
  private users: User[] = [];
  private progress: Progress[] = [];
  private certificates: Certificate[] = [];
  private payments: PaymentRecord[] = [];
  private notifications: NotificationRecord[] = [];
  private forumPosts: ForumPost[] = [];
  private accessCodes: AccessCode[] = [];
  private reviews: Review[] = [];
  private currentUser: User | null = null;

  constructor() {
    this.loadAll();
    this.seedInitialData();
  }

  private loadAll() {
    try {
      this.users = JSON.parse(localStorage.getItem("pw_users") || "[]");
      this.progress = JSON.parse(localStorage.getItem("pw_progress") || "[]");
      this.certificates = JSON.parse(localStorage.getItem("pw_certificates") || "[]");
      this.payments = JSON.parse(localStorage.getItem("pw_payments") || "[]");
      this.notifications = JSON.parse(localStorage.getItem("pw_notifications") || "[]");
      this.forumPosts = JSON.parse(localStorage.getItem("pw_forum") || "[]");
      this.accessCodes = JSON.parse(localStorage.getItem("pw_access_codes") || "[]");
      this.reviews = JSON.parse(localStorage.getItem("pw_reviews") || "[]");
      
      const loggedIn = localStorage.getItem("pw_current_user");
      this.currentUser = loggedIn ? JSON.parse(loggedIn) : null;
    } catch (e) {
      console.error("Local database load failed, resetting state...", e);
    }
  }

  private saveAll() {
    try {
      localStorage.setItem("pw_users", JSON.stringify(this.users));
      localStorage.setItem("pw_progress", JSON.stringify(this.progress));
      localStorage.setItem("pw_certificates", JSON.stringify(this.certificates));
      localStorage.setItem("pw_payments", JSON.stringify(this.payments));
      localStorage.setItem("pw_notifications", JSON.stringify(this.notifications));
      localStorage.setItem("pw_forum", JSON.stringify(this.forumPosts));
      localStorage.setItem("pw_access_codes", JSON.stringify(this.accessCodes));
      localStorage.setItem("pw_reviews", JSON.stringify(this.reviews));
      if (this.currentUser) {
        localStorage.setItem("pw_current_user", JSON.stringify(this.currentUser));
      } else {
        localStorage.removeItem("pw_current_user");
      }
    } catch (e) {
      console.error("Failed to write to localStorage:", e);
    }
  }

  private seedInitialData() {
    let changed = false;

    // 1. Seed standard Admin and Student users if empty
    if (this.users.length === 0) {
      this.users = [
        {
          id: "admin-id-123",
          email: "admin@patchwire.cy",
          name: "Chief SecOps (Admin)",
          avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=60",
          role: "admin",
          createdAt: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString(),
          xp: 8500
        },
        {
          id: "student-id-123",
          email: "student@patchwire.cy",
          name: "Alex Mercer",
          avatarUrl: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=60",
          role: "student",
          createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
          xp: 1500
        }
      ];
      changed = true;
    }

    // 2. Seed default system notifications
    if (this.notifications.length === 0) {
      this.notifications = [
        {
          id: "notif-1",
          userId: "student-id-123",
          title: "Welcome to PatchWire Cyber!",
          message: "Secure your terminals. Explore our advanced practical tracks and initiate your career journey.",
          type: "success",
          isRead: false,
          createdAt: new Date().toISOString()
        },
        {
          id: "notif-2",
          userId: "all",
          title: "Upcoming Cyber CTF Challenge",
          message: "The local CTF qualification starts next Friday. Assemble your teams and secure server shells.",
          type: "info",
          isRead: false,
          createdAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
        }
      ];
      changed = true;
    }

    // 3. Seed active community forum topics
    if (this.forumPosts.length === 0) {
      this.forumPosts = [
        {
          id: "post-1",
          userId: "admin-id-123",
          userName: "Chief SecOps (Admin)",
          userRole: "Instructor",
          avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=60",
          channel: "#general-discussion",
          title: "Starting out in Penetration Testing - My Advice",
          content: "Always understand the basics of TCP/IP and networking before diving into exploitation. An elite hacker is simply a networking wizard who knows how to bend protocols to their will. Focus on Nmap scanning and understanding services!",
          upvotes: 42,
          createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
          replies: [
            {
              id: "rep-1",
              userId: "student-id-123",
              userName: "Alex Mercer",
              userRole: "Student",
              avatarUrl: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=60",
              content: "Absolutely correct! I spent days failing Metasploit exploits until I realized the port wasn't even listening because of target firewalls. Troubleshooting scans is key.",
              createdAt: new Date(Date.now() - 36 * 3600 * 1000).toISOString()
            }
          ]
        },
        {
          id: "post-2",
          userId: "student-id-123",
          userName: "Alex Mercer",
          userRole: "Student",
          avatarUrl: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=60",
          channel: "#lab-help",
          title: "Stuck on Nmap Target scanning flag",
          content: "I'm running Nmap with -sS but getting filtered port responses. Is anyone else experiencing firewall drops on the Ethical Hacking target environment? Do I need to evade with a MTU size change?",
          upvotes: 12,
          createdAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
          replies: []
        }
      ];
      changed = true;
    }

    // 4. Seed an initial pending payment for demo
    if (this.payments.length === 0) {
      this.payments = [
        {
          id: "pay-demo-1",
          userId: "student-id-123",
          userName: "Alex Mercer",
          userEmail: "student@patchwire.cy",
          trackId: "ethical-hacking-basics",
          trackTitle: "Ethical Hacking Basics",
          amount: 29,
          utr: "UTR998877665544",
          screenshotUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=60", // Dynamic abstract background as receipt mock
          status: PaymentStatus.PENDING,
          createdAt: new Date(Date.now() - 4 * 3600 * 1000).toISOString()
        }
      ];
      changed = true;
    }

    // 5. Seed initial access codes for demo
    if (this.accessCodes.length === 0) {
      this.accessCodes = [
        {
          id: "ac-1",
          code: "CYBER-START-99",
          trackId: "soc-basics",
          status: "active",
          createdAt: new Date().toISOString()
        },
        {
          id: "ac-2",
          code: "PCCA-PASS-FREE",
          trackId: "ethical-hacking-basics",
          status: "active",
          createdAt: new Date().toISOString()
        },
        {
          id: "ac-3",
          code: "ULTIMATE-STUDENT",
          trackId: "ultimate-pack",
          status: "active",
          createdAt: new Date().toISOString()
        }
      ];
      changed = true;
    }

    // 6. Seed initial student reviews/testimonials (5 demo reviews as requested)
    if (this.reviews.length === 0) {
      this.reviews = [
        {
          id: "rev-1",
          studentName: "Piyush Pattnaik",
          studentTrack: "Ethical Hacking Basics",
          rating: 5,
          content: "Highly recommended for students in India! The guided TryHackMe modules and the challenging HackTheBox labs in the Ethical Hacking track are incredibly well integrated. Best ₹29 I have spent! Completely transformed my practical cyber understanding.",
          date: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
          avatarUrl: "https://api.dicebear.com/7.x/pixel-art/svg?seed=piyush",
          isVerified: true
        },
        {
          id: "rev-2",
          studentName: "Ananya Sen",
          studentTrack: "SOC Analyst",
          rating: 5,
          content: "The SOC Analyst track was fantastic. Analyzing raw log streams and identifying malware infection patterns on the simulated SIEM gave me the exact hands-on experience I needed for my campus placement prep.",
          date: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
          avatarUrl: "https://api.dicebear.com/7.x/pixel-art/svg?seed=ananya",
          isVerified: true
        },
        {
          id: "rev-3",
          studentName: "Rohan Deshmukh",
          studentTrack: "VAPT Professional",
          rating: 5,
          content: "Awesome platform. Bypassing authorization headers in the custom-built web simulators and extracting the flag was extremely thrilling. Love the hybrid TryHackMe guidance + HackTheBox hard exercises!",
          date: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
          avatarUrl: "https://api.dicebear.com/7.x/pixel-art/svg?seed=rohan",
          isVerified: true
        },
        {
          id: "rev-4",
          studentName: "Priya Sharma",
          studentTrack: "Digital Forensics",
          rating: 4,
          content: "The memory forensics labs using Volatility simulator were top-notch. Finding the hidden rogue process flag felt so rewarding. Extremely detailed syllabus and very simple administrative receipt approvals.",
          date: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
          avatarUrl: "https://api.dicebear.com/7.x/pixel-art/svg?seed=priya",
          isVerified: true
        },
        {
          id: "rev-5",
          studentName: "Karthik Nair",
          studentTrack: "Ultimate Pack Bundle",
          rating: 5,
          content: "Unbelievable value in the Ultimate Pack. Unlocked all five professional tracks, received verified diploma credentials, and the support team verified my UPI reference screenshot within 30 minutes! High quality.",
          date: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
          avatarUrl: "https://api.dicebear.com/7.x/pixel-art/svg?seed=karthik",
          isVerified: true
        }
      ];
      changed = true;
    }

    if (changed) {
      this.saveAll();
    }
  }

  // AUTH ACTIONS
  public getCurrentUser(): User | null {
    return this.currentUser;
  }

  public login(email: string, role: "admin" | "student"): User {
    const cleanEmail = email.toLowerCase().trim();
    let user = this.users.find(u => u.email === cleanEmail);
    if (!user) {
      user = {
        id: "user-" + Math.random().toString(36).substring(2, 9),
        email: cleanEmail,
        name: cleanEmail.split("@")[0].toUpperCase(),
        avatarUrl: `https://api.dicebear.com/7.x/pixel-art/svg?seed=${cleanEmail}`,
        role,
        createdAt: new Date().toISOString(),
        xp: 100
      };
      this.users.push(user);
    } else {
      // Allow switching roles during login for testing convenience
      user.role = role;
    }
    this.currentUser = user;
    this.saveAll();
    return user;
  }

  public register(name: string, email: string, role: "admin" | "student"): User {
    const cleanEmail = email.toLowerCase().trim();
    const existing = this.users.find(u => u.email === cleanEmail);
    if (existing) {
      existing.name = name;
      existing.role = role;
      this.currentUser = existing;
      this.saveAll();
      return existing;
    }

    const user: User = {
      id: "user-" + Math.random().toString(36).substring(2, 9),
      email: cleanEmail,
      name,
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${name}`,
      role,
      createdAt: new Date().toISOString(),
      xp: 100
    };
    this.users.push(user);
    this.currentUser = user;
    this.saveAll();
    return user;
  }

  public logout() {
    this.currentUser = null;
    this.saveAll();
  }

  public updateUserProfile(name: string, avatarUrl?: string): User | null {
    if (!this.currentUser) return null;
    const user = this.users.find(u => u.id === this.currentUser!.id);
    if (user) {
      user.name = name;
      if (avatarUrl) user.avatarUrl = avatarUrl;
      this.currentUser = user;
      this.saveAll();
    }
    return this.currentUser;
  }

  public addXp(amount: number) {
    if (!this.currentUser) return;
    const user = this.users.find(u => u.id === this.currentUser!.id);
    if (user) {
      user.xp += amount;
      this.currentUser.xp = user.xp;
      this.saveAll();
    }
  }

  // TRACK PROGRESS
  public getProgress(userId: string, trackId: string): Progress {
    let prog = this.progress.find(p => p.userId === userId && p.trackId === trackId);
    if (!prog) {
      prog = {
        userId,
        trackId,
        completedLessons: [],
        lastAccessed: new Date().toISOString(),
        quizScores: {}
      };
      this.progress.push(prog);
      this.saveAll();
    }
    return prog;
  }

  public isTrackCompleted(userId: string, trackId: string): boolean {
    const track = CYBER_TRACKS.find(t => t.id === trackId);
    if (!track) return false;
    const prog = this.getProgress(userId, trackId);
    const allLessonIds = track.modules.flatMap(m => m.lessons.map(l => l.id));
    if (allLessonIds.length === 0) return false;
    return allLessonIds.every(id => prog.completedLessons.includes(id));
  }

  public checkPrerequisitesCompleted(userId: string): boolean {
    return this.isTrackCompleted(userId, "cisco-cyber-basics") && 
           this.isTrackCompleted(userId, "cisco-network-basics");
  }

  public getEnrolledTracks(userId: string): CourseTrack[] {
    // A course is unlocked if payment status is Approved
    const approvedTrackIds = this.payments
      .filter(p => p.userId === userId && p.status === PaymentStatus.APPROVED)
      .map(p => p.trackId);
    
    // Expand bundles to also unlock individual constituent tracks
    const expandedTrackIds = [...approvedTrackIds];
    approvedTrackIds.forEach(id => {
      if (BUNDLE_CONSTITUENTS[id]) {
        expandedTrackIds.push(...BUNDLE_CONSTITUENTS[id]);
      }
    });
    
    // Also support default admin bypass
    if (this.currentUser?.role === "admin") {
      return CYBER_TRACKS;
    }

    const freePrerequisites = ["cisco-cyber-basics", "cisco-network-basics"];
    return CYBER_TRACKS.filter(t => freePrerequisites.includes(t.id) || expandedTrackIds.includes(t.id));
  }

  public getPendingTrackIds(userId: string): string[] {
    return this.payments
      .filter(p => p.userId === userId && p.status === PaymentStatus.PENDING)
      .map(p => p.trackId);
  }

  public getUnlockedBadges(userId: string): Badge[] {
    const key = `pw_unlocked_badges_${userId}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (e) {
        return [];
      }
    }
    const initialBadges: Badge[] = [
      { id: "b1", title: "Terminals Initiator", description: "Successfully established an operator profile on PatchWire Cyber.", iconName: "Flame", unlockedAt: new Date().toISOString() }
    ];
    localStorage.setItem(key, JSON.stringify(initialBadges));
    return initialBadges;
  }

  public unlockBadge(userId: string, badgeId: string, title: string, description: string, iconName: string) {
    const key = `pw_unlocked_badges_${userId}`;
    const current = this.getUnlockedBadges(userId);
    if (current.some(b => b.id === badgeId)) return;

    const newBadge: Badge = {
      id: badgeId,
      title,
      description,
      iconName,
      unlockedAt: new Date().toISOString()
    };
    
    current.push(newBadge);
    localStorage.setItem(key, JSON.stringify(current));
    
    this.createNotification(
      userId,
      `🏆 Badge Unlocked: ${title}`,
      `Congratulations! You've unlocked the "${title}" cyber badge. Details: ${description}`,
      "success"
    );
    
    window.dispatchEvent(new CustomEvent("badge-unlocked", { detail: newBadge }));
    this.saveAll();
  }

  public checkAndTriggerLessonBadges(userId: string, trackId: string, lessonId: string) {
    this.unlockBadge(userId, "first_lesson", "First Responder", "Completed your first lesson node on the platform.", "Award");

    if (trackId === "cisco-cyber-basics" && this.isTrackCompleted(userId, "cisco-cyber-basics")) {
      this.unlockBadge(userId, "cisco_cyber_done", "Cisco Cyber Graduate", "Completed the Cisco Cybersecurity Fundamentals prerequisite.", "ShieldCheck");
    }
    if (trackId === "cisco-network-basics" && this.isTrackCompleted(userId, "cisco-network-basics")) {
      this.unlockBadge(userId, "cisco_network_done", "Cisco Network Master", "Completed the Cisco Networking Essentials prerequisite.", "Cpu");
    }

    const track = CYBER_TRACKS.find(t => t.id === trackId);
    if (track) {
      track.modules.forEach(mod => {
        const modLessonIds = mod.lessons.map(l => l.id);
        const prog = this.getProgress(userId, trackId);
        const isModDone = modLessonIds.every(id => prog.completedLessons.includes(id));
        if (isModDone) {
          const modName = mod.title.split(":")[0] || "Module";
          this.unlockBadge(
            userId, 
            `mod_completed_${trackId}_${mod.id}`, 
            `${track.title} - ${modName} Champion`, 
            `Completed all curriculum, lab, and quiz requirements for ${mod.title}.`, 
            "Sparkles"
          );
        }
      });
    }

    if (this.isTrackCompleted(userId, trackId)) {
      this.unlockBadge(
        userId, 
        `track_completed_${trackId}`, 
        `${track?.title || "Track"} Graduate`, 
        `Successfully completed the full curriculum of "${track?.title || "Track"}" and claimed your diploma.`, 
        "Trophy"
      );
    }
  }

  public completeLesson(userId: string, trackId: string, lessonId: string, quizScore?: number) {
    const prog = this.getProgress(userId, trackId);
    let newlyCompleted = false;
    if (!prog.completedLessons.includes(lessonId)) {
      prog.completedLessons.push(lessonId);
      this.addXp(150); // Earn 150 XP for completing a lesson!
      newlyCompleted = true;
    }
    prog.lastAccessed = new Date().toISOString();
    if (quizScore !== undefined) {
      prog.quizScores[lessonId] = quizScore;
    }
    this.saveAll();
    if (newlyCompleted) {
      this.checkAndTriggerLessonBadges(userId, trackId, lessonId);
    }
  }

  public toggleLessonCompletion(userId: string, trackId: string, lessonId: string): boolean {
    const prog = this.getProgress(userId, trackId);
    const index = prog.completedLessons.indexOf(lessonId);
    let completed = false;
    if (index > -1) {
      prog.completedLessons.splice(index, 1);
      completed = false;
    } else {
      prog.completedLessons.push(lessonId);
      this.addXp(150);
      completed = true;
    }
    prog.lastAccessed = new Date().toISOString();
    this.saveAll();
    if (completed) {
      this.checkAndTriggerLessonBadges(userId, trackId, lessonId);
    }
    return completed;
  }

  // PAYMENTS (UPI Manual verification)
  public createPayment(trackId: string, amount: number, utr: string, screenshotUrl: string): PaymentRecord {
    if (!this.currentUser) throw new Error("Authentication required");
    
    const record: PaymentRecord = {
      id: "pay-" + Math.random().toString(36).substring(2, 9).toUpperCase(),
      userId: this.currentUser.id,
      userName: this.currentUser.name,
      userEmail: this.currentUser.email,
      trackId,
      trackTitle: CYBER_TRACKS.find(t => t.id === trackId)?.title || "Cyber Track",
      amount,
      utr,
      screenshotUrl,
      status: PaymentStatus.PENDING,
      createdAt: new Date().toISOString()
    };
    
    // Check if there's an existing record for this course, remove it to overwrite/retry
    this.payments = this.payments.filter(p => !(p.userId === this.currentUser!.id && p.trackId === trackId));
    
    this.payments.push(record);
    this.saveAll();

    // Create a student notification
    this.createNotification(
      this.currentUser.id,
      "Payment Verification Submitted",
      `Your manual payment of ₹${amount} for ${record.trackTitle} is submitted for validation. Trans ID: ${utr}. Expect approval within 1-2 hours.`,
      "info"
    );

    return record;
  }

  public getPayments(): PaymentRecord[] {
    return this.payments;
  }

  public getUserPayments(userId: string): PaymentRecord[] {
    return this.payments.filter(p => p.userId === userId);
  }

  // ADMIN ENDPOINTS
  public updatePaymentStatus(paymentId: string, status: PaymentStatus): PaymentRecord | null {
    const record = this.payments.find(p => p.id === paymentId);
    if (!record) return null;

    record.status = status;
    this.saveAll();

    if (status === PaymentStatus.APPROVED) {
      // 1. Notify the student of access
      this.createNotification(
        record.userId,
        "Learning Track Unlocked!",
        `Congratulations! Your payment for "${record.trackTitle}" has been verified. Welcome to your cybersecurity internship program!`,
        "success"
      );
    } else if (status === PaymentStatus.REJECTED) {
      // Notify of rejection
      this.createNotification(
        record.userId,
        "Payment Verification Failed",
        `We were unable to verify your payment transaction ID (UTR: ${record.utr}) for "${record.trackTitle}". Please check and try again, or contact support.`,
        "alert"
      );
    }

    return record;
  }

  // NOTIFICATIONS
  public getNotifications(userId: string): NotificationRecord[] {
    return this.notifications.filter(n => n.userId === userId || n.userId === "all");
  }

  public createNotification(userId: string, title: string, message: string, type: NotificationRecord["type"]): NotificationRecord {
    const newNotif: NotificationRecord = {
      id: "notif-" + Math.random().toString(36).substring(2, 9),
      userId,
      title,
      message,
      type,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    this.notifications.unshift(newNotif);
    this.saveAll();
    return newNotif;
  }

  public markNotificationsAsRead(userId: string) {
    this.notifications.forEach(n => {
      if (n.userId === userId || n.userId === "all") {
        n.isRead = true;
      }
    });
    this.saveAll();
  }

  // CERTIFICATES
  public generateCertificate(userId: string, userName: string, trackId: string): Certificate {
    const track = CYBER_TRACKS.find(t => t.id === trackId);
    const certId = `PWC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    
    // Remove duplicates if existing
    this.certificates = this.certificates.filter(c => !(c.userId === userId && c.trackId === trackId));

    // Gather assessment scores
    const prog = this.getProgress(userId, trackId);
    const assessmentScores: { [lessonTitle: string]: number } = {};
    if (track) {
      track.modules.forEach(m => {
        m.lessons.forEach(l => {
          if (l.type === "quiz") {
            const score = prog.quizScores[l.id];
            // If they completed the lesson but have no quiz score registered, we default to 100 or a realistic passing grade
            const finalScore = score !== undefined ? score : (prog.completedLessons.includes(l.id) ? 100 : Math.floor(75 + Math.random() * 25));
            assessmentScores[l.title] = finalScore;
          }
        });
      });
    }

    const cert: Certificate = {
      id: certId,
      userId,
      userName,
      trackId,
      trackTitle: track?.title || "Cyber Security Specialist Program",
      issueDate: new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }),
      qrCodeUrl: `${window.location.origin}/verify-cert?id=${certId}`,
      assessmentScores
    };

    this.certificates.push(cert);
    this.addXp(1000); // 1000 bonus XP for certification!
    this.saveAll();

    this.createNotification(
      userId,
      "Official Digital Certificate Issued!",
      `Bravo! You have officially graduated from "${cert.trackTitle}". Your certificate ID is ${certId}. Verify and share now!`,
      "success"
    );

    return cert;
  }

  public getCertificates(userId: string): Certificate[] {
    return this.certificates.filter(c => c.userId === userId);
  }

  public getCertificateById(certId: string): Certificate | null {
    return this.certificates.find(c => c.id === certId) || null;
  }

  // LEADERBOARD
  public getLeaderboard(): LeaderboardEntry[] {
    // Generate leaderboard dynamically based on users list and active progress logs
    const entries: LeaderboardEntry[] = this.users.map(u => {
      const progs = this.progress.filter(p => p.userId === u.id);
      const labsCompleted = progs.reduce((acc, curr) => {
        // count lab type lessons in completed
        let labs = 0;
        const track = CYBER_TRACKS.find(t => t.id === curr.trackId);
        if (track) {
          track.modules.forEach(m => {
            m.lessons.forEach(l => {
              if (l.type === "lab" && curr.completedLessons.includes(l.id)) {
                labs++;
              }
            });
          });
        }
        return acc + labs;
      }, 0);

      const certsCount = this.certificates.filter(c => c.userId === u.id).length;

      return {
        userId: u.id,
        userName: u.name,
        avatarUrl: u.avatarUrl,
        xp: u.xp + (labsCompleted * 100) + (certsCount * 500),
        labsCompleted,
        badgesCount: certsCount + (u.xp > 2000 ? 2 : u.xp > 500 ? 1 : 0)
      };
    });

    return entries.sort((a, b) => b.xp - a.xp).map((entry, index) => ({
      ...entry,
      rank: index + 1
    }));
  }

  // COMMUNITY FORUM
  public getForumPosts(channel?: string): ForumPost[] {
    if (channel) {
      return this.forumPosts.filter(p => p.channel === channel);
    }
    return this.forumPosts;
  }

  public createForumPost(channel: string, title: string, content: string): ForumPost {
    if (!this.currentUser) throw new Error("Authentication required");

    const newPost: ForumPost = {
      id: "post-" + Math.random().toString(36).substring(2, 9),
      userId: this.currentUser.id,
      userName: this.currentUser.name,
      userRole: this.currentUser.role === "admin" ? "Instructor" : "Student",
      avatarUrl: this.currentUser.avatarUrl,
      channel,
      title,
      content,
      upvotes: 1,
      replies: [],
      createdAt: new Date().toISOString()
    };

    this.forumPosts.unshift(newPost);
    this.addXp(50); // XP for engaging in community!
    this.saveAll();
    return newPost;
  }

  public addForumReply(postId: string, content: string): ForumPost | null {
    if (!this.currentUser) throw new Error("Authentication required");

    const post = this.forumPosts.find(p => p.id === postId);
    if (!post) return null;

    const reply = {
      id: "rep-" + Math.random().toString(36).substring(2, 9),
      userId: this.currentUser.id,
      userName: this.currentUser.name,
      userRole: this.currentUser.role === "admin" ? "Instructor" : "Student",
      avatarUrl: this.currentUser.avatarUrl,
      content,
      createdAt: new Date().toISOString()
    };

    post.replies.push(reply);
    this.addXp(25); // XP for reply!
    this.saveAll();
    return post;
  }

  public upvotePost(postId: string) {
    const post = this.forumPosts.find(p => p.id === postId);
    if (post) {
      post.upvotes += 1;
      this.saveAll();
    }
  }

  // DYNAMIC REUSABLE COURSE ADMIN ACTIONS
  public addLessonToModule(trackId: string, moduleId: string, lesson: Omit<Lesson, "id">): CourseTrack | null {
    const track = CYBER_TRACKS.find(t => t.id === trackId);
    if (!track) return null;

    const mod = track.modules.find(m => m.id === moduleId);
    if (!mod) return null;

    const newLesson: Lesson = {
      ...lesson,
      id: "les-" + Math.random().toString(36).substring(2, 9)
    };

    mod.lessons.push(newLesson);
    return track;
  }

  public createAnnouncement(title: string, message: string) {
    this.createNotification("all", title, message, "info");
  }

  // ACCESS CODES MANAGEMENT
  public getAccessCodes(): AccessCode[] {
    return this.accessCodes;
  }

  public createAccessCode(code: string, trackId: string): AccessCode {
    const newCode: AccessCode = {
      id: "ac-" + Math.random().toString(36).substring(2, 9),
      code: code.trim().toUpperCase(),
      trackId,
      status: "active",
      createdAt: new Date().toISOString()
    };
    this.accessCodes.unshift(newCode);
    this.saveAll();
    return newCode;
  }

  public toggleAccessCodeStatus(id: string): AccessCode | null {
    const item = this.accessCodes.find(c => c.id === id);
    if (!item) return null;
    item.status = item.status === "active" ? "disabled" : "active";
    this.saveAll();
    return item;
  }

  public deleteAccessCode(id: string): boolean {
    const initialLen = this.accessCodes.length;
    this.accessCodes = this.accessCodes.filter(c => c.id !== id);
    this.saveAll();
    return this.accessCodes.length < initialLen;
  }

  public claimAccessCode(userId: string, codeStr: string): { success: boolean; message: string; trackTitle?: string } {
    const cleanCode = codeStr.trim().toUpperCase();
    const item = this.accessCodes.find(c => c.code === cleanCode);

    if (!item) {
      return { success: false, message: "Invalid access code. Please check for spelling mistakes." };
    }

    if (item.status === "disabled") {
      return { success: false, message: "This access code has been deactivated by the operations group." };
    }

    if (item.usedBy) {
      return { success: false, message: "This one-time access code has already been used." };
    }

    const user = this.users.find(u => u.id === userId);
    if (!user) {
      return { success: false, message: "User not found in security logs." };
    }

    const trackId = item.trackId;
    let trackTitle = "Cyber Course";

    if (trackId === "ultimate-pack") {
      trackTitle = "Ultimate Pack Bundle";
    } else if (trackId === "soc-grc-bundle") {
      trackTitle = "SOC + GRC Bundle";
    } else if (trackId === "red-team-bundle") {
      trackTitle = "Red Team Bundle";
    } else {
      const track = CYBER_TRACKS.find(t => t.id === trackId);
      if (track) {
        trackTitle = track.title;
      }
    }

    // Mark as used
    item.usedBy = user.id;
    item.usedAt = new Date().toISOString();

    // Create approved payment record to unlock
    const record: PaymentRecord = {
      id: "pay-" + Math.random().toString(36).substring(2, 9).toUpperCase(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      trackId: trackId,
      trackTitle: trackTitle,
      amount: 0,
      utr: "ACCESS_CODE_" + cleanCode,
      screenshotUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400", // Technology shield background
      status: PaymentStatus.APPROVED,
      createdAt: new Date().toISOString()
    };

    // Remove any pending/existing payments for this course to overwrite
    this.payments = this.payments.filter(p => !(p.userId === user.id && p.trackId === trackId));
    this.payments.push(record);

    this.createNotification(
      user.id,
      "Access Code Redeemed Successfully!",
      `You have claimed code "${cleanCode}". "${trackTitle}" is now fully unlocked on your terminal dashboard.`,
      "success"
    );

    this.saveAll();
    return { success: true, message: `Access granted to "${trackTitle}"!`, trackTitle };
  }

  // REVIEWS MANAGEMENT
  public getReviews(): Review[] {
    return this.reviews;
  }

  public submitReview(studentName: string, studentTrack: string, rating: number, content: string): Review {
    const newReview: Review = {
      id: "rev-" + Math.random().toString(36).substring(2, 9),
      studentName: studentName.trim() || "Anonymous Operator",
      studentTrack: studentTrack || "General Cyber Track",
      rating: Math.max(1, Math.min(5, rating)),
      content: content.trim(),
      date: new Date().toISOString(),
      avatarUrl: `https://api.dicebear.com/7.x/pixel-art/svg?seed=${encodeURIComponent(studentName.trim() || "anon")}`,
      isVerified: true
    };
    this.reviews.unshift(newReview);
    this.saveAll();
    return newReview;
  }
}

export const db = new LocalDatabase();
