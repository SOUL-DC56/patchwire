import { CourseTrack, TrackDifficulty, Module, Lesson } from "../types";

// Base metadata for the 12 tracks
const TRACKS_METADATA = [
  {
    id: "cisco-cyber-basics",
    title: "Cisco Cybersecurity Fundamentals",
    description: "Common to all tracks (DO FIRST). Learn fundamental cybersecurity terminology, threat vectors, enterprise defenses, and protection mechanisms.",
    longDescription: "Mandatory foundation for PatchWire Cyber internships. Explore the cybersecurity threat landscape, understand security posture management, analyze common vulnerabilities, and learn the essential policies required of any defender.",
    price: 0,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["Cyber Security", "Threat Intel", "Basic Defense", "Cisco Fundamentals"],
    bannerImage: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "cisco-network-basics",
    title: "Cisco Networking Essentials",
    description: "Common to all tracks (DO FIRST). Learn essential network routing protocols, IP addressing, subnetting, packet flows, and transport architecture.",
    longDescription: "Mandatory networking foundation for PatchWire Cyber internships. Understand OSI layers, TCP/UDP protocols, routing, subnetting, network configurations, and packet capture concepts using Nmap and basic Wireshark tools.",
    price: 0,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["Networking Basics", "OSI & TCP/IP", "Subnetting", "Routing Essentials"],
    bannerImage: "https://images.unsplash.com/photo-1544256718-3bcf237f3974?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "soc-basics",
    title: "SOC Basics",
    description: "Learn the fundamentals of Security Operations Center work, including log analysis, alert triage, and incident basics.",
    longDescription: "Get started on your blue team career. This course takes you from scratch to understanding security incident logs, analyzing system alarms, evaluating threat levels, and drafting complete incident summaries. Perfect for complete beginners.",
    price: 19,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["Log Analysis", "Alert Triage", "SIEM Basics", "Incident Reports"],
    bannerImage: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "ethical-hacking-basics",
    title: "Ethical Hacking Basics",
    description: "Get started with ethical hacking concepts, penetration testing methodology, and basic tools like Nmap and Metasploit.",
    longDescription: "An entry-level syllabus for ethical hacking. Learn the theoretical phase of network mapping, running vulnerability tests using Nmap scans, performing credential audits, and launching introductory Metasploit scripts securely inside sandboxes.",
    price: 29,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["Recon Techniques", "Nmap & Metasploit", "Web Basics", "CTF Practice"],
    bannerImage: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "network-security-basics",
    title: "Network Security Basics",
    description: "Understand network protocols, firewalls, VPNs, and common network attacks. Perfect starting point for any cyber career.",
    longDescription: "Learn how the global internet and local networks are secured. Study ports, the OSI model hierarchy, packet analysis using Wireshark tools, setting up demilitarized zones, and basic firewall blocking guidelines.",
    price: 29,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["OSI Model", "Firewall Config", "VPN Setup", "Packet Analysis"],
    bannerImage: "https://images.unsplash.com/photo-1544256718-3bcf237f3974?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "cloud-security-basics",
    title: "Cloud Security Basics",
    description: "Introduction to cloud security concepts, AWS/Azure basics, IAM, and the shared responsibility model.",
    longDescription: "A beginner-friendly cloud security course. Understand public cloud infrastructure configurations, user privilege models, locking S3 storage buckets, and auditing cloud activity logs.",
    price: 59,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["AWS & Azure Basics", "IAM Fundamentals", "S3 Security", "Cloud Labs"],
    bannerImage: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "basic-soc-internship",
    title: "Basic SOC Internship",
    description: "Entry-level Security Operations Center internship covering log monitoring, alert triage, and incident basics. Perfect for complete beginners.",
    longDescription: "A highly practical virtual internship program. Monitor log outputs, triage alerts in our simulated dashboard, record network incident notes, and earn a student internship validation credential.",
    price: 19,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["Log Monitoring", "Alert Triage", "SIEM Basics", "Practical Labs"],
    bannerImage: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "basic-forensics-internship",
    title: "Basic Digital Forensics Internship",
    description: "Entry-level digital forensics internship. Learn evidence handling, file system basics, and beginner investigation techniques.",
    longDescription: "Start your career in digital investigation. Practice evidence handling, recover deleted files from formatted disk images, analyze metadata, and map incident chronological logs.",
    price: 19,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["Evidence Handling", "File System Analysis", "Chain of Custody", "Practical Labs"],
    bannerImage: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "digital-forensics-basics",
    title: "Digital Forensics Basics",
    description: "Entry-level digital forensics program. Learn the fundamentals of evidence collection, file system analysis, and beginner investigation techniques in a virtual lab environment.",
    longDescription: "A thorough introduction to cybersecurity forensics. Study how to secure evidence properly, dissect FAT/NTFS file systems, inspect program execution traces, and report findings.",
    price: 9,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["Evidence Collection", "File System Analysis", "Memory Forensics Intro", "Chain of Custody"],
    bannerImage: "https://images.unsplash.com/photo-1618060932014-4deda4932554?w=800&auto=format&fit=crop&q=60"
  },
  // Professional Tracks
  {
    id: "soc-analyst",
    title: "SOC Analyst",
    description: "Master SOC operations with real-world SIEM tools, threat hunting, incident response, and advanced log correlation across enterprise environments.",
    longDescription: "The professional pathway for SOC Engineers. Learn to construct SIEM rules on dashboards, analyze complex multi-host Windows and Linux active directory logs, investigate advanced persistent threat groups, and write enterprise audit reports.",
    price: 99,
    difficulty: TrackDifficulty.INTERMEDIATE,
    durationWeeks: 2,
    skills: ["SIEM Mastery", "Threat Hunting", "IR Procedures", "Malware Analysis"],
    bannerImage: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "vapt",
    title: "VAPT",
    description: "Comprehensive Vulnerability Assessment and Penetration Testing program. Covers web, network, and mobile app pentesting with real-world engagements.",
    longDescription: "An intensive offensive cybersecurity course. Master Burp Suite Pro features, scan servers for remote code exploits, decompile and reverse Android applications, audit API endpoints, and compose official threat mitigation rosters.",
    price: 199,
    difficulty: TrackDifficulty.ADVANCED,
    durationWeeks: 2,
    skills: ["Web App Pentesting", "Network VAPT", "Burp Suite Pro", "Report Writing"],
    bannerImage: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "grc",
    title: "GRC",
    description: "Governance, Risk and Compliance track covering ISO 27001, GDPR, NIST frameworks, risk assessments, and audit preparation.",
    longDescription: "The structural foundation of compliance-driven defense. Study the ISO/IEC 27001 standard, design complete corporate asset registers, perform statutory risk analysis, and audit technical workflows for compliance.",
    price: 49,
    difficulty: TrackDifficulty.BEGINNER,
    durationWeeks: 2,
    skills: ["ISO 27001", "GDPR Compliance", "NIST Framework", "Risk Assessments"],
    bannerImage: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "digital-forensics",
    title: "Digital Forensics",
    description: "Learn digital forensics investigation techniques using industry tools like Autopsy, Volatility, and FTK for memory, disk, and network forensics.",
    longDescription: "The ultimate blue team forensics course. Dissect raw RAM dumps with Volatility, reconstruct partition structures using Autopsy, inspect email header authenticity, and establish court-admissible custody chains.",
    price: 69,
    difficulty: TrackDifficulty.ADVANCED,
    durationWeeks: 2,
    skills: ["Memory Forensics", "Disk Analysis", "Network Forensics", "Chain of Custody"],
    bannerImage: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: "cloud-security-advanced",
    title: "Cloud Security Advanced",
    description: "Advanced cloud security covering AWS, Azure, and GCP security architectures, CSPM, CASB, DevSecOps, and cloud compliance frameworks.",
    longDescription: "Master cloud environments. Audit Kubernetes configurations, integrate secure SAST/DAST scanner checks in CI/CD pipelines, secure GCP/AWS databases, and manage Cloud Security Posture.",
    price: 399,
    difficulty: TrackDifficulty.EXPERT,
    durationWeeks: 2,
    skills: ["AWS/Azure/GCP Security", "CSPM & CASB", "DevSecOps", "Cloud Forensics"],
    bannerImage: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=60"
  }
];

interface SyllabusDetails {
  title: string;
  skill: string;
  lectureUrl: string;
  labDesc: string;
  labInst: string;
  q: string;
  opts: string[];
  ans: number;
  exp: string;
}

// 100% Free Learning Portal links mapped cleanly with 2 Lectures & 2 Free Labs for every single track
const COURSE_SYLLABI: Record<string, [SyllabusDetails, SyllabusDetails]> = {
  "cisco-cyber-basics": [
    {
      title: "Cisco Security Threats & Vectors",
      skill: "Cyber Security",
      lectureUrl: "https://www.netacad.com/courses/cybersecurity",
      labDesc: "[CISCO THREAT ANALYSIS DRILL]\nExplore the mechanics of malware, ransomware payloads, and social engineering delivery systems. Map threat intelligence sources.",
      labInst: "1. Execute 'ls' to locate active intelligence bulletins.\n2. Run 'nmap' to search for listening malicious servers.\n3. Run 'readflag' to collect your threat verification digest.",
      q: "Which type of malware replicates itself automatically across a network to compromise other connected nodes without user action?",
      opts: ["Trojan horse", "Worm", "Adware", "Spyware"],
      ans: 1,
      exp: "Worms are self-replicating malware programs that travel over networks without needing user interaction."
    },
    {
      title: "Cisco Defense Posture & Controls",
      skill: "Basic Defense",
      lectureUrl: "https://www.netacad.com/courses/cybersecurity",
      labDesc: "[CISCO SECURITY CONTROLS DRILL]\nInspect security policies, multi-factor authentication requirements, and encryption standards.",
      labInst: "1. Run 'help' to review Cisco policy compliance tools.\n2. Execute 'exploit' to test secure boundary rules.\n3. Run 'readflag' to obtain the posture compliance token.",
      q: "Which element of the CIA Triad is protected when you enforce strong password requirements and Multi-Factor Authentication (MFA)?",
      opts: ["Confidentiality", "Integrity", "Availability", "Accountability"],
      ans: 0,
      exp: "Confidentiality ensures that sensitive systems and data are accessible only to authorized operators."
    }
  ],
  "cisco-network-basics": [
    {
      title: "Cisco OSI Layers & Packet Flow",
      skill: "OSI & TCP/IP",
      lectureUrl: "https://www.netacad.com/courses/networking",
      labDesc: "[CISCO OSI FLOATING PACKET DRILL]\nTrace packet hops through the Layer 3 Network and Layer 4 Transport protocols. Inspect source and destination IP addresses.",
      labInst: "1. Execute 'ls' to list capture pcap files.\n2. Execute 'nmap' to map active network interfaces.\n3. Run 'readflag' to submit packet tracer results.",
      q: "At which layer of the OSI model do routers operate to forward data packets across network perimeters?",
      opts: ["Layer 2 (Data Link)", "Layer 3 (Network)", "Layer 4 (Transport)", "Layer 7 (Application)"],
      ans: 1,
      exp: "Routers operate at Layer 3 (Network layer) of the OSI model to route data based on IP addresses."
    },
    {
      title: "Cisco IPv4 Subnetting & Gateway Routing",
      skill: "Subnetting",
      lectureUrl: "https://www.netacad.com/courses/networking",
      labDesc: "[CISCO ROUTING INTERACTION DRILL]\nCalculate subnets for a CIDR /24 block. Configure system routing tables and gateways.",
      labInst: "1. Run 'help' to view routing tools.\n2. Execute 'exploit' to check gateway availability.\n3. Run 'readflag' to confirm CIDR block coordinates.",
      q: "How many usable host IP addresses are available in a standard Class C subnet with a mask of /24?",
      opts: ["254", "256", "128", "512"],
      ans: 0,
      exp: "A /24 subnet has 256 addresses total, minus 2 (network address and broadcast address), leaving 254 usable host IPs."
    }
  ],
  "soc-basics": [
    {
      title: "SOC Operations & Log Auditing",
      skill: "Log Analysis",
      lectureUrl: "https://cheatsheetseries.owasp.org/cheatsheets/Logging_Vocabulary_Cheat_Sheet.html",
      labDesc: "[LINUX LOG AUDITING LAB]\nAudit system-wide syslog logs inside our secure terminal. Track down failed logins, unauthorized sudo executions, and malicious backdoors.",
      labInst: "1. Type 'ls' to locate active auth.log files.\n2. Run 'nmap' to simulate safe port probing.\n3. Run 'readflag' to verify the integrity and claim the compliance flag.",
      q: "Which Event ID in Windows Security logs records successful user account logon events?",
      opts: ["Event ID 4624", "Event ID 4625", "Event ID 4720", "Event ID 4634"],
      ans: 0,
      exp: "Event ID 4624 is triggered on Windows security systems when a user account logs in successfully."
    },
    {
      title: "Incident Triage & Threat Response",
      skill: "Alert Triage",
      lectureUrl: "https://cheatsheetseries.owasp.org/cheatsheets/Incident_Response_Cheat_Sheet.html",
      labDesc: "[SIEM INCIDENT RESPONSE LAB]\nEvaluate incident priority by tracing source IP headers and checking for active data filtration traces.",
      labInst: "1. Run 'help' to examine available SOC tools.\n2. Execute 'exploit' to trigger alerts in our simulated telemetry loop.\n3. Run 'readflag' to submit your incident findings.",
      q: "Which phase of the incident response lifecycle is focused on preventing further damage from a detected intrusion?",
      opts: ["Eradication", "Preparation", "Containment", "Post-Incident Review"],
      ans: 2,
      exp: "Containment isolates compromised nodes to prevent further damage or lateral movement across networks."
    }
  ],
  "basic-soc-internship": [
    {
      title: "Internship Onboarding & SOC Monitoring",
      skill: "SOC Operations",
      lectureUrl: "https://cheatsheetseries.owasp.org/cheatsheets/Logging_Vocabulary_Cheat_Sheet.html",
      labDesc: "[VIRTUAL INTERNSHIP ONBOARDING LAB]\nLearn the primary duties of a Tier-1 SOC Analyst. Monitor simulated security events and logs.",
      labInst: "1. Execute 'ls' to inspect local corporate logs.\n2. Execute 'nmap' to catalog local gateway devices.\n3. Run 'readflag' to finalize your onboarding task.",
      q: "What is the primary objective of a security operations center (SOC)?",
      opts: ["To develop website components", "To continuously monitor, detect, and respond to cyber threats", "To configure payroll systems", "To write marketing materials"],
      ans: 1,
      exp: "A SOC's main function is to continually monitor and maintain an organization's security posture."
    },
    {
      title: "Active Alert Triaging & Response",
      skill: "Incident Triage",
      lectureUrl: "https://cheatsheetseries.owasp.org/cheatsheets/Incident_Response_Cheat_Sheet.html",
      labDesc: "[ALERT TRIAGE DRILL]\nInspect security telemetry alerts. Isolate malicious connection requests and escalate high-impact threats.",
      labInst: "1. Execute 'exploit' to start active security logging.\n2. Run 'readflag' to collect the containment hash.",
      q: "When reviewing alert telemetry, what does a sudden burst of failed SSH logins from an unknown public IP indicate?",
      opts: ["A software upgrade process", "A brute-force credential guessing attack", "A caching system error", "A standard database query"],
      ans: 1,
      exp: "Repeated failed SSH logins from external nodes indicate credential harvesting or brute-force scanning."
    }
  ],
  "soc-analyst": [
    {
      title: "Advanced SIEM Logs & Alert Tuning",
      skill: "SIEM Systems",
      lectureUrl: "https://cheatsheetseries.owasp.org/cheatsheets/Logging_Vocabulary_Cheat_Sheet.html",
      labDesc: "[SIEM ALERTS REGISTRY LAB]\nWrite correlation rules to group distributed port scans and alert engineers when a web exploit succeeds.",
      labInst: "1. Use 'nmap' to trace ingress protocols.\n2. Type 'exploit' to run a mock exploit attempt that triggers alerts.\n3. Execute 'readflag' to claim the flag.",
      q: "What is the primary benefit of log normalization in SIEM platforms?",
      opts: ["Compacting disk space", "Converting system logs to movies", "Mapping diverse proprietary fields into a standard unified schema", "Disabling active firewalls"],
      ans: 2,
      exp: "Log normalization converts diverse formats (JSON, Syslog, CSV) into standard schemas for fast querying."
    },
    {
      title: "Threat Hunting & Advanced Incident Response",
      skill: "Threat Hunting",
      lectureUrl: "https://cheatsheetseries.owasp.org/cheatsheets/Incident_Response_Cheat_Sheet.html",
      labDesc: "[THREAT HUNTING OPERATIONS]\nSearch endpoint records for sneaky privilege escalation patterns and malicious process spawns.",
      labInst: "1. Run 'ls' to see running system assets.\n2. Run 'exploit' to locate suspicious privilege execution paths.\n3. Run 'readflag' to finalize the hunt.",
      q: "What does an unexpected process executing from the 'C:\\Windows\\Temp\\' folder strongly indicate?",
      opts: ["Standard system background update", "Malicious executable seeking a globally writable directory path", "System web cache storage", "Automated disk defragmentation"],
      ans: 1,
      exp: "Writable folders like Temp are often abused by malware to evade file execution restrictions."
    }
  ],
  "ethical-hacking-basics": [
    {
      title: "Passive Reconnaissance & Nmap Discovery",
      skill: "Information Recon",
      lectureUrl: "https://nmap.org/book/man.html",
      labDesc: "[NMAP RECONNAISSANCE SANDBOX]\nMaster network mapping. Scan the simulated local server nodes to discover active services, ports, and banners.",
      labInst: "1. Run 'help' to review scouting commands.\n2. Execute 'nmap' to probe port configurations on the local range.\n3. Run 'readflag' to extract the local proof of validation.",
      q: "What is the primary purpose of an Nmap TCP SYN Stealth scan (-sS)?",
      opts: ["To establish a full TCP session handshake", "To avoid full handshake establishment to reduce logging footprint", "To encrypt target servers", "To shut down network adapters"],
      ans: 1,
      exp: "A SYN stealth scan aborts the connection handshake with a RST packet prior to full establishment."
    },
    {
      title: "OWASP Vulnerabilities & PortSwigger Exploitation",
      skill: "Web Pentesting",
      lectureUrl: "https://portswigger.net/web-security/all-topics",
      labDesc: "[WEB INJECTION & EXPLOIT LAB]\nInteract with the terminal web simulator, analyze input sanitization flaws, and exploit a basic injection vulnerability.",
      labInst: "1. Run 'nmap' to verify web service availability on port 80.\n2. Run 'exploit' to inject test parameters into the administrative panel.\n3. Run 'readflag' to view the security flag.",
      q: "What is the most effective programmatic defense against SQL injection attacks?",
      opts: ["Client-side form limits", "Using parameterized queries/prepared statements", "Hosting web applications inside public cloud storage", "Resetting database configurations daily"],
      ans: 1,
      exp: "Parameterized queries treat user input strictly as data, making it impossible to alter the SQL syntax structure."
    }
  ],
  "vapt": [
    {
      title: "Vulnerability Scanning & Port Auditing",
      skill: "Vulnerability Assessments",
      lectureUrl: "https://nmap.org/book/man.html",
      labDesc: "[VAPT PORT AUDITING PRACTICE]\nGenerate comprehensive vulnerability profiles by matching live service banners against known vulnerability CVE lists.",
      labInst: "1. Execute 'nmap' with aggressive scripting flags to check local open sockets.\n2. Run 'readflag' to print the CVE tracking key.",
      q: "What does VAPT stand for in modern offensive security industries?",
      opts: ["Virtual Access and Port Testing", "Vulnerability Assessment and Penetration Testing", "Verified Attack and Protection Tracking", "Volume and Path Threat Analysis"],
      ans: 1,
      exp: "VAPT stands for Vulnerability Assessment (identifying weaknesses) and Penetration Testing (actively exploiting them)."
    },
    {
      title: "Exploit Mitigation & Professional Report Writing",
      skill: "Penetration Testing",
      lectureUrl: "https://portswigger.net/web-security/all-topics",
      labDesc: "[EXPLOIT EXPLOITATION & MITIGATION LAB]\nLaunch local shell payloads, gain administrative privilege rights, and write a formal executive remediation outline.",
      labInst: "1. Run 'exploit' to spawn a privilege escalation script.\n2. Read local administrative variables.\n3. Execute 'readflag' to prove compromise.",
      q: "Which element is most vital to include in a formal VAPT executive report for corporate leadership?",
      opts: ["The exact hexadecimal memory dumps of all crashes", "A clear risk rating with prioritized, actionable technical remediation steps", "The favorite hacking tools of the auditor", "The list of standard open source license agreements"],
      ans: 1,
      exp: "Leadership teams need clear risk context (severity) paired with actionable, direct instructions to remediate findings."
    }
  ],
  "network-security-basics": [
    {
      title: "OSI Model & Packet Capture Auditing",
      skill: "Network Protocol Security",
      lectureUrl: "https://www.cloudflare.com/learning/network-layer/what-is-the-osi-model/",
      labDesc: "[WIRESHARK PACKET ANALYSIS SANDBOX]\nDissect MAC addresses, IP headers, and TCP flags. Find plain-text credential leaks in unencrypted network streams.",
      labInst: "1. Execute 'ls' to locate captured network pcap traces.\n2. Execute 'nmap' to map current gateway nodes.\n3. Execute 'readflag' to decode target packet streams.",
      q: "Which layer of the OSI model is responsible for logical IP routing and packet forwarding?",
      opts: ["Layer 2 (Data Link Layer)", "Layer 3 (Network Layer)", "Layer 4 (Transport Layer)", "Layer 7 (Application Layer)"],
      ans: 1,
      exp: "Layer 3 (Network Layer) is where logical IPv4/IPv6 addressing, subnetting, and router hops are handled."
    },
    {
      title: "Firewalls, VPNs & Demilitarized Zones",
      skill: "Firewall Configuration",
      lectureUrl: "https://cheatsheetseries.owasp.org/cheatsheets/Microservice_Security_Cheat_Sheet.html",
      labDesc: "[FIREWALL RULE ENGINEERING]\nConfigure firewall policies to block untrusted external subnets while allowing encrypted VPN tunneling and secure public HTTP access.",
      labInst: "1. Run 'nmap' to verify active firewall policies.\n2. Run 'exploit' to test policy blocks against unauthorized scanners.\n3. Run 'readflag' to claim the flag.",
      q: "What is the key functional difference between stateful and stateless firewalls?",
      opts: ["Stateful systems check packet sizes only", "Stateful firewalls track the full handshake status and session context of active connections", "Stateless firewalls only block public cloud routes", "Stateful systems require specialized fiber optic cables"],
      ans: 1,
      exp: "Stateful firewalls track current connection states, allowing return traffic for established handshakes to pass safely without separate inbound rules."
    }
  ],
  "cloud-security-basics": [
    {
      title: "Cloud Models & AWS/Azure Security",
      skill: "Cloud IAM Security",
      lectureUrl: "https://docs.aws.amazon.com/security/",
      labDesc: "[CLOUD LEAST-PRIVILEGE IAM AUDITING]\nReview permissive wildcard IAM policies and apply granular permissions, preventing unauthorized S3 storage deletions.",
      labInst: "1. View local policy JSONs with 'ls'.\n2. Run 'nmap' to trace API gateway endpoint paths.\n3. Execute 'readflag' to apply secure policy constraints.",
      q: "Under the Cloud Shared Responsibility Model, who is responsible for securing host server hypervisors?",
      opts: ["The end student", "The network administrator of the client company", "The Cloud Service Provider (CSP) like AWS/Azure/GCP", "The third-party compliance auditor"],
      ans: 2,
      exp: "CSPs are strictly responsible for securing underlying hardware, hypervisors, physical host facilities, and baseline virtualization networks."
    },
    {
      title: "Securing Cloud Storage & Object Buckets",
      skill: "S3 Storage Security",
      lectureUrl: "https://docs.aws.amazon.com/security/",
      labDesc: "[OBJECT BUCKET LOCKDOWN EXERCISE]\nConfigure storage bucket properties. Block public read routes and enforce server-side AES256 data encryption.",
      labInst: "1. Execute 'nmap' to check open cloud buckets.\n2. Execute 'exploit' to probe public directory exposures.\n3. Run 'readflag' to apply storage lockdown protocols.",
      q: "Which AWS S3 configuration is recommended to globally override permissive ACLs and block public data leakage?",
      opts: ["S3 Transfer Acceleration", "Block All Public Access", "Enable Versioning Only", "CORS Configuration Rule sets"],
      ans: 1,
      exp: "Enabling 'Block All Public Access' globally blocks external HTTP requests to bucket directories, regardless of object-level access permissions."
    }
  ],
  "cloud-security-advanced": [
    {
      title: "Container & Kubernetes Security Hardening",
      skill: "Kubernetes Hardening",
      lectureUrl: "https://kubernetes.io/docs/concepts/security/",
      labDesc: "[KUBERNETES SECURE PARSING LAB]\nReview container deployments. Block privileged execution modes and enforce read-only root filesystems inside pods.",
      labInst: "1. Run 'ls' to identify YAML deployments.\n2. Use 'nmap' to trace internal API ports.\n3. Execute 'readflag' to patch deployments and claim the flag.",
      q: "In Kubernetes, what is the major risk of launching a pod with 'hostNetwork: true' enabled?",
      opts: ["It decreases cluster replication speeds", "It isolates the container entirely from other nodes", "It grants the pod access to the host's loopback and network interfaces, bypassing standard namespace isolation", "It limits the pod to public clouds"],
      ans: 2,
      exp: "Setting hostNetwork to true exposes the host's network interfaces directly to the container, bypassing isolation and exposing the host machine's ports."
    },
    {
      title: "Cloud Posture (CSPM) & CI/CD Pipeline Security",
      skill: "CSPM & DevSecOps",
      lectureUrl: "https://kubernetes.io/docs/concepts/security/",
      labDesc: "[DEVSECOPS PIPELINE HARDENING]\nIntegrate automated security scan steps (SAST/DAST) in a simulated GitHub Actions pipeline file, blocking compromised container pushes.",
      labInst: "1. Execute 'exploit' to start a mock pipeline test.\n2. Execute 'readflag' to extract pipeline compliance hash.",
      q: "What is the primary role of Cloud Security Posture Management (CSPM) tools?",
      opts: ["To optimize network latency", "To continuously scan cloud tenants for configuration drifts, compliance violations, and over-privileged accounts", "To backup local storage clusters", "To automate payroll records"],
      ans: 1,
      exp: "CSPM platforms continuously audit cloud configurations against frameworks (CIS benchmarks, PCI) to locate misconfigurations."
    }
  ],
  "basic-forensics-internship": [
    {
      title: "Forensic Acquisition & Hash Verification",
      skill: "Forensic Acquisition",
      lectureUrl: "https://csrc.nist.gov/publications/detail/sp/800-86/final",
      labDesc: "[FORENSIC IMAGE ACQUISITION DRILL]\nLearn to use hardware write-blockers. Verify bit-stream image duplicates by computing MD5 and SHA-256 integrity checksums.",
      labInst: "1. Type 'ls' to locate image file segments.\n2. Run 'nmap' to check file headers.\n3. Run 'readflag' to compute hash states and verify integrity.",
      q: "Why is a cryptographic hash (MD5 or SHA-256) calculated during forensic disk acquisition?",
      opts: ["To encrypt the suspect drive", "To verify absolute mathematical integrity of the duplicate image against the original disk", "To compress unallocated space", "To speed up LAN transfer rates"],
      ans: 1,
      exp: "Matching hash values prove mathematically that the forensic image is identical to the original drive and has not been altered."
    },
    {
      title: "File Recovery & Chain of Custody Documentation",
      skill: "Data Carving",
      lectureUrl: "https://csrc.nist.gov/publications/detail/sp/800-86/final",
      labDesc: "[FILE CARVING & LOGISTICS LAB]\nAnalyze disk partition structures to recover deleted text logs. Draft a standard chain of custody document.",
      labInst: "1. Run 'exploit' to search directory clusters.\n2. Run 'readflag' to output the recovered text flag.",
      q: "What does an interrupted or undocumented Chain of Custody record typically result in?",
      opts: ["Automated drive formatting", "The evidence being ruled inadmissible in a court of law", "The target workstation shutting down", "Loss of laboratory power"],
      ans: 1,
      exp: "An undocumented or broken Chain of Custody raises contamination and tampering risks, rendering evidence inadmissible in court."
    }
  ],
  "digital-forensics-basics": [
    {
      title: "Introduction to Digital Evidence & Hash Integrity",
      skill: "Evidence Integrity",
      lectureUrl: "https://csrc.nist.gov/publications/detail/sp/800-86/final",
      labDesc: "[EVIDENCE VERIFICATION LAB]\nVerify forensic raw files against tampering. Apply checksum validation rules across storage disk images.",
      labInst: "1. Type 'ls' to verify files.\n2. Type 'nmap' to scan filesystem endpoints.\n3. Run 'readflag' to capture verification hash.",
      q: "Which mathematical function creates a fixed-size fingerprint of a file, widely used for evidence integrity verification?",
      opts: ["Symmetric encryption", "Cryptographic hash function (e.g., SHA-256)", "Asymmetric key exchange", "File system indexing"],
      ans: 1,
      exp: "Cryptographic hash functions produce a unique, deterministic fingerprint of a file's contents, ensuring any modification can be immediately spotted."
    },
    {
      title: "NTFS Filesystem Carving & Master File Table",
      skill: "Filesystem Analysis",
      lectureUrl: "https://csrc.nist.gov/publications/detail/sp/800-86/final",
      labDesc: "[NTFS ANALYSIS CHASSIS]\nParse the Master File Table (MFT) to find hidden administrative metadata and map file allocation indexes.",
      labInst: "1. Use 'exploit' to scan disk structures.\n2. Run 'readflag' to extract directory records.",
      q: "What is the primary role of the Master File Table (MFT) in NTFS filesystems?",
      opts: ["To route IP packets", "To act as a database storing detailed metadata about every file and folder in the partition", "To encrypt user password directories", "To cache DNS requests"],
      ans: 1,
      exp: "The MFT is the structural heart of NTFS, holding metadata (timestamps, sizes, pointers to storage clusters) for every file/folder."
    }
  ],
  "digital-forensics": [
    {
      title: "Advanced Memory Forensics & RAM Analysis",
      skill: "Memory Forensics",
      lectureUrl: "https://github.com/volatilityfoundation/volatility/wiki",
      labDesc: "[VOLATILITY MEMORY FORENSICS PRACTICE]\nLoad a RAM dump in Volatility. Isolate running processes, trace active network connections, and dump plain-text password cache files.",
      labInst: "1. Type 'ls' to see RAM capture segments.\n2. Execute 'nmap' to trace suspect IP records.\n3. Type 'readflag' to query Volatility processes and print the flag.",
      q: "Which volatile storage space contains active cryptographic keys, network connections, and unencrypted browser history in a live computer?",
      opts: ["Hard disk drive (HDD) partition", "Random Access Memory (RAM)", "BIOS system cache", "Solid State Drive unallocated block"],
      ans: 1,
      exp: "RAM contains active operating states, transient keys, running process structures, and socket connections."
    },
    {
      title: "Prefetch, Registry, & Timeline Super-Timelines",
      skill: "Timeline Forensic Analysis",
      lectureUrl: "https://github.com/volatilityfoundation/volatility/wiki",
      labDesc: "[WINDOWS TIMELINE FORENSICS CHASSIS]\nAnalyze Prefetch (.pf) files, Registry hives, and shimcaches to reconstruct a minute-by-minute timeline of a cyber break-in.",
      labInst: "1. Run 'exploit' to parse Prefetch directories.\n2. Execute 'readflag' to compile findings.",
      q: "Which Windows artifact logs the execution count, timestamps, and associated DLLs of binary programs run on a machine?",
      opts: ["Pagefile.sys", "Prefetch (.pf) files", "Master File Table", "Host hosts file"],
      ans: 1,
      exp: "Windows Prefetch files (.pf) track execution history to improve startup speeds."
    }
  ],
  "grc": [
    {
      title: "ISO/IEC 27001 Standards & Risk Ratings",
      skill: "Information Governance",
      lectureUrl: "https://csrc.nist.gov/projects/risk-management/about-rmf",
      labDesc: "[RISK APPRAISAL WORKSPACE]\nDevelop a comprehensive asset risk register. Calculate Single Loss Expectancy (SLE) and Annual Loss Expectancy (ALE) for servers.",
      labInst: "1. Use 'ls' to review policy spreadsheets.\n2. Type 'nmap' to map assets.\n3. Run 'readflag' to record risks and get the flag.",
      q: "Under ISO 27001 standards, what is the primary role of the Statement of Applicability (SoA)?",
      opts: ["To manage company payroll accounts", "To identify selected/excluded Annex A security controls and justify those decisions", "To register physical hardware coordinates", "To format backup schedules"],
      ans: 1,
      exp: "The SoA links business risk assessments directly with the active technical security controls implemented."
    },
    {
      title: "Compliance Frameworks (GDPR, PCI, NIST)",
      skill: "Corporate Compliance",
      lectureUrl: "https://gdpr-info.eu/",
      labDesc: "[COMPLIANCE CONTROLS ASSESSMENT]\nPerform gap analysis matching NIST SP 800-53 security controls against database encryption standards to ensure regulatory compliance.",
      labInst: "1. Execute 'exploit' to start compliance checker.\n2. Execute 'readflag' to collect compliance report hash.",
      q: "Which core compliance framework strictly regulates consumer credit card processing, requiring quarterly scans and strict network segment isolation?",
      opts: ["GDPR Privacy Regulation", "PCI-DSS Security Standard", "HIPAA Health Insurance Portability Act", "NIST Risk Management Framework"],
      ans: 1,
      exp: "PCI-DSS enforces security requirements for any organization that stores, processes, or transmits cardholder data."
    }
  ]
};

const generateModulesAndLessons = (
  trackId: string, 
  skills: string[], 
  weeks: number
): Module[] => {
  const modules: Module[] = [];
  const syllabi = COURSE_SYLLABI[trackId] || COURSE_SYLLABI["soc-basics"];
  
  for (let w = 1; w <= 2; w++) {
    const syllabus = syllabi[w - 1];
    
    const lessons: Lesson[] = [
      {
        id: `${trackId}-w${w}-theory`,
        title: `Lecture: ${syllabus.title} Fundamentals`,
        type: "video",
        duration: "15 mins",
        contentUrl: syllabus.lectureUrl,
        isFree: true
      },
      {
        id: `${trackId}-w${w}-lab-1`,
        title: `TryHackMe — ${syllabus.skill} Practice Room`,
        type: "lab",
        duration: "1 hr",
        labDescription: `Hands-on practice room mapped from TryHackMe for ${syllabus.skill}. This offers a realistic simulated enterprise environment to practice ${syllabus.title} skills.`,
        labInstructions: `1. Open the external TryHackMe learning room.\n2. Apply passive scan techniques.\n3. Locate system anomalies and submit the correct flag to proceed: flag{${trackId}_compromised_node_99}`,
        isFree: true
      },
      {
        id: `${trackId}-w${w}-lab-2`,
        title: `PortSwigger — ${syllabus.skill} Vulnerability Lab`,
        type: "lab",
        duration: "1.5 hr",
        labDescription: `Interactive application security lab hosted by PortSwigger for ${syllabus.skill}. Discover specific configuration vulnerabilities side-by-side with theory.`,
        labInstructions: `1. Log into your free PortSwigger Academy account.\n2. Execute sandbox vulnerability probes.\n3. Obtain the compliance hash: flag{${trackId}_compromised_node_99}`,
        isFree: true
      },
      {
        id: `${trackId}-w${w}-lab-3`,
        title: `PatchWire — ${syllabus.title} Custom Sandbox`,
        type: "lab",
        duration: "45 mins",
        labDescription: syllabus.labDesc,
        labInstructions: syllabus.labInst,
        isFree: true
      },
      {
        id: `${trackId}-w${w}-quiz`,
        title: `Verification Exam: ${syllabus.title}`,
        type: "quiz",
        duration: "10 mins",
        isFree: true,
        quizQuestions: [
          {
            id: `${trackId}-w${w}-q1`,
            question: syllabus.q,
            options: syllabus.opts,
            correctAnswerIndex: syllabus.ans,
            explanation: syllabus.exp
          }
        ]
      }
    ];

    modules.push({
      id: `${trackId}-mod-w${w}`,
      title: `Week ${w}: ${syllabus.skill} Core Module`,
      description: `Completely free hands-on labs, custom lectures, and interactive grading assessments for ${syllabus.skill}.`,
      lessons
    });
  }
  
  return modules;
};

export const CYBER_TRACKS: CourseTrack[] = TRACKS_METADATA.map((t) => {
  return {
    id: t.id,
    title: t.title,
    description: t.description,
    longDescription: t.longDescription,
    price: t.price,
    difficulty: t.difficulty,
    duration: `${t.durationWeeks} weeks`,
    skills: t.skills,
    modules: generateModulesAndLessons(t.id, t.skills, t.durationWeeks),
    careerOutcomes: [
      `${t.title} Specialist`,
      "Cyber Security Analyst",
      "SecOps Compliance Engineer",
      "Threat Mitigation Specialist"
    ],
    bannerImage: t.bannerImage,
    enrolledCount: Math.floor(Math.random() * 500) + 200
  };
});
