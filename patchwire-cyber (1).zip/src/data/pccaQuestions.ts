export interface PccaQuestion {
  id: string;
  domain: "Linux" | "Networking" | "SOC" | "Cloud" | "Python" | "Web Security" | "OSINT" | "Forensics" | "Threat Hunting" | "GRC" | "VAPT";
  q: string;
  options: string[];
  ans: number; // Index of the correct option
  explanation: string;
}

export const PCCA_DOMAINS = [
  "Linux",
  "Networking",
  "SOC",
  "Cloud",
  "Python",
  "Web Security",
  "OSINT",
  "Forensics",
  "Threat Hunting",
  "GRC",
  "VAPT"
] as const;

export const PCCA_QUESTIONS: PccaQuestion[] = [
  // LINUX (5 Questions)
  {
    id: "lin-1",
    domain: "Linux",
    q: "Which of the following commands displays active socket network connections and ports?",
    options: ["ls -la", "netstat -tuln", "chmod +x", "cat /etc/passwd"],
    ans: 1,
    explanation: "netstat with option -tuln lists TCP (-t), UDP (-u) listening (-l) ports with numeric (-n) addresses."
  },
  {
    id: "lin-2",
    domain: "Linux",
    q: "Which file contains mapped hash passwords for user credentials in standard Linux systems?",
    options: ["/etc/passwd", "/etc/shadow", "/etc/hosts", "/etc/resolv.conf"],
    ans: 1,
    explanation: "The /etc/shadow file contains secure user password hashes, which are only readable by the root user."
  },
  {
    id: "lin-3",
    domain: "Linux",
    q: "How do you recursively change file permissions to read, write, and execute for the owner, and read/execute for others in an directory?",
    options: ["chmod -R 755 dir", "chmod -R 644 dir", "chown -R 755 dir", "chmod 777 dir"],
    ans: 0,
    explanation: "755 gives rwx (7) to owner and rx (5) to group/others. -R is recursive."
  },
  {
    id: "lin-4",
    domain: "Linux",
    q: "What does the 'S' bit (SUID) on an executable file permission set in Linux mean?",
    options: [
      "The file is encrypted",
      "The file runs with the privileges of the file owner rather than the user executing it",
      "The file is read-only for administrators",
      "The file belongs to system services only"
    ],
    ans: 1,
    explanation: "SUID (Set Owner User ID) allows users to execute binary files with the owner's permissions (usually root)."
  },
  {
    id: "lin-5",
    domain: "Linux",
    q: "Which directory stores system configuration files, such as network settings and service definitions, in Linux?",
    options: ["/var", "/opt", "/etc", "/usr"],
    ans: 2,
    explanation: "The /etc directory is dedicated to host-specific system configuration files."
  },

  // NETWORKING (5 Questions)
  {
    id: "net-1",
    domain: "Networking",
    q: "What protocol operates at Layer 4 of the OSI model to provide connection-oriented, reliable data delivery?",
    options: ["IP", "UDP", "TCP", "ICMP"],
    ans: 2,
    explanation: "TCP is connection-oriented and reliable, whereas UDP is connectionless and IP operates at Layer 3 (Network)."
  },
  {
    id: "net-2",
    domain: "Networking",
    q: "Which protocol is responsible for securing web traffic with end-to-end TLS encryption?",
    options: ["HTTP", "SSH", "HTTPS", "SFTP"],
    ans: 2,
    explanation: "HTTPS uses TLS/SSL over port 443 to encrypt HTTP traffic."
  },
  {
    id: "net-3",
    domain: "Networking",
    q: "Which port does standard secure shell (SSH) use for remote server command execution?",
    options: ["Port 80", "Port 22", "Port 443", "Port 21"],
    ans: 1,
    explanation: "SSH defaults to port 22. Port 80 is HTTP, 443 is HTTPS, 21 is FTP."
  },
  {
    id: "net-4",
    domain: "Networking",
    q: "What mechanism allows private IP addresses behind a router to map into a single public IP to access the internet?",
    options: ["DNS", "DHCP", "NAT (Network Address Translation)", "OSPF"],
    ans: 2,
    explanation: "NAT translates private IP ranges into globally routable public IPs to save address space."
  },
  {
    id: "net-5",
    domain: "Networking",
    q: "In an Ethernet frame header, what are the primary addresses used to route packets within the same local network switch?",
    options: ["IP Addresses", "MAC Addresses", "TCP Ports", "Subnet Masks"],
    ans: 1,
    explanation: "MAC (Media Access Control) addresses are Layer 2 physical addresses used by local switches."
  },

  // SOC (5 Questions)
  {
    id: "soc-1",
    domain: "SOC",
    q: "What type of platform aggregates log data from multiple network sources to provide real-time alerts and correlation dashboards?",
    options: ["Firewall", "SIEM (Security Information and Event Management)", "IDS", "Proxy"],
    ans: 1,
    explanation: "SIEM aggregates log data and correlates activities across security nodes."
  },
  {
    id: "soc-2",
    domain: "SOC",
    q: "What is the primary objective of a Security Operations Center analyst during the triage phase of an alert?",
    options: [
      "To completely rebuild the compromised asset",
      "To determine if the alert represents a true incident or a false positive",
      "To patch the zero-day exploit software",
      "To prosecute the malicious actor"
    ],
    ans: 1,
    explanation: "Triage is the immediate sorting of alerts to separate actual security threats (true positives) from noise (false positives)."
  },
  {
    id: "soc-3",
    domain: "SOC",
    q: "In the context of the MITRE ATT&CK framework, what do the columns typically represent?",
    options: ["Software names", "Threat actors", "Tactics (adversary goals)", "Defense products"],
    ans: 2,
    explanation: "Tactics in MITRE ATT&CK represent the 'why' or tactical objectives of attackers during a campaign."
  },
  {
    id: "soc-4",
    domain: "SOC",
    q: "Which event represents a true threat that was NOT caught or flagged by active security monitoring filters?",
    options: ["False Positive", "True Positive", "False Negative", "True Negative"],
    ans: 2,
    explanation: "A false negative is a security failure where malicious actions occur without generating any alarms."
  },
  {
    id: "soc-5",
    domain: "SOC",
    q: "Which incident response phase involves isolating infected systems from the corporate network to prevent malware from spreading?",
    options: ["Preparation", "Containment", "Eradication", "Lessons Learned"],
    ans: 1,
    explanation: "Containment isolates compromised devices (e.g., disconnecting from networks) to stop lateral propagation."
  },

  // CLOUD (5 Questions)
  {
    id: "cld-1",
    domain: "Cloud",
    q: "Under the Cloud Shared Responsibility Model, who is primarily responsible for securing customer data stored inside cloud databases?",
    options: ["Cloud Provider (e.g. AWS)", "The Customer (User)", "Third-party Auditors", "The internet service provider"],
    ans: 1,
    explanation: "The customer is always responsible for the security 'in' the cloud, which includes data, access controls, and configurations."
  },
  {
    id: "cld-2",
    domain: "Cloud",
    q: "What AWS service manages granular user access, access policies, and authentication permissions?",
    options: ["AWS S3", "AWS EC2", "AWS IAM (Identity & Access Management)", "AWS CloudTrail"],
    ans: 2,
    explanation: "IAM administers identity controls, policies, and permissions for AWS resources."
  },
  {
    id: "cld-3",
    domain: "Cloud",
    q: "What cloud security vulnerability is caused by granting wide-open, unauthenticated public read access to an Amazon S3 storage bucket containing corporate backups?",
    options: ["Cloud Misconfiguration", "SQL Injection", "Distributed Denial of Service", "Social Engineering"],
    ans: 0,
    explanation: "Misconfiguration, such as publicizing private buckets, is a primary driver of enterprise cloud data breaches."
  },
  {
    id: "cld-4",
    domain: "Cloud",
    q: "Which tool or platform class allows organizations to continuously audit cloud configurations against compliance benchmarks like CIS?",
    options: ["WAF", "CSPM (Cloud Security Posture Management)", "SIEM", "VPN"],
    ans: 1,
    explanation: "CSPM dynamically inspects cloud resources to identify compliance drifts and misconfigurations."
  },
  {
    id: "cld-5",
    domain: "Cloud",
    q: "What is the primary security risk of hardcoding AWS Access Keys directly inside client-side React code uploaded to a public GitHub repository?",
    options: [
      "The code won't compile",
      "Credential theft and total account compromise by scanners",
      "The server will experience CPU throttling",
      "GitHub will charge excess hosting fees"
    ],
    ans: 1,
    explanation: "Scanners continuously crawl public repositories for exposed API tokens and credentials, causing instant exploitation risks."
  },

  // PYTHON (4 Questions)
  {
    id: "py-1",
    domain: "Python",
    q: "Which Python standard library module is commonly used for interacting with HTTP endpoints, e.g., for security automation or web scraping?",
    options: ["os", "sys", "requests", "math"],
    ans: 2,
    explanation: "The requests module is a standard for crafting web requests and REST API communication in Python."
  },
  {
    id: "py-2",
    domain: "Python",
    q: "In a secure Python application, how should secret database credentials be loaded to prevent hardcoding vulnerabilities?",
    options: [
      "Direct string definition: db_pass = 'Admin123'",
      "Read from system environment variables via os.environ.get()",
      "Store inside public text documentation files",
      "Input directly from standard terminal logs"
    ],
    ans: 1,
    explanation: "Loading parameters via environment variables keeps secrets isolated from code repos."
  },
  {
    id: "py-3",
    domain: "Python",
    q: "What is the purpose of the 'socket' module in Python security scripts?",
    options: [
      "To perform filesystem scans",
      "To execute low-level network connections and port scanning",
      "To compile python code into binary",
      "To parse database tables"
    ],
    ans: 1,
    explanation: "The socket module provides raw TCP/IP socket operations, allowing network level connections, port scanning, and shell creation."
  },
  {
    id: "py-4",
    domain: "Python",
    q: "Which library is popular for parsing packet captures (PCAP) and craft custom TCP packets in Python?",
    options: ["Pandas", "Scapy", "Flask", "Django"],
    ans: 1,
    explanation: "Scapy is an extremely powerful interactive packet manipulation tool and library written in Python."
  },

  // WEB SECURITY (5 Questions)
  {
    id: "web-1",
    domain: "Web Security",
    q: "What vulnerability occurs when a web application takes user SQL input and joins it directly with a query without sanitization?",
    options: ["Cross-Site Scripting (XSS)", "SQL Injection (SQLi)", "CSRF", "BOLA"],
    ans: 1,
    explanation: "SQL Injection injects custom queries directly into backend databases, bypassing authentication and exposing data."
  },
  {
    id: "web-2",
    domain: "Web Security",
    q: "Which vulnerability allows an attacker to inject client-side scripts (usually JavaScript) into a web page viewed by other users?",
    options: ["SQL Injection", "Cross-Site Scripting (XSS)", "Buffer Overflow", "Command Injection"],
    ans: 1,
    explanation: "XSS executes custom scripts in victim browsers, allowing cookie theft or session hijacking."
  },
  {
    id: "web-3",
    domain: "Web Security",
    q: "What does the 'SameSite' attribute on cookie headers protect against?",
    options: ["SQLi", "XSS", "Cross-Site Request Forgery (CSRF)", "DDoS"],
    ans: 2,
    explanation: "SameSite restricts cookies from being transmitted during cross-site requests, mitigating CSRF attacks."
  },
  {
    id: "web-4",
    domain: "Web Security",
    q: "What OWASP Top 10 vulnerability occurs when an endpoint relies on raw database IDs in requests without checking if the user owns that resource?",
    options: ["BOLA / IDOR (Broken Object Level Authorization)", "XSS", "Security Misconfiguration", "SSRF"],
    ans: 0,
    explanation: "IDOR/BOLA happens when an application exposes a reference to an internal object without verifying authorization."
  },
  {
    id: "web-5",
    domain: "Web Security",
    q: "What does the 'HttpOnly' flag on cookies accomplish?",
    options: [
      "Restricts cookie transmissions to HTTPS only",
      "Prevents client-side scripts (JavaScript) from accessing the cookie",
      "Specifies cookie expiry dates",
      "Forces cookie routing to API servers only"
    ],
    ans: 1,
    explanation: "HttpOnly prevents JavaScript access to cookies, reducing session hijacking risks via XSS."
  },

  // OSINT (4 Questions)
  {
    id: "osi-1",
    domain: "OSINT",
    q: "What search technique uses advanced operators (like 'filetype:pdf' or 'site:*.in') to discover sensitive indexing on Google?",
    options: ["Social Engineering", "Google Dorking", "Port Scanning", "Packet Sniffing"],
    ans: 1,
    explanation: "Google Dorking leverages advanced search commands to uncover insecure files and credentials."
  },
  {
    id: "osi-2",
    domain: "OSINT",
    q: "Which search tool aggregates internet-connected IoT devices, webcams, industrial control nodes, and server banners?",
    options: ["GitHub", "Shodan", "Wikipedia", "VirusTotal"],
    ans: 1,
    explanation: "Shodan crawls global ports and indexing banners to map public-facing server stacks."
  },
  {
    id: "osi-3",
    domain: "OSINT",
    q: "What utility helps investigators check historical archive backups of live websites over the past decades?",
    options: ["Nmap", "Wayback Machine", "Wireshark", "Burp Suite"],
    ans: 1,
    explanation: "The Wayback Machine archives snapshots of historical web states."
  },
  {
    id: "osi-4",
    domain: "OSINT",
    q: "What is the primary risk of employees sharing high-resolution photos of their physical security badges or access desks on social networks?",
    options: [
      "Bad SEO mapping for the enterprise",
      "Social engineering weaponization and physical badge duplication",
      "Database downtime",
      "Loss of brand indexing"
    ],
    ans: 1,
    explanation: "Attackers can use visual identifiers to clone RFIDs or construct convincing pretexting plans."
  },

  // FORENSICS (4 Questions)
  {
    id: "for-1",
    domain: "Forensics",
    q: "What is the first step when handling an active crime-scene hard drive to ensure digital evidence integrity?",
    options: [
      "Boot into the OS and run virus checks",
      "Create a bit-stream physical image of the disk using write-blockers",
      "Reformat the drive to FAT32",
      "Upload the drive file-by-file to a cloud catalog"
    ],
    ans: 1,
    explanation: "Using physical write-blockers protects raw sectors while bit-streaming a forensic image duplicate (the 'working copy')."
  },
  {
    id: "for-2",
    domain: "Forensics",
    q: "What is the cryptographic hash of a digital evidence file used to establish in court?",
    options: ["Owner identity", "Integrity and Chain of Custody compliance (proving zero changes)", "Access speed", "File compression ratios"],
    ans: 1,
    explanation: "Comparing SHA256/MD5 hashes proves that evidence remained pristine during seizure and staging."
  },
  {
    id: "for-3",
    domain: "Forensics",
    q: "Which file system artifact tracks deleted folder names and file names in traditional NTFS Windows platforms?",
    options: ["MFT (Master File Table)", "Hosts file", "Windows Event log", "Pagefile.sys"],
    ans: 0,
    explanation: "The MFT records directory hierarchies, allocations, and timestamps for all files on NTFS partitions."
  },
  {
    id: "for-4",
    domain: "Forensics",
    q: "Which open-source tool allows analysts to analyze volatile computer RAM memory dumps?",
    options: ["Autopsy", "Volatility", "Wireshark", "Nmap"],
    ans: 1,
    explanation: "Volatility is the industry standard for reading system states directly out of raw memory captures."
  },

  // THREAT HUNTING (4 Questions)
  {
    id: "th-1",
    domain: "Threat Hunting",
    q: "What is the difference between Threat Hunting and standard Incident Response?",
    options: [
      "Threat Hunting is proactive and assumes systems are already compromised; IR is reactive after alerts trigger",
      "IR is automated while Threat Hunting is purely manual programming",
      "Threat Hunting is for administrative teams only",
      "Incident Response uses no firewall systems"
    ],
    ans: 0,
    explanation: "Threat hunting actively searches for hidden compromises that evaded security logging boundaries."
  },
  {
    id: "th-2",
    domain: "Threat Hunting",
    q: "What does the 'Apex' (the top) of David Bianco's Pyramid of Pain represent?",
    options: ["IP Addresses", "TTPs (Tactics, Techniques, and Procedures)", "File Hashes", "Domain Names"],
    ans: 1,
    explanation: "TTPs are the most difficult (painful) artifacts for threat actors to change when hunted."
  },
  {
    id: "th-3",
    domain: "Threat Hunting",
    q: "Which indicator type represents a historical cryptographic hash or known IP address linked directly to malware?",
    options: ["Indicator of Attack (IOA)", "Indicator of Compromise (IOC)", "Indicator of Threat (IOT)", "Privilege Drift"],
    ans: 1,
    explanation: "IOCs are reactive telemetry artifacts (e.g., file hashes, IP signatures) indicating historical system compromises."
  },
  {
    id: "th-4",
    domain: "Threat Hunting",
    q: "What system logs capture Process Creation events and command line parameters to catch lateral adversary actions?",
    options: ["Active Directory logs", "Sysmon Event ID 1", "Apache Access logs", "Kernel modules logs"],
    ans: 1,
    explanation: "Sysmon (System Monitor) ID 1 tracks process generation, capturing commands executed by malware."
  },

  // GRC (5 Questions)
  {
    id: "grc-1",
    domain: "GRC",
    q: "Which ISO/IEC standard is globally recognized for designing an Information Security Management System (ISMS)?",
    options: ["ISO 9001", "ISO 27001", "ISO 14001", "ISO 31000"],
    ans: 1,
    explanation: "ISO/IEC 27001 governs the strategy, policies, implementation, and continuous auditing of an ISMS."
  },
  {
    id: "grc-2",
    domain: "GRC",
    q: "What is the primary aim of a corporate Information Security Risk Assessment?",
    options: [
      "To eliminate 100% of all security risks entirely",
      "To identify, analyze, and evaluate security threats to align them with organizational risk appetite",
      "To purchase more security hardware",
      "To fire low performing employees"
    ],
    ans: 1,
    explanation: "Risks can never be zero; assessment helps organizations mitigate, transfer, avoid, or accept risks based on cost-benefit metrics."
  },
  {
    id: "grc-3",
    domain: "GRC",
    q: "Which European Union directive regulates user data privacy, consent, and details the 'Right to be Forgotten'?",
    options: ["PCI DSS", "GDPR", "HIPAA", "SOX"],
    ans: 1,
    explanation: "GDPR (General Data Protection Regulation) is the global gold standard for user privacy enforcement."
  },
  {
    id: "grc-4",
    domain: "GRC",
    q: "In risk assessment terms, what does the formula 'Risk = Threat x Vulnerability x Impact' help calculate?",
    options: ["Network bandwidth requirements", "Quantitative Risk Level", "Firewall rules density", "Server downtime counts"],
    ans: 1,
    explanation: "This formula models risk numerically/qualitatively by tracking threat frequency, vulnerability gaps, and operational impacts."
  },
  {
    id: "grc-5",
    domain: "GRC",
    q: "Which NIST framework is commonly adopted to structure Cyber Defense programs across critical infrastructure?",
    options: ["NIST CSF (Cybersecurity Framework)", "NIST SP 800-88", "NIST Quality Matrix", "ISO 27002"],
    ans: 0,
    explanation: "The NIST Cybersecurity Framework groups activities into Identify, Protect, Detect, Respond, and Recover categories."
  },

  // VAPT (5 Questions)
  {
    id: "vap-1",
    domain: "VAPT",
    q: "In penetration testing, what is the primary difference between a 'Vulnerability Assessment' and a 'Penetration Test'?",
    options: [
      "Assessments catalog weaknesses; Penetration tests actively exploit those gaps to assess damage scope",
      "Assessments use Linux only; Pentests use Windows only",
      "Assessments are purely manual; Pentests are purely automated",
      "There is no difference"
    ],
    ans: 0,
    explanation: "Vulnerability Assessments map known vulnerability gaps; Penetration Tests simulate actual hostile attacks to prove impact."
  },
  {
    id: "vap-2",
    domain: "VAPT",
    q: "What type of pentest occurs when the tester has absolute, zero prior knowledge of the target company's server network architecture?",
    options: ["White Box", "Black Box", "Grey Box", "Internal Audit"],
    ans: 1,
    explanation: "Black Box testing simulates external, unprivileged attacks where the tester has no maps, credentials, or documentation."
  },
  {
    id: "vap-3",
    domain: "VAPT",
    q: "Which Burp Suite feature acts as an intercepting HTTP proxy to manually edit browser headers and parameters in real-time?",
    options: ["Burp Scanner", "Burp Proxy", "Burp Intruder", "Burp Decoder"],
    ans: 1,
    explanation: "The Proxy tab intercepts HTTP/S requests, allowing security testers to alter payloads before they hit servers."
  },
  {
    id: "vap-4",
    domain: "VAPT",
    q: "What vulnerability occurs when a server takes a URL from user input and retrieves contents from it on the server's behalf, potentially exposing private local nodes?",
    options: ["Server-Side Request Forgery (SSRF)", "SQL Injection", "XSS", "IDOR"],
    ans: 0,
    explanation: "SSRF tricks servers into executing requests back to internal microservices or databases."
  },
  {
    id: "vap-5",
    domain: "VAPT",
    q: "What does the industry metric 'CVSS' stand for?",
    options: [
      "Computer Virus Scan Service",
      "Common Vulnerability Scoring System",
      "Cyber Verification Security Standard",
      "Critical Vault Storage Structure"
    ],
    ans: 1,
    explanation: "CVSS (Common Vulnerability Scoring System) is a standardized framework to quantify cybersecurity vulnerability severity."
  }
];

export function computePccaRecommendations(scores: Record<string, number>): {
  recommendedTrackId: string;
  recommendedBundleId: string;
  breakdown: Array<{ domain: string; correct: number; total: number; percent: number }>;
} {
  // Map questions to domains
  const domainTotals: Record<string, number> = {};
  const domainCorrect: Record<string, number> = {};

  PCCA_DOMAINS.forEach(d => {
    domainTotals[d] = 0;
    domainCorrect[d] = 0;
  });

  PCCA_QUESTIONS.forEach((q, idx) => {
    const answered = scores[idx];
    domainTotals[q.domain]++;
    if (answered === q.ans) {
      domainCorrect[q.domain]++;
    }
  });

  const breakdown = PCCA_DOMAINS.map(d => {
    const total = domainTotals[d] || 1;
    const correct = domainCorrect[d] || 0;
    return {
      domain: d,
      correct,
      total,
      percent: Math.round((correct / total) * 100)
    };
  });

  // Calculate recommendation
  // Let's find weakest domains or strongest ones
  const webScore = domainCorrect["Web Security"] || 0;
  const vaptScore = domainCorrect["VAPT"] || 0;
  const socScore = domainCorrect["SOC"] || 0;
  const grcScore = domainCorrect["GRC"] || 0;
  const forensicsScore = domainCorrect["Forensics"] || 0;
  const cloudScore = domainCorrect["Cloud"] || 0;

  let recommendedTrackId = "soc-basics"; // default beginner blue team
  let recommendedBundleId = "soc-grc-bundle";

  // Logic:
  if (vaptScore > 2 || webScore > 2) {
    recommendedTrackId = "vapt";
    recommendedBundleId = "red-team-bundle";
  } else if (cloudScore > 2) {
    recommendedTrackId = "cloud-security-advanced";
    recommendedBundleId = "ultimate-pack";
  } else if (forensicsScore > 2) {
    recommendedTrackId = "digital-forensics";
    recommendedBundleId = "red-team-bundle";
  } else if (grcScore > 2) {
    recommendedTrackId = "grc";
    recommendedBundleId = "soc-grc-bundle";
  } else if (socScore > 2) {
    recommendedTrackId = "soc-analyst";
    recommendedBundleId = "soc-grc-bundle";
  }

  return {
    recommendedTrackId,
    recommendedBundleId,
    breakdown
  };
}
