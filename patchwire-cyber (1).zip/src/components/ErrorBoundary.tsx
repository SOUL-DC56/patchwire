import React, { Component, ErrorInfo, ReactNode } from "react";
import { ShieldAlert, RefreshCw, Terminal, AlertTriangle } from "lucide-react";

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null
  };

  public static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught runtime error in PatchWire App:", error, errorInfo);
    this.setState({
      error,
      errorInfo
    });
  }

  private handleResetSystem = () => {
    // Clear potentially corrupted local session storage or state if needed, then reload
    try {
      localStorage.removeItem("pw_user");
    } catch (e) {
      console.error(e);
    }
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-300 flex items-center justify-center p-6 font-sans antialiased selection:bg-cyan-500/30 selection:text-white">
          {/* Cyberpunk background glows */}
          <div className="absolute top-0 left-1/4 w-[500px] h-[500px] rounded-full bg-rose-500/5 blur-[120px] pointer-events-none"></div>
          <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] rounded-full bg-cyan-500/5 blur-[150px] pointer-events-none"></div>

          <div className="max-w-2xl w-full glass-panel-heavy p-8 rounded-3xl border border-rose-500/30 shadow-2xl space-y-6 relative overflow-hidden">
            {/* Top warning line */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-rose-500 via-amber-500 to-rose-500"></div>

            <div className="flex items-center space-x-3.5 pb-4 border-b border-rose-500/10">
              <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-400 animate-pulse">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h1 className="font-display font-bold text-xl text-white uppercase tracking-wider">
                  SYSTEM DIAGNOSTIC OUTAGE // CRITICAL
                </h1>
                <p className="text-[10px] text-slate-400 font-mono block uppercase">
                  Operator Session Intercepted by Runtime Exception
                </p>
              </div>
            </div>

            <div className="space-y-4 text-left">
              <p className="text-sm text-slate-300 leading-relaxed">
                PatchWire SecOps kernel encountered a fatal exception during operation. The rendering engine failed to mount the designated viewport. Don't worry, your course progress remains safe.
              </p>

              {/* Collapsible Error Log Terminal */}
              <div className="bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden shadow-inner">
                <div className="bg-slate-900/40 px-4 py-2 border-b border-slate-900 flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-rose-400/80">
                    <Terminal className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-mono uppercase tracking-widest">Exception Logs Ledger</span>
                  </div>
                  <span className="text-[8px] font-mono text-slate-500 uppercase">Secure Core v1.4</span>
                </div>
                <div className="p-4 font-mono text-[11px] text-rose-300 max-h-60 overflow-y-auto space-y-2 leading-relaxed">
                  <div className="font-bold flex items-center space-x-1.5 text-amber-400">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>[SYS_EXCEPTION]: {this.state.error?.toString() || "Unknown Initialization Error"}</span>
                  </div>
                  {this.state.errorInfo && (
                    <pre className="text-slate-500 whitespace-pre-wrap text-[10px] bg-slate-950/50 p-2.5 rounded-lg border border-slate-900/40 mt-2">
                      {this.state.errorInfo.componentStack}
                    </pre>
                  )}
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-900">
              <button
                onClick={() => window.location.reload()}
                className="flex-1 py-3 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white font-sans font-semibold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Reboot Sandbox Viewport</span>
              </button>
              
              <button
                onClick={this.handleResetSystem}
                className="flex-1 py-3 bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-sans font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Factory Reset Operator Session</span>
              </button>
            </div>

            <div className="text-center pt-2">
              <span className="text-[9px] font-mono text-slate-600 uppercase tracking-widest">
                PATCHWIRE CYBERSECURITY INCIDENT RESPONSE PROTOCOL 2026
              </span>
            </div>
          </div>
        </div>
      );
    }

    // Class component requirement: "when referencing children properties in class components, use props.children instead of children."
    return this.props.children;
  }
}
