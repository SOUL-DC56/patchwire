import React from "react";
import { ShieldAlert, ShieldCheck, Mail, Globe, MapPin, Radio, Github, Twitter, Linkedin, MessageSquare } from "lucide-react";

interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full glass-panel border-t border-cyan-500/10 mt-auto bg-slate-950 px-4 py-12 md:px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-12">
        
        {/* BRAND & LOGO COLUMN */}
        <div className="md:col-span-1.5 flex flex-col space-y-4 text-left">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => onNavigate("home")}>
            <div className="p-1.5 rounded bg-cyan-950/40 border border-cyan-500/20">
              <ShieldCheck className="w-6 h-6 text-cyan-400" />
            </div>
            <span className="font-display font-bold text-lg tracking-wider text-white">
              PATCH<span className="text-cyan-400">WIRE</span> CYBER
            </span>
          </div>
          <p className="text-sm text-slate-400 font-sans leading-relaxed">
            Premium hand-crafted virtual cybersecurity internship tracks, mock penetration testing labs, and certified career acceleration programs for defense and offense groups.
          </p>
          {/* SOCIAL LINKS */}
          <div className="flex items-center space-x-3 pt-2">
            <a href="#github" className="p-2 bg-slate-900 border border-slate-800 hover:border-cyan-400 rounded transition-colors text-slate-400 hover:text-cyan-400">
              <Github className="w-4 h-4" />
            </a>
            <a href="#twitter" className="p-2 bg-slate-900 border border-slate-800 hover:border-cyan-400 rounded transition-colors text-slate-400 hover:text-cyan-400">
              <Twitter className="w-4 h-4" />
            </a>
            <a href="#linkedin" className="p-2 bg-slate-900 border border-slate-800 hover:border-cyan-400 rounded transition-colors text-slate-400 hover:text-cyan-400">
              <Linkedin className="w-4 h-4" />
            </a>
            <a href="#discord" className="p-2 bg-slate-900 border border-slate-800 hover:border-cyan-400 rounded transition-colors text-slate-400 hover:text-cyan-400">
              <MessageSquare className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* QUICK NAVIGATION */}
        <div className="text-left">
          <h4 className="font-display font-bold text-sm tracking-wider text-white uppercase border-b border-cyan-500/20 pb-2 mb-3">
            Learning Paths
          </h4>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={() => onNavigate("tracks")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Ethical Hacking
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("tracks")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                SOC Analyst (Blue Team)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("tracks")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Incident Response
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("pricing")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Internship Bundle Plans
              </button>
            </li>
          </ul>
        </div>

        {/* LEGAL PAGES */}
        <div className="text-left">
          <h4 className="font-display font-bold text-sm tracking-wider text-white uppercase border-b border-cyan-500/20 pb-2 mb-3">
            Legal & Trust
          </h4>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={() => onNavigate("legal")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Disclaimer
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("legal")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Privacy Policy
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("legal")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Terms & Conditions
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("legal")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Refund Policy
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("legal")} className="text-slate-400 hover:text-cyan-400 transition-colors text-left cursor-pointer">
                Acceptable Use Policy
              </button>
            </li>
          </ul>
        </div>

        {/* CONTACT INFO CARD */}
        <div className="text-left flex flex-col space-y-3">
          <h4 className="font-display font-bold text-sm tracking-wider text-white uppercase border-b border-cyan-500/20 pb-2 mb-3">
            Secure HQ
          </h4>
          <div className="flex items-start space-x-2 text-sm text-slate-400">
            <MapPin className="w-4 h-4 text-cyan-400 mt-1 shrink-0" />
            <span>Remote Location (Work From Home), India</span>
          </div>
          <div className="flex flex-col space-y-1.5 text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <Mail className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="font-mono text-[11px]" title="Company Main Email">admin@patchwirecyber.co.in</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="font-mono text-[11px]" title="Support Email">patchwire.support@gmail.com</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="font-mono text-[11px]" title="Founder Personal Email">piyushpattnaik3@gmail.com</span>
            </div>
            <div className="flex items-center space-x-2">
              <MessageSquare className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="font-mono text-[11px] text-cyan-400">7653905357 (WhatsApp Only)</span>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-sm text-slate-400 pt-1">
            <Radio className="w-4 h-4 text-cyan-400 shrink-0 animate-pulse" />
            <span className="font-mono text-xs text-cyan-400">SECURE SHELL PROTOCOL ACTIVE</span>
          </div>
        </div>

      </div>

      {/* DETAILED LEGAL MANDATED DISCLAIMER BANNER */}
      <div className="max-w-7xl mx-auto mt-10 pt-8 border-t border-slate-900 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        
        <div className="lg:col-span-8 p-4 rounded bg-cyan-950/15 border border-cyan-500/10 text-left">
          <div className="flex items-center space-x-2 mb-1">
            <ShieldAlert className="w-4 h-4 text-cyan-400" />
            <span className="font-display font-bold text-xs text-white uppercase tracking-wider">Ethical Compliance Mandate</span>
          </div>
          <p className="text-[11px] font-sans text-slate-400 leading-relaxed">
            <span className="text-cyan-400 font-semibold">Disclaimer:</span> PatchWire Cyber provides cybersecurity education and practical vulnerability environments for ethical learning and defense development purposes only. Users are strictly forbidden from attempting attacks, scans, or unauthorized actions against systems they do not explicitly own or have written, authenticated authorization to target. Students are fully responsible for complying with international cybersecurity regulations, including the Indian Information Technology Act, 2000.
          </p>
        </div>

        <div className="lg:col-span-4 text-left lg:text-right text-xs text-slate-500 flex flex-col space-y-1">
          <span>&copy; {currentYear} PatchWire Cyber. All rights reserved.</span>
          <span className="font-mono text-[10px]">VER: 4.1.1 // MD5: A30E401B2E0CF</span>
        </div>

      </div>
    </footer>
  );
}
