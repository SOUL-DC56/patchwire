import React, { useState } from "react";
import { 
  ShieldAlert, User as UserIcon, LogOut, LayoutDashboard, 
  Settings, Bell, Terminal, Trophy, MessageSquare, Menu, X, Code2
} from "lucide-react";
import { User, NotificationRecord } from "../types";

interface NavbarProps {
  user: User | null;
  currentPage: string;
  onNavigate: (page: string, params?: any) => void;
  notifications: NotificationRecord[];
  onLogout: () => void;
  onOpenAuth: () => void;
}

export default function Navbar({ 
  user, 
  currentPage, 
  onNavigate, 
  notifications, 
  onLogout,
  onOpenAuth 
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const unreadNotifs = notifications.filter(n => !n.isRead).length;

  const handleLinkClick = (page: string, params?: any) => {
    onNavigate(page, params);
    setMobileMenuOpen(false);
  };

  const navLinks = [
    { name: "Tracks", page: "tracks" },
    { name: "Pricing", page: "pricing" },
    { name: "About", page: "about" },
    { name: "FAQ", page: "faq" },
    { name: "Contact", page: "contact" }
  ];

  return (
    <nav className="sticky top-0 z-50 w-full glass-panel border-b border-cyan-500/10 px-4 py-3 md:px-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* LOGO */}
        <div 
          onClick={() => handleLinkClick("home")}
          className="flex items-center space-x-2 cursor-pointer group"
        >
          <div className="relative p-1.5 rounded bg-cyan-950/40 border border-cyan-400/30 group-hover:border-cyan-400 transition-colors">
            <ShieldAlert className="w-6 h-6 text-cyan-400 animate-pulse" />
          </div>
          <div>
            <span className="font-display font-bold text-lg md:text-xl tracking-wider text-white">
              PATCH<span className="text-cyan-400">WIRE</span>
            </span>
            <div className="text-[9px] font-mono tracking-widest text-slate-400 uppercase -mt-1 flex items-center">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-cyan-400 mr-1 animate-ping"></span>
              CYBER PLATFORM
            </div>
          </div>
        </div>

        {/* DESKTOP NAV */}
        <div className="hidden lg:flex items-center space-x-1">
          {navLinks.map((link) => (
            <button
              key={link.page}
              onClick={() => handleLinkClick(link.page)}
              className={`px-3.5 py-1.5 rounded-md font-sans text-sm font-medium transition-colors cursor-pointer ${
                currentPage === link.page 
                  ? "bg-cyan-950/50 text-cyan-400 border border-cyan-500/20" 
                  : "text-slate-300 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              {link.name}
            </button>
          ))}
        </div>

        {/* AUTHENTICATED / GUEST CONTROLS */}
        <div className="hidden lg:flex items-center space-x-3">
          {user ? (
            <div className="flex items-center space-x-2">
              {/* Leaderboard */}
              <button 
                onClick={() => handleLinkClick("leaderboard")}
                className="p-2 text-slate-300 hover:text-cyan-400 hover:bg-slate-900/40 rounded-full relative cursor-pointer"
                title="Leaderboard"
              >
                <Trophy className="w-5 h-5" />
              </button>

              {/* Forum */}
              <button 
                onClick={() => handleLinkClick("community")}
                className="p-2 text-slate-300 hover:text-cyan-400 hover:bg-slate-900/40 rounded-full relative cursor-pointer"
                title="Community Forums"
              >
                <MessageSquare className="w-5 h-5" />
              </button>

              {/* Notifications */}
              <button 
                onClick={() => handleLinkClick("notifications")}
                className="p-2 text-slate-300 hover:text-cyan-400 hover:bg-slate-900/40 rounded-full relative cursor-pointer"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifs > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-[10px] font-bold text-white rounded-full flex items-center justify-center animate-bounce">
                    {unreadNotifs}
                  </span>
                )}
              </button>

              {/* Dashboard */}
              <button 
                onClick={() => handleLinkClick("dashboard")}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-sm font-medium border cursor-pointer transition-colors ${
                  currentPage === "dashboard"
                    ? "bg-cyan-900/40 border-cyan-400 text-white"
                    : "border-cyan-500/20 text-cyan-400 hover:bg-cyan-950/30"
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Dashboard</span>
              </button>

              {/* User profile dropdown proxy */}
              <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
                <div 
                  onClick={() => handleLinkClick("profile")}
                  className="w-8 h-8 rounded-full border border-cyan-400/40 overflow-hidden bg-slate-900 cursor-pointer"
                  title="View Profile"
                >
                  <img 
                    src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100"} 
                    alt="avatar" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-xs font-semibold text-slate-200 truncate max-w-[100px]" title={user.name}>
                    {user.name}
                  </span>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase">
                    {user.role}
                  </span>
                </div>
              </div>

              {/* Admin Portal shortcut if Admin */}
              {user.role === "admin" && (
                <button 
                  onClick={() => handleLinkClick("admin")}
                  className="flex items-center space-x-1 px-3 py-1.5 bg-rose-950/40 border border-rose-500/30 text-rose-300 hover:text-white hover:border-rose-500 text-xs font-medium font-mono rounded cursor-pointer"
                >
                  <Terminal className="w-3.5 h-3.5 animate-pulse" />
                  <span>[ADMIN_PORTAL]</span>
                </button>
              )}

              {/* Logout */}
              <button 
                onClick={onLogout}
                className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-900/40 rounded-full cursor-pointer"
                title="Log Out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-sans text-sm font-semibold rounded-md hover:from-cyan-500 hover:to-blue-500 shadow-md hover:shadow-cyan-500/20 transition-all cursor-pointer flex items-center space-x-1.5"
            >
              <UserIcon className="w-4 h-4" />
              <span>Student Login</span>
            </button>
          )}
        </div>

        {/* MOBILE HAMBURGER BUTTON */}
        <div className="flex items-center lg:hidden space-x-2">
          {user && unreadNotifs > 0 && (
            <button 
              onClick={() => handleLinkClick("notifications")}
              className="p-1.5 text-rose-400 relative"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-rose-500 rounded-full"></span>
            </button>
          )}
          
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-400 hover:text-white bg-slate-900/50 rounded-md border border-slate-800"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

      </div>

      {/* MOBILE NAV DROPDOWN */}
      {mobileMenuOpen && (
        <div className="lg:hidden mt-3 p-4 rounded-lg bg-slate-950/95 border border-cyan-500/20 flex flex-col space-y-2.5 animate-in fade-in slide-in-from-top-3">
          {navLinks.map((link) => (
            <button
              key={link.page}
              onClick={() => handleLinkClick(link.page)}
              className={`w-full text-left px-3 py-2 rounded font-sans text-sm transition-colors ${
                currentPage === link.page 
                  ? "bg-cyan-950/40 text-cyan-400" 
                  : "text-slate-300 hover:bg-slate-900/40"
              }`}
            >
              {link.name}
            </button>
          ))}

          {user && (
            <div className="pt-2 border-t border-slate-800 flex flex-col space-y-2">
              <button
                onClick={() => handleLinkClick("dashboard")}
                className="w-full text-left px-3 py-2 rounded text-slate-300 hover:bg-slate-900/40 text-sm flex items-center space-x-2"
              >
                <LayoutDashboard className="w-4 h-4 text-cyan-400" />
                <span>My Dashboard</span>
              </button>

              <button
                onClick={() => handleLinkClick("community")}
                className="w-full text-left px-3 py-2 rounded text-slate-300 hover:bg-slate-900/40 text-sm flex items-center space-x-2"
              >
                <MessageSquare className="w-4 h-4 text-cyan-400" />
                <span>Community Forums</span>
              </button>

              <button
                onClick={() => handleLinkClick("leaderboard")}
                className="w-full text-left px-3 py-2 rounded text-slate-300 hover:bg-slate-900/40 text-sm flex items-center space-x-2"
              >
                <Trophy className="w-4 h-4 text-cyan-400" />
                <span>Leaderboard</span>
              </button>

              <button
                onClick={() => handleLinkClick("profile")}
                className="w-full text-left px-3 py-2 rounded text-slate-300 hover:bg-slate-900/40 text-sm flex items-center space-x-2"
              >
                <UserIcon className="w-4 h-4 text-cyan-400" />
                <span>My Profile</span>
              </button>

              {user.role === "admin" && (
                <button
                  onClick={() => handleLinkClick("admin")}
                  className="w-full text-left px-3 py-2 rounded bg-rose-950/30 text-rose-300 text-sm font-mono flex items-center space-x-2"
                >
                  <Terminal className="w-4 h-4" />
                  <span>[ADMIN_PORTAL]</span>
                </button>
              )}

              <button
                onClick={onLogout}
                className="w-full text-left px-3 py-2 rounded text-rose-400 hover:bg-rose-950/10 text-sm flex items-center space-x-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          )}

          {!user && (
            <button
              onClick={() => {
                onOpenAuth();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-center rounded font-sans text-sm font-semibold transition-colors"
            >
              Login / Sign Up
            </button>
          )}
        </div>
      )}
    </nav>
  );
}
