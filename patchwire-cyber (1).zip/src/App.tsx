import React, { useState, useEffect, useRef } from "react";
import { 
  ShieldAlert, ShieldCheck, Terminal, Flame, MessageSquare, Send, 
  X, HelpCircle, Lock, Mail, User as UserIcon, RefreshCw, Sparkles, Bell,
  Award, Trophy, Cpu
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { User, NotificationRecord } from "./types";
import { db } from "./lib/supabase";

// Import Layout Components
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

// Import Public Pages
import { 
  HomePage, PricingPage, AboutPage, ContactPage, FAQPage, LegalPages 
} from "./pages/PublicPages";

// Import Dashboard Pages
import { 
  DashboardPage, ProfilePage, CertificatePage, LeaderboardPage, CommunityPage, NotificationsPage 
} from "./pages/DashboardPages";

// Import Course Pages
import { 
  TracksCatalogPage, CourseDetailPage, CheckoutPage, AdminPortalPage 
} from "./pages/CoursePages";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<string>("home");
  const [pageParams, setPageParams] = useState<any>(null);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [activeUnlockedBadge, setActiveUnlockedBadge] = useState<any>(null);

  // Listen to global badge unlock events
  useEffect(() => {
    const handleBadgeUnlocked = (e: Event) => {
      const badge = (e as CustomEvent).detail;
      if (badge) {
        setActiveUnlockedBadge(badge);
      }
    };
    window.addEventListener("badge-unlocked", handleBadgeUnlocked);
    return () => {
      window.removeEventListener("badge-unlocked", handleBadgeUnlocked);
    };
  }, []);

  // Auth Modal state
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authRole, setAuthRole] = useState<"student" | "admin">("student");
  const [emailInput, setEmailInput] = useState("");
  const [nameInput, setNameInput] = useState("");
  const [authError, setAuthError] = useState("");

  // AI Chatbot State
  const [showChatbot, setShowChatbot] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{ role: "user" | "model"; text: string }>>([
    { role: "model", text: "Greetings, operator! I am Patchy AI, your tactical virtual SecOps instructor. For any content unavailability queries or payment/UTR validation issues, please message us directly on WhatsApp at 7653905357 (Strictly Message only, No Calls) or reach us at patchwire.support@gmail.com. Ask me anything about our fully remote learning tracks, labs, or career acceleration hub!" }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Initialize DB session
  useEffect(() => {
    const activeSessionUser = db.getCurrentUser();
    if (activeSessionUser) {
      setUser(activeSessionUser);
      setNotifications(db.getNotifications(activeSessionUser.id));
    }
  }, []);

  // Sync notifications periodically or when actions occur
  const reloadNotifications = () => {
    if (user) {
      setNotifications(db.getNotifications(user.id));
    }
  };

  useEffect(() => {
    reloadNotifications();
  }, [user, currentPage]);

  // Handle route navigation
  const handleNavigate = (page: string, params?: any) => {
    setCurrentPage(page);
    setPageParams(params || null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Auth Submissions
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;
    try {
      const authenticatedUser = db.login(emailInput, authRole);
      setUser(authenticatedUser);
      setShowAuthModal(false);
      setEmailInput("");
      setAuthError("");
      handleNavigate("dashboard");
    } catch (err: any) {
      setAuthError(err?.message || "Login configuration failed.");
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput || !nameInput) return;
    try {
      const authenticatedUser = db.register(nameInput, emailInput, authRole);
      setUser(authenticatedUser);
      setShowAuthModal(false);
      setEmailInput("");
      setNameInput("");
      setAuthError("");
      handleNavigate("dashboard");
    } catch (err: any) {
      setAuthError(err?.message || "Registration failed.");
    }
  };

  const handleLogout = () => {
    db.logout();
    setUser(null);
    handleNavigate("home");
  };

  // AI Assistant Chat Request
  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const userMsg = chatInput.trim();
    const updatedMessages = [...chatMessages, { role: "user" as const, text: userMsg }];
    setChatMessages(updatedMessages);
    setChatInput("");
    setIsChatLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg,
          history: chatMessages.slice(-6) // Send recent turns context
        })
      });

      const data = await response.json();
      if (response.ok && data.text) {
        setChatMessages([...updatedMessages, { role: "model" as const, text: data.text }]);
      } else {
        setChatMessages([...updatedMessages, { role: "model" as const, text: data.error || "I ran into a server communication timeout. Please verify configuration keys." }]);
      }
    } catch (err: any) {
      setChatMessages([...updatedMessages, { role: "model" as const, text: "The server AI service is offline or starting up. Try transmitting again shortly." }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Scroll Chat end ref
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages, isChatLoading]);

  // Render Current Page
  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage onNavigate={handleNavigate} />;
      case "about":
        return <AboutPage />;
      case "contact":
        return <ContactPage />;
      case "pricing":
        return <PricingPage onNavigate={handleNavigate} />;
      case "faq":
        return <FAQPage />;
      case "legal":
        return <LegalPages />;
      case "leaderboard":
        return <LeaderboardPage />;
      case "community":
        return <CommunityPage />;
      case "dashboard":
        return user ? <DashboardPage user={user} onNavigate={handleNavigate} /> : <HomePage onNavigate={handleNavigate} />;
      case "profile":
        return user ? <ProfilePage user={user} onNavigate={handleNavigate} /> : <HomePage onNavigate={handleNavigate} />;
      case "certificates":
        return user ? <CertificatePage user={user} onNavigate={handleNavigate} /> : <HomePage onNavigate={handleNavigate} />;
      case "notifications":
        return user ? <NotificationsPage user={user} /> : <HomePage onNavigate={handleNavigate} />;
      case "admin":
        return user && user.role === "admin" ? <AdminPortalPage /> : <HomePage onNavigate={handleNavigate} />;
      case "checkout":
        return user ? <CheckoutPage user={user} trackId={pageParams?.trackId} onNavigate={handleNavigate} /> : <HomePage onNavigate={handleNavigate} />;
      case "tracks":
        if (pageParams?.id) {
          return (
            <CourseDetailPage 
              user={user} 
              trackId={pageParams.id} 
              onNavigate={handleNavigate} 
              onOpenAuth={() => { setAuthMode("register"); setShowAuthModal(true); }}
            />
          );
        }
        return <TracksCatalogPage user={user} onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative bg-slate-950 font-sans text-slate-300 antialiased overflow-x-hidden">
      
      {/* Background decoration glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] rounded-full bg-cyan-500/5 blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] rounded-full bg-blue-500/5 blur-[150px] pointer-events-none"></div>

      {/* STICKY HEADER */}
      <Navbar 
        user={user} 
        currentPage={currentPage} 
        onNavigate={handleNavigate} 
        notifications={notifications} 
        onLogout={handleLogout} 
        onOpenAuth={() => { setAuthMode("login"); setShowAuthModal(true); }}
      />

      {/* CENTRAL DYNAMIC CORE VIEW */}
      <main className="flex-grow py-6 md:py-10">
        {renderPage()}
      </main>

      {/* FOOTER CODES */}
      <Footer onNavigate={handleNavigate} />

      {/* ==========================================
          AUTHENTICATION FLOW MODAL (LOGIN/REGISTER)
          ========================================== */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="glass-panel-heavy p-8 rounded-3xl w-full max-w-md relative overflow-hidden bg-slate-950 text-left border-2 border-cyan-500/20 scanline-container">
            <div className="absolute top-0 right-0 w-24 h-1 bg-cyan-400"></div>
            
            <button 
              onClick={() => { setShowAuthModal(false); setAuthError(""); }}
              className="absolute top-4 right-4 p-1.5 text-slate-500 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-6">
              <div className="flex items-center space-x-2">
                <Terminal className="w-5 h-5 text-cyan-400 animate-pulse" />
                <h3 className="font-display font-bold text-base text-white uppercase tracking-wider">
                  {authMode === "login" ? "ESTABLISH SECURE TERMINAL SESSION" : "REGISTER OPERATOR IDENTITY"}
                </h3>
              </div>

              {authError && (
                <div className="p-3 bg-rose-950/20 border border-rose-500/30 text-rose-300 text-xs rounded-xl font-mono">
                  [SYS_ERR: {authError}]
                </div>
              )}

              {/* ROLE SWITCH BUTTONS */}
              <div className="grid grid-cols-2 gap-2 bg-slate-900/60 p-1 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setAuthRole("student")}
                  className={`py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                    authRole === "student" ? "bg-cyan-950/60 text-cyan-400 border border-cyan-400/20" : "text-slate-400"
                  }`}
                >
                  Student Seat
                </button>
                <button
                  type="button"
                  onClick={() => setAuthRole("admin")}
                  className={`py-1.5 rounded-lg text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                    authRole === "admin" ? "bg-cyan-950/60 text-cyan-400 border border-cyan-400/20" : "text-slate-400"
                  }`}
                >
                  Admin Seat
                </button>
              </div>

              {/* FORMS */}
              {authMode === "login" ? (
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Operator Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <input 
                        type="email" 
                        required
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        placeholder="e.g. student@patchwire.cy"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl py-3 pl-11 pr-4 text-xs text-white focus:outline-none"
                      />
                    </div>
                    <p className="text-[9px] text-slate-500 font-sans">For demo, try: <span className="text-cyan-400 font-mono">student@patchwire.cy</span> or <span className="text-cyan-400 font-mono">admin@patchwire.cy</span></p>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                  >
                    Authenticate Terminal
                  </button>
                </form>
              ) : (
                <form onSubmit={handleRegisterSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Operator Full Name</label>
                    <div className="relative">
                      <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <input 
                        type="text" 
                        required
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        placeholder="e.g. Alex Mercer"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl py-3 pl-11 pr-4 text-xs text-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Operator Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <input 
                        type="email" 
                        required
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        placeholder="e.g. alex@mercer.cy"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl py-3 pl-11 pr-4 text-xs text-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                  >
                    Register Seat Key
                  </button>
                </form>
              )}

              {/* Toggle switch */}
              <div className="text-center">
                <button
                  type="button"
                  onClick={() => { setAuthMode(authMode === "login" ? "register" : "login"); setAuthError(""); }}
                  className="text-xs text-slate-400 hover:text-cyan-400 font-mono transition-colors cursor-pointer"
                >
                  {authMode === "login" ? "Create new Cryptographic key &rarr;" : "Already registered? Establish session &rarr;"}
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          GLOWING AI TERMINAL ASSISTANT FLOATING TOOL
          ========================================== */}
      <div className="fixed bottom-6 right-6 z-50">
        {showChatbot ? (
          <div className="glass-panel-heavy w-80 md:w-96 rounded-3xl overflow-hidden border-2 border-cyan-500/30 flex flex-col h-[480px] shadow-2xl relative bg-slate-950 scanline-container">
            {/* Header */}
            <div className="p-4 border-b border-cyan-500/10 flex items-center justify-between bg-slate-950/80">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 rounded bg-cyan-950 border border-cyan-400/20">
                  <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
                </div>
                <div className="text-left">
                  <span className="font-display font-bold text-xs text-white">PATCHY AI // SEC_INSTRUCTOR</span>
                  <span className="text-[9px] text-slate-500 font-mono block uppercase">Secure LLM Gateway</span>
                </div>
              </div>
              <button 
                onClick={() => setShowChatbot(false)}
                className="text-slate-500 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Support Banner */}
            <div className="bg-cyan-950/40 border-b border-cyan-500/15 px-4 py-2.5 text-left space-y-1 relative z-10">
              <span className="text-[9.5px] font-mono text-cyan-400 uppercase tracking-wider block font-bold">🚨 Urgent Help Desk Protocol</span>
              <p className="text-[10px] text-slate-300 leading-relaxed font-sans">
                For queries regarding <strong className="text-cyan-400">content unavailability</strong> or <strong className="text-cyan-400">payment issues</strong>, please message us on WhatsApp at <strong className="text-white font-mono">7653905357</strong> (Strictly No Calls) or email <strong className="text-white font-mono">patchwire.support@gmail.com</strong>.
              </p>
            </div>

            {/* Chat Messages */}
            <div className="flex-grow overflow-y-auto p-4 space-y-3 font-sans text-xs">
              {chatMessages.map((msg, index) => {
                const isModel = msg.role === "model";
                return (
                  <div key={index} className={`flex ${isModel ? "justify-start" : "justify-end"}`}>
                    <div className={`p-3 rounded-2xl max-w-[80%] leading-relaxed text-left ${
                      isModel 
                        ? "bg-slate-900 border border-slate-850 text-slate-200" 
                        : "bg-cyan-950/60 border border-cyan-500/20 text-white"
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                );
              })}
              {isChatLoading && (
                <div className="flex justify-start">
                  <div className="p-3 rounded-2xl bg-slate-900 border border-slate-850 text-slate-400 italic font-mono flex items-center space-x-1">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                    <span>Transmitting payload...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef}></div>
            </div>

            {/* Input Form */}
            <form onSubmit={handleSendChatMessage} className="p-3 border-t border-cyan-500/10 bg-slate-950 flex items-center gap-2">
              <input 
                type="text" 
                required
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask Patchy AI..."
                className="flex-grow bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none font-sans"
              />
              <button 
                type="submit"
                className="p-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        ) : (
          <button
            onClick={() => setShowChatbot(true)}
            className="p-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-full shadow-lg shadow-cyan-500/15 flex items-center justify-center cursor-pointer relative group border border-cyan-400/25 animate-bounce"
            title="Ask SecOps AI Assistant"
          >
            <MessageSquare className="w-6 h-6 shrink-0" />
            <span className="absolute right-full mr-3 px-2.5 py-1 bg-slate-950 border border-slate-800 rounded text-[9px] font-mono uppercase tracking-widest text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              Secure Chatbot
            </span>
          </button>
        )}
      </div>

      {/* ==========================================
          DYNAMIC BADGE UNLOCKED CELEBRATORY POPUP
          ========================================== */}
      <AnimatePresence>
        {activeUnlockedBadge && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.4, opacity: 0, rotateY: -90 }}
              animate={{ scale: 1, opacity: 1, rotateY: 0 }}
              exit={{ scale: 0.6, opacity: 0, rotateY: 90 }}
              transition={{ type: "spring", damping: 15, stiffness: 100 }}
              className="glass-panel-heavy p-8 rounded-3xl w-full max-w-lg text-center relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-cyan-950/40 border-2 border-cyan-400/40 shadow-[0_0_50px_rgba(34,211,238,0.25)] scanline-container"
            >
              {/* Background ambient lighting glows */}
              <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-48 h-48 bg-cyan-500/20 blur-[50px] pointer-events-none rounded-full"></div>
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"></div>

              {/* Decorative side brackets */}
              <div className="absolute top-4 left-4 font-mono text-[9px] text-slate-600">// ACHIEVEMENT_RECORD</div>
              <div className="absolute top-4 right-4 font-mono text-[9px] text-cyan-400/50">LEVEL_UP_TRIGGERED</div>

              <div className="space-y-6 pt-4">
                {/* Rotating holographic particle effect ring */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 15, ease: "linear" }}
                  className="w-24 h-24 rounded-full border border-dashed border-cyan-500/40 flex items-center justify-center mx-auto relative"
                >
                  <div className="absolute inset-2 rounded-full border border-cyan-400/10 animate-ping"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    {(() => {
                      const icon = activeUnlockedBadge.iconName;
                      if (icon === "Flame") return <Flame className="w-10 h-10 text-orange-400" />;
                      if (icon === "Award") return <Award className="w-10 h-10 text-amber-400" />;
                      if (icon === "ShieldCheck") return <ShieldCheck className="w-10 h-10 text-emerald-400" />;
                      if (icon === "Cpu") return <Cpu className="w-10 h-10 text-cyan-400" />;
                      if (icon === "Sparkles") return <Sparkles className="w-10 h-10 text-purple-400" />;
                      if (icon === "Trophy") return <Trophy className="w-10 h-10 text-yellow-400" />;
                      return <Award className="w-10 h-10 text-cyan-400" />;
                    })()}
                  </div>
                </motion.div>

                {/* Main Titles */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-mono font-bold tracking-[0.25em] text-cyan-400 uppercase block animate-pulse">
                    🏆 BADGE UNLOCKED SUCCESSFULLY
                  </span>
                  <h2 className="font-display font-black text-2xl text-white tracking-tight leading-none">
                    {activeUnlockedBadge.title}
                  </h2>
                </div>

                {/* Description and instructions */}
                <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-2xl relative">
                  <p className="text-slate-300 font-sans text-xs leading-relaxed">
                    {activeUnlockedBadge.description}
                  </p>
                  <div className="mt-2 text-[9px] font-mono text-slate-500 uppercase flex items-center justify-between">
                    <span>SECTOR_VERIFICATION: SECURE</span>
                    <span>XP AWARDED: +150 XP</span>
                  </div>
                </div>

                {/* Action CTA */}
                <button
                  onClick={() => {
                    setActiveUnlockedBadge(null);
                    // Force state refreshes
                    reloadNotifications();
                  }}
                  className="w-full py-3 bg-cyan-950 hover:bg-cyan-900/40 border border-cyan-400/30 hover:border-cyan-400 text-cyan-400 hover:text-white font-mono text-xs font-bold uppercase tracking-widest rounded-xl transition-all shadow-md shadow-cyan-950/50 cursor-pointer"
                >
                  [ ACKNOWLEDGE PROTOCOL ]
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
