import React, { useState, useEffect } from "react";
import { 
  Trophy, Award, BookOpen, Clock, ShieldCheck, Mail, User as UserIcon, 
  Terminal, Flame, Bell, Send, ThumbsUp, MessageSquare, Shield, Check, Plus, 
  Settings as SettingsIcon, LogOut, Lock, HelpCircle, ExternalLink, Printer, ArrowRight,
  Cpu, Sparkles
} from "lucide-react";
import { User, CourseTrack, Progress, Certificate, NotificationRecord, ForumPost, PaymentStatus, Badge } from "../types";
import { db } from "../lib/supabase";
import { CYBER_TRACKS } from "../data/tracks";

// ==========================================
// 1. DASHBOARD
// ==========================================
export function DashboardPage({ 
  user, 
  onNavigate 
}: { 
  user: User; 
  onNavigate: (page: string, params?: any) => void;
}) {
  const [enrolled, setEnrolled] = useState<CourseTrack[]>([]);
  const [pendingIds, setPendingIds] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);

  useEffect(() => {
    setEnrolled(db.getEnrolledTracks(user.id));
    setPendingIds(db.getPendingTrackIds(user.id));
    setNotifications(db.getNotifications(user.id).slice(0, 3));
  }, [user]);

  const getTrackProgress = (trackId: string) => {
    const prog = db.getProgress(user.id, trackId);
    const track = CYBER_TRACKS.find(t => t.id === trackId);
    if (!track) return 0;
    
    let totalLessonsCount = 0;
    track.modules.forEach(m => {
      totalLessonsCount += m.lessons.length;
    });

    if (totalLessonsCount === 0) return 0;
    return Math.round((prog.completedLessons.length / totalLessonsCount) * 100);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8 text-left">
      
      {/* WELCOME BACK BANNER */}
      <div className="glass-panel p-6 md:p-8 rounded-3xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6 bg-slate-950/30 scanline-container">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_left,rgba(6,182,212,0.1),transparent_50%)] pointer-events-none"></div>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 bg-cyan-950 border border-cyan-400/30 rounded text-[10px] font-mono uppercase text-cyan-400 tracking-wider">SECURE_TERMINAL_ONLINE</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          </div>
          <h1 className="font-display font-bold text-2xl md:text-3xl text-white">
            Welcome Back, <span className="text-cyan-400">{user.name}</span>
          </h1>
          <p className="text-xs text-slate-400 font-sans max-w-xl">
            You are currently authenticated in the PatchWire virtual network. Complete labs, submit system flags, and monitor your career certificates.
          </p>
        </div>

        {/* STATS BUBBLES */}
        <div className="flex items-center space-x-4">
          <div className="px-5 py-3 bg-slate-900/60 border border-slate-800 rounded-2xl text-center">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">My XP Rank</span>
            <div className="flex items-center justify-center space-x-1 mt-1">
              <Flame className="w-4 h-4 text-amber-500 animate-pulse" />
              <span className="font-display font-bold text-white text-lg">{user.xp}</span>
            </div>
          </div>
          <div className="px-5 py-3 bg-slate-900/60 border border-slate-800 rounded-2xl text-center">
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Enrolled Labs</span>
            <span className="font-display font-bold text-white text-lg block mt-1">
              {enrolled.length}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* ENROLLED TRACKS (LEFT COLUMN - 8 COLS) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-xl text-white flex items-center space-x-2">
              <Terminal className="w-5 h-5 text-cyan-400" />
              <span>Active Cybersecurity Tracks</span>
            </h2>
            <button 
              onClick={() => onNavigate("tracks")}
              className="text-xs text-cyan-400 hover:text-white font-mono font-semibold"
            >
              + Enroll in New Tracks
            </button>
          </div>

          {enrolled.length === 0 && pendingIds.length === 0 ? (
            <div className="glass-panel p-10 rounded-2xl text-center space-y-4">
              <BookOpen className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="font-display font-bold text-white text-lg">No Active Cyber Tracks</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                Unlock your first cybersecurity career internship track. Choose between Ethical Hacking, Incident Response, or SOC defense.
              </p>
              <button
                onClick={() => onNavigate("tracks")}
                className="px-5 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-sans text-xs font-semibold rounded-lg hover:from-cyan-500 hover:to-blue-500"
              >
                Browse Training Catalog
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Approved/Unlocked tracks */}
              {enrolled.map((track) => {
                const progress = getTrackProgress(track.id);
                return (
                  <div key={track.id} className="glass-panel rounded-2xl overflow-hidden hover:border-cyan-400/30 transition-all group flex flex-col justify-between">
                    <div className="p-5 space-y-4">
                      <div className="flex items-start justify-between">
                        <span className="px-2 py-0.5 bg-cyan-950/80 border border-cyan-400/20 text-cyan-400 font-mono text-[9px] uppercase rounded">
                          {track.difficulty}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono flex items-center space-x-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{track.duration}</span>
                        </span>
                      </div>

                      <h3 className="font-display font-bold text-base text-white group-hover:text-cyan-400 transition-colors">
                        {track.title}
                      </h3>

                      {/* Progress Bar */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[10px] font-mono">
                          <span className="text-slate-400">Internship Progress</span>
                          <span className="text-cyan-400 font-bold">{progress}%</span>
                        </div>
                        <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                          <div 
                            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-500"
                            style={{ width: `${progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-slate-950/40 border-t border-slate-900 flex items-center justify-between">
                      <span className="text-[10px] font-mono text-emerald-400 uppercase flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1"></span>
                        Access Unlocked
                      </span>
                      <button
                        onClick={() => onNavigate("tracks", { id: track.id })}
                        className="px-4 py-2 bg-cyan-950/40 border border-cyan-500/20 text-cyan-400 text-xs font-semibold rounded hover:bg-cyan-900/30 transition-all"
                      >
                        Launch Terminal
                      </button>
                    </div>
                  </div>
                );
              })}

              {/* Pending tracks */}
              {CYBER_TRACKS.filter(t => pendingIds.includes(t.id)).map((track) => (
                <div key={track.id} className="glass-panel rounded-2xl overflow-hidden border-yellow-500/10 bg-slate-950/10 flex flex-col justify-between opacity-80">
                  <div className="p-5 space-y-3">
                    <span className="px-2 py-0.5 bg-yellow-950/50 border border-yellow-500/20 text-yellow-500 font-mono text-[9px] uppercase rounded">
                      Verifying UPI
                    </span>
                    <h3 className="font-display font-bold text-base text-slate-400">{track.title}</h3>
                    <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                      Our SecOps group is cross-checking your UPI reference ID (UTR). Access unlocks as soon as ledger matches.
                    </p>
                  </div>
                  <div className="p-4 bg-slate-950/60 border-t border-slate-900/50 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-yellow-500 uppercase flex items-center animate-pulse">
                      ● PENDING MANUAL CHECK
                    </span>
                    <button
                      disabled
                      className="px-3 py-1.5 bg-slate-900 border border-slate-800 text-slate-600 text-xs font-semibold rounded cursor-not-allowed"
                    >
                      Locked
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ALERTS & SYSTEM ACTIVITY (RIGHT COLUMN - 4 COLS) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-lg text-white flex items-center space-x-2">
              <Bell className="w-5 h-5 text-cyan-400" />
              <span>Security Bulletins</span>
            </h2>
            <button 
              onClick={() => onNavigate("notifications")}
              className="text-xs text-slate-500 hover:text-cyan-400 font-mono"
            >
              See All
            </button>
          </div>

          <div className="glass-panel p-5 rounded-2xl space-y-4">
            {notifications.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">No bulletins received.</p>
            ) : (
              notifications.map((notif) => (
                <div key={notif.id} className="p-3 bg-slate-900/30 rounded-xl border border-slate-900 text-xs space-y-1 text-left relative pl-4">
                  <div className={`absolute left-0 top-3 bottom-3 w-1 rounded-full ${
                    notif.type === "success" ? "bg-emerald-500" :
                    notif.type === "alert" ? "bg-rose-500" :
                    notif.type === "warning" ? "bg-amber-500" : "bg-cyan-500"
                  }`}></div>
                  <div className="flex items-center justify-between">
                    <span className="font-display font-bold text-white">{notif.title}</span>
                    <span className="text-[9px] font-mono text-slate-500">
                      {new Date(notif.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-slate-400 leading-relaxed font-sans">{notif.message}</p>
                </div>
              ))
            )}
          </div>

          {/* Quick recommendations */}
          <div className="glass-panel p-5 rounded-2xl border border-cyan-400/5 bg-cyan-950/5 text-left space-y-4">
            <h3 className="font-display font-bold text-sm text-cyan-400">Security Recommendation</h3>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              Take the <span className="text-white font-semibold">Practical Cybersecurity Capability Assessment (PCCA)</span> to evaluate your skillset and match custom recommended tracks.
            </p>
            <button
              onClick={() => onNavigate("tracks")}
              className="w-full py-2 bg-cyan-950/60 border border-cyan-500/25 text-cyan-400 hover:text-white hover:bg-cyan-900/30 text-xs font-semibold rounded transition-colors cursor-pointer"
            >
              Launch PCCA Quiz
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

// ==========================================
// 2. PROFILE & ACHIVEMENTS
// ==========================================
function getBadgeIcon(iconName?: string) {
  switch (iconName) {
    case "Flame": return <Flame className="w-5 h-5 text-orange-400" />;
    case "Award": return <Award className="w-5 h-5 text-amber-400" />;
    case "ShieldCheck": return <ShieldCheck className="w-5 h-5 text-emerald-400" />;
    case "Cpu": return <Cpu className="w-5 h-5 text-cyan-400" />;
    case "Sparkles": return <Sparkles className="w-5 h-5 text-purple-400" />;
    case "Trophy": return <Trophy className="w-5 h-5 text-yellow-400" />;
    default: return <Award className="w-5 h-5 text-cyan-400" />;
  }
}

export function ProfilePage({ 
  user, 
  onNavigate 
}: { 
  user: User; 
  onNavigate?: (page: string, params?: any) => void;
}) {
  const [certs, setCerts] = useState<Certificate[]>([]);
  const [xpToNext, setXpToNext] = useState(1000);
  const [unlockedBadges, setUnlockedBadges] = useState<Badge[]>([]);

  useEffect(() => {
    const userCerts = db.getCertificates(user.id);
    setCerts(userCerts);
    
    // Fetch user's actual unlocked badges from our database
    const badgesList = db.getUnlockedBadges(user.id);
    
    // Keep dynamic fallback verification badge if they have high XP
    const hasVetting = badgesList.some(b => b.id === "vetting_candidate");
    if (user.xp > 500 && !hasVetting) {
      db.unlockBadge(
        user.id, 
        "vetting_candidate", 
        "Vetting Candidate", 
        "Completed a graded platform MCQ challenge with advanced scoring.", 
        "Award"
      );
    }
    
    setUnlockedBadges(db.getUnlockedBadges(user.id));
  }, [user]);

  const level = Math.floor(user.xp / 1000) + 1;
  const currentLevelXp = user.xp % 1000;
  const progressPercent = Math.min((currentLevelXp / 1000) * 100, 100);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-10 text-left">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* AVATAR CARD */}
        <div className="lg:col-span-4 flex flex-col space-y-6">
          <div className="glass-panel p-6 rounded-2xl text-center space-y-4">
            <div className="w-24 h-24 rounded-full border-2 border-cyan-400 overflow-hidden bg-slate-900 mx-auto">
              <img 
                src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
                alt="avatar" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="space-y-1">
              <h3 className="font-display font-bold text-lg text-white">{user.name}</h3>
              <p className="font-mono text-xs text-cyan-400 uppercase tracking-widest">{user.role} // LVL {level}</p>
            </div>

            {/* Experience progression bar */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span>XP Progression</span>
                <span>{currentLevelXp} / 1000 XP</span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-amber-500 to-rose-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
              <span className="text-[9px] text-slate-500 font-mono uppercase block text-right">Next Level unlocks at {1000 - currentLevelXp} XP</span>
            </div>
          </div>
        </div>

        {/* ACHIEVEMENTS AND ACCREDITATIONS (8 COLS) */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* BADGES ROW */}
          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg text-white flex items-center space-x-2 border-b border-slate-900 pb-2">
              <Trophy className="w-5 h-5 text-cyan-400" />
              <span>Cyber Achievements Badges</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {unlockedBadges.map((badge) => {
                const isUnlocked = !!badge.unlockedAt;
                return (
                  <div 
                    key={badge.id} 
                    className={`glass-panel p-5 rounded-2xl text-left flex flex-col justify-between space-y-3 relative overflow-hidden transition-all hover:border-cyan-500/30 ${
                      isUnlocked ? "border-cyan-500/20 bg-slate-950/20" : "opacity-40"
                    }`}
                  >
                    {!isUnlocked && (
                      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[1px] flex items-center justify-center z-10">
                        <Lock className="w-5 h-5 text-slate-500" />
                      </div>
                    )}
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        {getBadgeIcon(badge.iconName)}
                        <h4 className="font-display font-bold text-sm text-slate-200">{badge.title}</h4>
                      </div>
                      <p className="text-[11px] text-slate-400 font-sans leading-relaxed">{badge.description}</p>
                    </div>
                    {isUnlocked && (
                      <div className="flex items-center justify-between text-[9px] font-mono text-cyan-400">
                        <span>UNLOCKED</span>
                        <span>{new Date(badge.unlockedAt!).toLocaleDateString()}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* DIPLOMAS */}
          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg text-white flex items-center space-x-2 border-b border-slate-900 pb-2">
              <Award className="w-5 h-5 text-cyan-400" />
              <span>My Verified Certificates</span>
            </h3>

            {certs.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 glass-panel rounded-2xl space-y-4">
                <p>You have not completed any internship tracks yet. Unlock lessons and pass quizzes to claim your digital verification code.</p>
                {onNavigate && (
                  <button
                    onClick={() => onNavigate("tracks")}
                    className="px-4 py-2 bg-cyan-950 border border-cyan-400/30 hover:border-cyan-400 text-cyan-400 font-sans text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    Browse & Enroll in Tracks
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {certs.map((cert) => (
                  <div key={cert.id} className="glass-panel p-5 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <h4 className="font-display font-bold text-sm text-white">{cert.trackTitle}</h4>
                      <div className="flex items-center space-x-3 text-[10px] font-mono text-slate-400">
                        <span>Cert ID: {cert.id}</span>
                        <span>Issued: {cert.issueDate}</span>
                      </div>
                    </div>
                    <div className="text-xs text-emerald-400 font-mono font-bold flex items-center space-x-1.5 shrink-0 px-3 py-1.5 bg-emerald-950/30 border border-emerald-500/20 rounded-lg">
                      <ShieldCheck className="w-4 h-4" />
                      <span>VERIFIED GRD</span>
                    </div>
                  </div>
                ))}
                {onNavigate && (
                  <div className="pt-2">
                    <button
                      onClick={() => onNavigate("tracks")}
                      className="px-5 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans text-xs font-bold rounded-xl flex items-center space-x-1.5 shadow"
                    >
                      <span>Enroll in More Advanced Tracks</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}

// ==========================================
// 3. CERTIFICATE VIEWER & VERIFIER
// ==========================================
export function CertificatePage({ 
  user, 
  onNavigate 
}: { 
  user: User; 
  onNavigate?: (page: string, params?: any) => void;
}) {
  const [certs, setCerts] = useState<Certificate[]>([]);
  const [searchId, setSearchId] = useState("");
  const [verifiedRecord, setVerifiedRecord] = useState<Certificate | null>(null);
  const [errorText, setErrorText] = useState("");

  useEffect(() => {
    setCerts(db.getCertificates(user.id));
  }, [user]);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId) return;
    const match = db.getCertificateById(searchId.trim().toUpperCase());
    if (match) {
      setVerifiedRecord(match);
      setErrorText("");
    } else {
      setVerifiedRecord(null);
      setErrorText(`Certificate ID "${searchId}" could not be located in our ledger.`);
    }
  };

  const handlePrint = (id: string) => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12 text-left">
      <div className="text-center space-y-4">
        <h1 className="font-display font-bold text-3xl text-white">Digital <span className="text-cyan-400">Credentials</span> Registry</h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto leading-relaxed">
          Verify digital security diplomas, look up certificate identifiers, or print official academic accomplishments.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-5xl mx-auto">
        
        {/* LEFT COLUMN: CERTIFICATE LIST & PRINT DIRECT (7 COLS) */}
        <div className="lg:col-span-7 space-y-6">
          <h2 className="font-display font-bold text-lg text-white border-b border-slate-900 pb-2">My Diplomas</h2>
          
          {certs.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 glass-panel rounded-2xl">
              No active certificate registers found on your cryptographic user key.
            </div>
          ) : (
            <div className="space-y-8">
              {certs.map((cert) => (
                <div 
                  key={cert.id} 
                  id={`printable-cert-${cert.id}`}
                  className="glass-panel-heavy p-8 rounded-3xl relative overflow-hidden border-2 border-cyan-400/30 flex flex-col justify-between min-h-[460px] relative bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/20"
                >
                  {/* Decorative Guilloche Frame */}
                  <div className="absolute inset-4 border border-cyan-400/10 pointer-events-none rounded-2xl"></div>
                  
                  {/* Watermark Logo */}
                  <div className="absolute right-8 top-1/2 -translate-y-1/2 text-[100px] font-bold font-display text-cyan-400/5 select-none pointer-events-none">
                    PWC
                  </div>

                  {/* Header */}
                  <div className="flex items-center justify-between z-10">
                    <div className="flex items-center space-x-2">
                      <Shield className="w-8 h-8 text-cyan-400" />
                      <span className="font-display font-bold tracking-wider text-sm text-white">PATCHWIRE <span className="text-cyan-400">CYBER</span></span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 font-mono block uppercase">Ledger Index</span>
                      <span className="font-mono font-bold text-cyan-400 text-xs">{cert.id}</span>
                    </div>
                  </div>

                  {/* Body Statement */}
                  <div className="text-center space-y-3 z-10 my-4">
                    <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase">OFFICIAL CERTIFICATE OF GRADUATION</span>
                    <h3 className="font-display font-bold text-xl text-white">{cert.userName}</h3>
                    <p className="text-[11px] text-slate-400 max-w-md mx-auto leading-relaxed">
                      has successfully satisfied all practical laboratory targets, passed the cryptographic system challenges, and fully qualified for the career credential in
                    </p>
                    <h4 className="font-display font-bold text-base text-cyan-400 tracking-tight">{cert.trackTitle}</h4>

                    {/* Graded Assessment Scores Ledger Attachment */}
                    {cert.assessmentScores && Object.keys(cert.assessmentScores).length > 0 && (
                      <div className="mt-4 p-3 bg-slate-950/80 border border-slate-800 rounded-xl space-y-1.5 max-w-md mx-auto text-center z-10 relative">
                        <span className="text-[8px] font-mono tracking-widest text-cyan-400 uppercase block">// OFFICIAL GRADUATION SCORECARD //</span>
                        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[10px] font-mono text-left text-slate-400 max-h-24 overflow-y-auto">
                          {Object.entries(cert.assessmentScores).map(([title, score]) => (
                            <div key={title} className="flex justify-between border-b border-slate-900 pb-0.5">
                              <span className="truncate max-w-[130px] text-[9px]" title={title}>
                                {title.replace("Assessment: ", "").replace(" Verification Exam", "")}
                              </span>
                              <span className="text-emerald-400 font-bold">{score}%</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Footer */}
                  <div className="flex items-end justify-between z-10">
                    <div className="text-left">
                      <span className="text-[9px] text-slate-500 font-mono block uppercase">Verification Register</span>
                      <span className="text-[10px] text-slate-300 font-sans">{cert.qrCodeUrl.substring(0, 30)}...</span>
                    </div>
                    
                    <div className="text-right">
                      <span className="text-[9px] text-slate-500 font-mono block uppercase">Issue Date</span>
                      <span className="text-xs text-slate-300 font-sans">{cert.issueDate}</span>
                    </div>
                  </div>

                  {/* Print trigger overlay for UX */}
                  <div className="absolute top-3 right-24">
                    <button 
                      onClick={() => handlePrint(cert.id)}
                      className="p-2 bg-cyan-950/40 border border-cyan-400/20 hover:border-cyan-400 hover:text-white rounded text-cyan-400 flex items-center space-x-1 cursor-pointer text-[10px] font-mono uppercase"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Print Certificate</span>
                    </button>
                  </div>
                </div>
              ))}
              {onNavigate && (
                <div className="pt-4 flex justify-start">
                  <button 
                    onClick={() => onNavigate("tracks")}
                    className="px-5 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans text-xs font-bold rounded-xl flex items-center space-x-2 shadow-md shadow-cyan-500/15 cursor-pointer"
                  >
                    <span>🎓 Enroll in Next Internship Track</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: INDEPENDENT LEDGER VERIFIER (5 COLS) */}
        <div className="lg:col-span-5 space-y-6">
          <h2 className="font-display font-bold text-lg text-white border-b border-slate-900 pb-2">Verification Registry</h2>
          
          <div className="glass-panel p-6 rounded-2xl space-y-4">
            <h3 className="font-display font-bold text-sm text-white">Verify Certificate ID</h3>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Enter any PatchWire Cyber certificate ID to check its authentication record against our live ledger logs.
            </p>

            <form onSubmit={handleVerify} className="space-y-3">
              <input 
                type="text" 
                required
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                placeholder="e.g. PWC-2026-1002"
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none uppercase font-mono"
              />
              <button 
                type="submit"
                className="w-full py-2 bg-cyan-950 border border-cyan-500/30 hover:border-cyan-400 text-cyan-400 hover:text-white text-xs font-semibold rounded transition-colors"
              >
                Query Ledger Register
              </button>
            </form>

            {errorText && (
              <div className="p-3 bg-rose-950/20 border border-rose-500/20 text-rose-300 text-xs rounded-lg font-sans">
                {errorText}
              </div>
            )}

            {verifiedRecord && (
              <div className="p-4 bg-emerald-950/20 border border-emerald-500/30 text-emerald-300 text-xs rounded-lg space-y-3 font-mono">
                <div className="flex items-center space-x-1.5 text-emerald-400 font-bold uppercase text-[10px]">
                  <ShieldCheck className="w-4 h-4 animate-pulse" />
                  <span>[RECORD_FOUND: VERIFIED]</span>
                </div>
                <div className="space-y-1 pl-2 border-l border-emerald-500/20">
                  <p><span className="text-slate-500">Holder:</span> <span className="text-white">{verifiedRecord.userName}</span></p>
                  <p><span className="text-slate-500">Program:</span> <span className="text-white">{verifiedRecord.trackTitle}</span></p>
                  <p><span className="text-slate-500">Verified ID:</span> <span className="text-cyan-400">{verifiedRecord.id}</span></p>
                  <p><span className="text-slate-500">Graduation:</span> <span className="text-white">{verifiedRecord.issueDate}</span></p>
                </div>
                <span className="text-[9px] text-emerald-500/60 uppercase block text-right">// STATUS: INT RECOGNIZED CERTIFICATE</span>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}

// ==========================================
// 4. LEADERBOARD
// ==========================================
export function LeaderboardPage() {
  const [board, setBoard] = useState<any[]>([]);

  useEffect(() => {
    setBoard(db.getLeaderboard());
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-10 text-left">
      <div className="text-center space-y-4">
        <h1 className="font-display font-bold text-3xl text-white">Elite <span className="text-cyan-400">Operators</span> Leaderboard</h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto leading-relaxed">
          Monitor top cyber-minds transiting the virtual sandbox networks, ranked by XP achievements and laboratory compromises.
        </p>
      </div>

      <div className="max-w-4xl mx-auto glass-panel rounded-3xl overflow-hidden border border-slate-800">
        <table className="w-full text-left border-collapse text-xs md:text-sm">
          <thead>
            <tr className="bg-slate-900 border-b border-slate-800 font-mono text-[10px] text-cyan-400 uppercase tracking-wider">
              <th className="py-4 px-6">Rank</th>
              <th className="py-4 px-4">Operator</th>
              <th className="py-4 px-4 text-center">Labs Completed</th>
              <th className="py-4 px-4 text-center">Badges</th>
              <th className="py-4 px-6 text-right">XP score</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-900/60 font-sans text-slate-300">
            {board.map((student) => (
              <tr key={student.userId} className="hover:bg-slate-900/10 transition-colors">
                <td className="py-4 px-6 font-mono font-bold">
                  {student.rank === 1 ? <span className="text-amber-400">🥇 Gold</span> :
                   student.rank === 2 ? <span className="text-slate-400">🥈 Silver</span> :
                   student.rank === 3 ? <span className="text-amber-600">🥉 Bronze</span> :
                   <span>#{student.rank}</span>}
                </td>
                <td className="py-4 px-4 flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full border border-slate-800 overflow-hidden shrink-0 bg-slate-900">
                    <img src={student.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100"} alt="avatar" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="font-semibold text-slate-200 truncate max-w-[150px]" title={student.userName}>
                      {student.userName}
                    </span>
                  </div>
                </td>
                <td className="py-4 px-4 text-center font-mono text-cyan-400">{student.labsCompleted}</td>
                <td className="py-4 px-4 text-center font-mono">{student.badgesCount}</td>
                <td className="py-4 px-6 text-right font-display font-bold text-white">{student.xp} XP</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ==========================================
// 5. COMMUNITY FORUMS
// ==========================================
export function CommunityPage() {
  const channels = ["#general-discussion", "#lab-help", "#ctf-challenges", "#career-advice"];
  const [activeChan, setActiveChan] = useState("#general-discussion");
  const [posts, setPosts] = useState<ForumPost[]>([]);
  
  // Post states
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);

  // Reply states
  const [activePost, setActivePost] = useState<ForumPost | null>(null);
  const [replyContent, setReplyContent] = useState("");

  const loadPosts = () => {
    setPosts(db.getForumPosts(activeChan));
  };

  useEffect(() => {
    loadPosts();
  }, [activeChan]);

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newContent) return;
    db.createForumPost(activeChan, newTitle, newContent);
    setNewTitle("");
    setNewContent("");
    setShowAddForm(false);
    loadPosts();
  };

  const handleReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyContent || !activePost) return;
    const updated = db.addForumReply(activePost.id, replyContent);
    setReplyContent("");
    if (updated) {
      setActivePost(updated);
      loadPosts();
    }
  };

  const handleUpvote = (id: string) => {
    db.upvotePost(id);
    loadPosts();
    // Update active post view if open
    if (activePost && activePost.id === id) {
      setActivePost(prev => prev ? { ...prev, upvotes: prev.upvotes + 1 } : null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-10 text-left">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* CHANNELS PANEL (3 COLS) */}
        <div className="lg:col-span-3 space-y-4">
          <h2 className="font-display font-bold text-lg text-white border-b border-slate-900 pb-2">Channels</h2>
          <div className="flex flex-col space-y-1">
            {channels.map((chan) => (
              <button
                key={chan}
                onClick={() => { setActiveChan(chan); setActivePost(null); setShowAddForm(false); }}
                className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                  activeChan === chan 
                    ? "bg-cyan-950/50 text-cyan-400 border border-cyan-500/30 font-semibold" 
                    : "text-slate-400 hover:text-white hover:bg-slate-900/40"
                }`}
              >
                {chan}
              </button>
            ))}
          </div>
        </div>

        {/* POSTS FEED AND COMMENTS INTERACTION (9 COLS) */}
        <div className="lg:col-span-9 space-y-6">
          
          {/* Active Post Thread Detail */}
          {activePost ? (
            <div className="space-y-6">
              <button 
                onClick={() => setActivePost(null)}
                className="text-xs text-cyan-400 hover:text-white font-mono cursor-pointer"
              >
                &larr; Back to {activeChan} feed
              </button>

              <div className="glass-panel p-6 rounded-3xl space-y-4 text-left">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-900">
                    <img src={activePost.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100"} alt="avatar" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-xs text-white">{activePost.userName}</span>
                      <span className="px-1.5 py-0.5 bg-cyan-950 text-cyan-400 text-[8px] font-mono rounded uppercase">{activePost.userRole}</span>
                    </div>
                    <span className="text-[9px] text-slate-500 font-mono">{new Date(activePost.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <h3 className="font-display font-bold text-lg text-white">{activePost.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">{activePost.content}</p>

                <div className="flex items-center space-x-4 pt-3 border-t border-slate-900 text-xs">
                  <button 
                    onClick={() => handleUpvote(activePost.id)}
                    className="flex items-center space-x-1.5 text-slate-400 hover:text-cyan-400 transition-colors"
                  >
                    <ThumbsUp className="w-4 h-4" />
                    <span>{activePost.upvotes} Upvotes</span>
                  </button>
                </div>
              </div>

              {/* REPLIES ITERATOR */}
              <div className="space-y-4">
                <h4 className="font-display font-bold text-sm text-slate-300">Replies ({activePost.replies.length})</h4>
                
                {activePost.replies.length === 0 ? (
                  <p className="text-xs text-slate-500 font-sans pl-2">No replies yet. Solve the anomaly first.</p>
                ) : (
                  <div className="space-y-3">
                    {activePost.replies.map((rep) => (
                      <div key={rep.id} className="p-4 bg-slate-950/40 border border-slate-900 rounded-2xl text-left space-y-2 relative pl-12">
                        <div className="absolute left-3 top-4 w-7 h-7 rounded-full overflow-hidden bg-slate-900">
                          <img src={rep.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100"} alt="avatar" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2 text-[10px] font-mono">
                            <span className="font-semibold text-slate-300">{rep.userName}</span>
                            <span className="px-1.5 py-0.5 bg-slate-900 text-slate-400 text-[8px] rounded uppercase">{rep.userRole}</span>
                            <span className="text-slate-500 text-[9px]">{new Date(rep.createdAt).toLocaleDateString()}</span>
                          </div>
                          <p className="text-xs text-slate-300 leading-relaxed font-sans">{rep.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* POST REPLY FORM */}
              <form onSubmit={handleReply} className="space-y-3">
                <textarea 
                  rows={3}
                  required
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                  placeholder="Contribute to thread..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl p-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/30"
                />
                <button 
                  type="submit"
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-semibold rounded-lg flex items-center space-x-1"
                >
                  <Send className="w-3 h-3" />
                  <span>Reply</span>
                </button>
              </form>
            </div>
          ) : (
            // Feed list view
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="font-display font-bold text-xl text-white uppercase tracking-wider">{activeChan}</h2>
                <button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="px-3.5 py-2 bg-cyan-950 border border-cyan-500/30 text-cyan-400 hover:text-white hover:bg-cyan-900/30 text-xs font-mono rounded-lg flex items-center space-x-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Start Thread</span>
                </button>
              </div>

              {/* ADD NEW POST FORM */}
              {showAddForm && (
                <div className="glass-panel p-6 rounded-2xl bg-slate-950/40">
                  <form onSubmit={handleCreatePost} className="space-y-4 text-left">
                    <h3 className="font-display font-bold text-sm text-white">Publish New Cyber Topic</h3>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono text-slate-400 uppercase">Topic Title</label>
                      <input 
                        type="text" 
                        required
                        value={newTitle}
                        onChange={(e) => setNewTitle(e.target.value)}
                        placeholder="e.g. Nmap SYN scans filtered response help"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono text-slate-400 uppercase">Thread Content</label>
                      <textarea
                        rows={4}
                        required
                        value={newContent}
                        onChange={(e) => setNewContent(e.target.value)}
                        placeholder="Describe the research issue or question..."
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                      />
                    </div>
                    <div className="flex items-center space-x-3 pt-2">
                      <button 
                        type="submit"
                        className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-semibold rounded-lg"
                      >
                        Publish Topic
                      </button>
                      <button 
                        type="button"
                        onClick={() => setShowAddForm(false)}
                        className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-400 text-xs rounded-lg hover:text-white"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* POST LIST */}
              {posts.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 glass-panel rounded-2xl">
                  This channel is currently empty. Initiate communication.
                </div>
              ) : (
                <div className="space-y-4">
                  {posts.map((post) => (
                    <div 
                      key={post.id} 
                      className="glass-panel p-5 rounded-2xl hover:border-cyan-400/30 transition-all flex flex-col justify-between space-y-4 text-left group"
                    >
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-900">
                          <img src={post.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100"} alt="avatar" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="font-bold text-xs text-white">{post.userName}</span>
                            <span className="px-1.5 py-0.5 bg-cyan-950 text-cyan-400 text-[8px] font-mono rounded uppercase">{post.userRole}</span>
                          </div>
                          <span className="text-[9px] text-slate-500 font-mono">{new Date(post.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>

                      <div className="space-y-1 cursor-pointer" onClick={() => setActivePost(post)}>
                        <h3 className="font-display font-bold text-base text-slate-200 group-hover:text-cyan-400 transition-colors">
                          {post.title}
                        </h3>
                        <p className="text-xs text-slate-400 font-sans leading-relaxed line-clamp-2">
                          {post.content}
                        </p>
                      </div>

                      <div className="flex items-center space-x-6 pt-3 border-t border-slate-900/60 text-xs text-slate-400">
                        <button 
                          onClick={() => handleUpvote(post.id)}
                          className="flex items-center space-x-1.5 hover:text-cyan-400 transition-colors"
                        >
                          <ThumbsUp className="w-4 h-4" />
                          <span>{post.upvotes}</span>
                        </button>
                        <button 
                          onClick={() => setActivePost(post)}
                          className="flex items-center space-x-1.5 hover:text-cyan-400 transition-colors"
                        >
                          <MessageSquare className="w-4 h-4" />
                          <span>{post.replies.length} Replies</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
}

// ==========================================
// 6. NOTIFICATIONS FEED
// ==========================================
export function NotificationsPage({ user }: { user: User }) {
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);

  const loadNotifications = () => {
    setNotifications(db.getNotifications(user.id));
  };

  useEffect(() => {
    loadNotifications();
    // Mark as read when entering
    db.markNotificationsAsRead(user.id);
  }, [user]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8 text-left">
      <h1 className="font-display font-bold text-2xl text-white">System <span className="text-cyan-400">Notifications</span></h1>
      
      <div className="glass-panel p-6 rounded-3xl space-y-4">
        {notifications.length === 0 ? (
          <p className="text-xs text-slate-500 text-center py-10 font-mono">[SYS_RECORDS_EMPTY: NO NEW ALERTS]</p>
        ) : (
          <div className="divide-y divide-slate-900">
            {notifications.map((notif) => (
              <div key={notif.id} className="py-4 first:pt-0 last:pb-0 flex items-start space-x-4">
                <div className={`p-2.5 rounded-lg border shrink-0 ${
                  notif.type === "success" ? "bg-emerald-950/40 border-emerald-500/20 text-emerald-400" :
                  notif.type === "alert" ? "bg-rose-950/40 border-rose-500/20 text-rose-400" :
                  notif.type === "warning" ? "bg-amber-950/40 border-amber-500/20 text-amber-400" :
                  "bg-cyan-950/40 border-cyan-500/20 text-cyan-400"
                }`}>
                  <Bell className="w-4.5 h-4.5 animate-pulse" />
                </div>
                <div className="space-y-1 flex-grow">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="font-bold text-white">{notif.title}</span>
                    <span className="text-[10px] text-slate-500">
                      {new Date(notif.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">{notif.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
