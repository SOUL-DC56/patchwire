import React, { useState, useEffect } from "react";
import { 
  Terminal, ShieldCheck, Clock, Award, BookOpen, Key, AlertTriangle, 
  Play, FileText, CheckCircle, ChevronDown, ChevronRight, HelpCircle, 
  Send, QrCode, Upload, ArrowRight, ShieldAlert, CheckCircle2, User, 
  X, Image as ImageIcon, UserCheck, Flame, RefreshCw, Lock, ExternalLink
} from "lucide-react";
import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer 
} from "recharts";
import { CourseTrack, Lesson, QuizQuestion, Module, PaymentStatus, TrackDifficulty } from "../types";
import { db } from "../lib/supabase";
import { CYBER_TRACKS } from "../data/tracks";
import { PCCA_QUESTIONS, computePccaRecommendations } from "../data/pccaQuestions";

// ==========================================
// 1. TRACKS CATALOG & PCCA ASSESSMENT
// ==========================================
export function TracksCatalogPage({ 
  user, 
  onNavigate 
}: { 
  user: any; 
  onNavigate: (page: string, params?: any) => void;
}) {
  const [filterDifficulty, setFilterDifficulty] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [enrolledIds, setEnrolledIds] = useState<string[]>([]);
  const [pendingIds, setPendingIds] = useState<string[]>([]);

  // PCCA state
  const [showPcca, setShowPcca] = useState(false);
  const [pccaStep, setPccaStep] = useState(0);
  const [pccaAnswers, setPccaAnswers] = useState<number[]>([]);
  const [pccaResultData, setPccaResultData] = useState<{
    recommendedTrackId: string;
    recommendedBundleId: string;
    breakdown: Array<{ domain: string; correct: number; total: number; percent: number }>;
  } | null>(null);

  useEffect(() => {
    if (user) {
      setEnrolledIds(db.getEnrolledTracks(user.id).map(t => t.id));
      setPendingIds(db.getPendingTrackIds(user.id));
    }
  }, [user]);

  const handlePccaAnswer = (optIndex: number) => {
    const nextAnswers = [...pccaAnswers, optIndex];
    setPccaAnswers(nextAnswers);

    if (pccaStep < PCCA_QUESTIONS.length - 1) {
      setPccaStep(pccaStep + 1);
    } else {
      const scoreMap: Record<string, number> = {};
      nextAnswers.forEach((ansVal, qIdx) => {
        scoreMap[qIdx] = ansVal;
      });
      const rec = computePccaRecommendations(scoreMap);
      setPccaResultData(rec);
    }
  };

  const handleSimulateAssessment = () => {
    const simulatedAnswers: number[] = [];
    PCCA_QUESTIONS.forEach((q) => {
      // 70% chance of correct answer, 30% of random choice
      const isCorrect = Math.random() > 0.3;
      simulatedAnswers.push(isCorrect ? q.ans : Math.floor(Math.random() * q.options.length));
    });
    
    const scoreMap: Record<string, number> = {};
    simulatedAnswers.forEach((ansVal, qIdx) => {
      scoreMap[qIdx] = ansVal;
    });
    
    setPccaAnswers(simulatedAnswers);
    setPccaStep(PCCA_QUESTIONS.length - 1);
    const rec = computePccaRecommendations(scoreMap);
    setPccaResultData(rec);
  };

  const hasCiscoNetworkCompleted = user ? db.isTrackCompleted(user.id, "cisco-network-basics") : false;
  const hasCiscoCyberCompleted = user ? db.isTrackCompleted(user.id, "cisco-cyber-basics") : false;

  const filteredTracks = CYBER_TRACKS.filter(track => {
    // Exclude Cisco foundational tracks from standard catalog lists
    if (track.id === "cisco-cyber-basics" || track.id === "cisco-network-basics") {
      return false;
    }
    const matchesDiff = filterDifficulty === "All" || track.difficulty === filterDifficulty;
    const matchesSearch = track.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          track.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDiff && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12 text-left">
      
      {/* HEADER ROW */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <h1 className="font-display font-bold text-3xl text-white">Cybersecurity <span className="text-cyan-400">Internship tracks</span></h1>
          <p className="text-slate-400 text-sm max-w-xl">
            Acquire enterprise skills. Complete practical labs in our dynamic sandbox, earn Digital Certificates, and map your career roadmap.
          </p>
        </div>
        
        {/* PCCA Assessment Banner */}
        <button
          onClick={() => { setShowPcca(true); setPccaStep(0); setPccaAnswers([]); setPccaResultData(null); }}
          className="px-5 py-3 bg-cyan-950/40 border border-cyan-500/30 text-cyan-400 hover:text-white rounded-xl text-xs font-mono tracking-wider uppercase animate-pulse shrink-0 cursor-pointer"
        >
          [Launch Skills Assessment PCCA]
        </button>
      </div>

      {/* MANDATORY FOUNDATIONAL PREREQUISITES PANEL */}
      <div className="p-6 rounded-3xl border-2 border-dashed border-cyan-400/30 bg-slate-950/40 relative overflow-hidden space-y-4">
        <div className="absolute top-0 right-0 p-3 text-[9px] font-mono text-cyan-400/50 uppercase tracking-widest">FOUNDATIONAL_STAGE_01</div>
        <div className="space-y-1">
          <h2 className="font-display font-black text-sm text-white uppercase tracking-tight flex items-center gap-2">
            <span className="text-cyan-400">🔒 MANDATORY PRE-REQUISITES CORE</span>
            <span className="px-2 py-0.5 bg-cyan-950 text-cyan-400 border border-cyan-400/20 rounded text-[9px] font-mono font-bold uppercase tracking-wider">Required First</span>
          </h2>
          <p className="text-xs text-slate-400 font-sans leading-relaxed max-w-3xl">
            Under PatchWire Cyber security training standards, <strong className="text-slate-200">all students must complete both foundational Cisco tracks</strong> before being authorized to unlock or complete any commercial advanced internship tracks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Card 1: Cisco Networking Essentials */}
          <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-2xl flex flex-col justify-between space-y-3 hover:border-cyan-500/20 transition-all">
            <div className="space-y-1.5 text-left">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-cyan-400 font-mono font-bold uppercase tracking-wider">// CORE ROUTING & SUBNETS</span>
                {hasCiscoNetworkCompleted ? (
                  <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-500/30 text-emerald-400 rounded text-[9px] font-mono font-bold uppercase">COMPLETED</span>
                ) : (
                  <span className="px-2 py-0.5 bg-amber-950/40 border border-amber-500/20 text-amber-500 rounded text-[9px] font-mono font-bold uppercase">PENDING</span>
                )}
              </div>
              <h3 className="font-display font-bold text-xs text-white">Cisco Networking Essentials</h3>
              <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                Learn OSI model layers, TCP/UDP sockets, routing configurations, and subnet calculation frameworks.
              </p>
            </div>
            <button
              onClick={() => onNavigate("course-detail", { id: "cisco-network-basics" })}
              className={`w-full py-2 font-mono text-[10px] font-bold uppercase rounded-lg transition-all border ${
                hasCiscoNetworkCompleted 
                  ? "bg-emerald-950/20 hover:bg-emerald-950/40 border-emerald-500/30 text-emerald-400" 
                  : "bg-cyan-950 hover:bg-cyan-900/40 border-cyan-400/30 text-cyan-400 hover:text-white"
              } cursor-pointer`}
            >
              [ {hasCiscoNetworkCompleted ? "Review Completed Material" : "Launch Networking Course"} ]
            </button>
          </div>

          {/* Card 2: Cisco Cybersecurity Fundamentals */}
          <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-2xl flex flex-col justify-between space-y-3 hover:border-cyan-500/20 transition-all">
            <div className="space-y-1.5 text-left">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-cyan-400 font-mono font-bold uppercase tracking-wider">// DEFENSE MECHANISMS</span>
                {hasCiscoCyberCompleted ? (
                  <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-500/30 text-emerald-400 rounded text-[9px] font-mono font-bold uppercase">COMPLETED</span>
                ) : (
                  <span className="px-2 py-0.5 bg-amber-950/40 border border-amber-500/20 text-amber-500 rounded text-[9px] font-mono font-bold uppercase">PENDING</span>
                )}
              </div>
              <h3 className="font-display font-bold text-xs text-white">Cisco Cybersecurity Fundamentals</h3>
              <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                Learn basic threat landscape taxonomy, defense in depth, policy controls, and system auditing processes.
              </p>
            </div>
            <button
              onClick={() => onNavigate("course-detail", { id: "cisco-cyber-basics" })}
              className={`w-full py-2 font-mono text-[10px] font-bold uppercase rounded-lg transition-all border ${
                hasCiscoCyberCompleted 
                  ? "bg-emerald-950/20 hover:bg-emerald-950/40 border-emerald-500/30 text-emerald-400" 
                  : "bg-cyan-950 hover:bg-cyan-900/40 border-cyan-400/30 text-cyan-400 hover:text-white"
              } cursor-pointer`}
            >
              [ {hasCiscoCyberCompleted ? "Review Completed Material" : "Launch Cybersecurity Course"} ]
            </button>
          </div>
        </div>
      </div>

      {/* PCCA MODAL IN-PLACE */}
      {showPcca && (
        <div className="glass-panel p-6 rounded-3xl max-w-3xl mx-auto border-cyan-400/30 space-y-6 relative scanline-container bg-slate-950/95">
          <button 
            onClick={() => setShowPcca(false)}
            className="absolute top-4 right-4 text-slate-500 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center justify-between border-b border-slate-900 pb-3 pr-8">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-5 h-5 text-cyan-400" />
              <h3 className="font-display font-bold text-sm text-white uppercase tracking-wider">PatchWire Cyber Capability Assessment (PCCA)</h3>
            </div>
            {!pccaResultData && (
              <button
                onClick={handleSimulateAssessment}
                className="text-[9px] font-mono text-cyan-500 hover:text-cyan-300 border border-cyan-500/20 px-2 py-1 rounded bg-cyan-950/20 cursor-pointer"
              >
                [Simulation Bypass]
              </button>
            )}
          </div>

          {!pccaResultData ? (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                  <span>Domain Focus: <span className="text-cyan-400 font-bold">{PCCA_QUESTIONS[pccaStep].domain}</span></span>
                  <span>Question {pccaStep + 1} of {PCCA_QUESTIONS.length}</span>
                </div>
                
                {/* Progress bar */}
                <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-cyan-500 transition-all duration-300" 
                    style={{ width: `${((pccaStep + 1) / PCCA_QUESTIONS.length) * 100}%` }}
                  ></div>
                </div>
              </div>

              <h4 className="font-display font-bold text-base text-white mt-4">{PCCA_QUESTIONS[pccaStep].q}</h4>
              
              <div className="flex flex-col space-y-2 pt-2">
                {PCCA_QUESTIONS[pccaStep].options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => handlePccaAnswer(i)}
                    className="w-full text-left p-3.5 bg-slate-900/40 hover:bg-cyan-950/25 border border-slate-800/60 hover:border-cyan-500/30 rounded-xl text-xs text-slate-300 hover:text-white transition-all cursor-pointer"
                  >
                    <span className="font-mono text-cyan-500 mr-2">[{i + 1}]</span>
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-6 py-2">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-cyan-950 border border-cyan-400/40 flex items-center justify-center mx-auto text-cyan-400">
                  <CheckCircle2 className="w-6 h-6 animate-pulse" />
                </div>
                <h3 className="font-display font-bold text-lg text-white">Assessment Program Complete!</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  The diagnostics framework has aggregated your 50-node answers ledger. Below is your structured capability radar mapping:
                </p>
              </div>

              {/* Chart and recommended column */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                
                {/* Radar Chart */}
                <div className="md:col-span-7">
                  <div className="h-64 w-full bg-slate-950/40 p-2 rounded-2xl border border-slate-900/60 flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={pccaResultData.breakdown.map(item => ({
                        subject: item.domain,
                        score: item.percent,
                        fullMark: 100,
                      }))}>
                        <PolarGrid stroke="#1e293b" />
                        <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 8, fontFamily: 'JetBrains Mono' }} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#475569', fontSize: 7 }} />
                        <Radar name="Capabilities" dataKey="score" stroke="#06b6d4" fill="#0891b2" fillOpacity={0.4} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="md:col-span-5 space-y-4 text-xs font-sans">
                  <div className="glass-panel p-4 rounded-xl border-cyan-500/10 space-y-2.5">
                    <span className="text-[9px] font-mono text-cyan-400 uppercase tracking-widest">[Matched Track Plan]</span>
                    <h5 className="font-display font-bold text-sm text-white">
                      {CYBER_TRACKS.find(t => t.id === pccaResultData.recommendedTrackId)?.title || "Specialized Intern Track"}
                    </h5>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Your capability matrix indicates strong growth vectors within this focus domain.
                    </p>
                    <button
                      onClick={() => { onNavigate("tracks", { id: pccaResultData.recommendedTrackId }); setShowPcca(false); }}
                      className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-bold rounded-lg cursor-pointer transition-colors text-center block"
                    >
                      Configure This Track
                    </button>
                  </div>

                  <div className="glass-panel p-4 rounded-xl border-cyan-500/10 space-y-2.5">
                    <span className="text-[9px] font-mono text-yellow-500 uppercase tracking-widest">[Matched Operations Bundle]</span>
                    <h5 className="font-display font-bold text-sm text-white">
                      {pccaResultData.recommendedBundleId === "ultimate-pack" ? "Ultimate Cybersecurity Bundle (₹699)" : pccaResultData.recommendedBundleId === "red-team-bundle" ? "Red Team Bundle (₹249)" : "SOC + GRC Bundle (₹129)"}
                    </h5>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Optimize your academic investment with the operations bundle matched to your diagnostic path.
                    </p>
                    <button
                      onClick={() => { onNavigate("tracks", { id: pccaResultData.recommendedBundleId }); setShowPcca(false); }}
                      className="w-full py-2 bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-500 hover:to-amber-500 text-slate-950 font-sans text-xs font-extrabold rounded-lg cursor-pointer transition-all text-center block"
                    >
                      Unlock Matched Bundle
                    </button>
                  </div>
                </div>

              </div>

              <div className="flex justify-end pt-2 border-t border-slate-900">
                <button
                  onClick={() => setShowPcca(false)}
                  className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-400 text-xs rounded-lg hover:text-white cursor-pointer"
                >
                  Close Results
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FILTER & SEARCH SYSTEM */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-4 glass-panel rounded-2xl">
        {/* Difficulties */}
        <div className="flex items-center space-x-1 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
          {["All", "Beginner", "Intermediate", "Advanced", "Expert"].map((diff) => (
            <button
              key={diff}
              onClick={() => setFilterDifficulty(diff)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                filterDifficulty === diff 
                  ? "bg-cyan-950/50 text-cyan-400 border border-cyan-500/20 font-bold" 
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {diff}
            </button>
          ))}
        </div>

        {/* Search */}
        <input 
          type="text" 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search tracks, labs, or tools..."
          className="w-full md:w-80 bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl px-4 py-2 text-xs text-white focus:outline-none"
        />
      </div>

      {/* TRACKS LIST CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredTracks.map((track) => {
          const isEnrolled = enrolledIds.includes(track.id);
          const isPending = pendingIds.includes(track.id);

          return (
            <div 
              key={track.id}
              className="glass-panel rounded-2xl overflow-hidden hover:border-cyan-400/40 hover:-translate-y-1.5 transition-all flex flex-col h-full group"
            >
              {/* Image banner */}
              <div className="h-44 relative overflow-hidden bg-slate-900">
                <img 
                  src={track.bannerImage} 
                  alt={track.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 brightness-95"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                <div className="absolute top-3 right-3 px-2 py-0.5 bg-cyan-950/80 border border-cyan-400/30 rounded text-[10px] font-mono uppercase text-cyan-400 tracking-wider">
                  {track.difficulty}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex flex-col flex-grow justify-between space-y-4 text-left">
                <div className="space-y-3">
                  <h3 className="font-display font-bold text-base text-white group-hover:text-cyan-400 transition-colors">
                    {track.title}
                  </h3>
                  <p className="text-slate-400 text-xs font-sans leading-relaxed line-clamp-3">
                    {track.description}
                  </p>
                  
                  {/* Stats bar */}
                  <div className="flex items-center space-x-4 text-[10px] font-mono text-slate-500 pt-1">
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{track.duration}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Terminal className="w-3.5 h-3.5" />
                      <span>{track.modules.length} Modules</span>
                    </span>
                  </div>
                </div>

                {/* Price and Action */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-900">
                  <div className="flex flex-col">
                    <span className="text-[9px] text-slate-500 font-mono uppercase">Course Fee</span>
                    <span className="font-display font-bold text-white text-base">₹{track.price} <span className="text-xs text-cyan-400 font-mono">INR</span></span>
                  </div>
                  
                  {isEnrolled ? (
                    <button 
                      onClick={() => onNavigate("tracks", { id: track.id })}
                      className="px-4 py-2 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 hover:text-white hover:bg-emerald-900/30 font-sans text-xs font-semibold rounded transition-all cursor-pointer flex items-center space-x-1"
                    >
                      <span>Active</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : isPending ? (
                    <span className="px-3 py-1.5 bg-yellow-950/20 border border-yellow-500/20 rounded text-[10px] text-yellow-500 font-mono uppercase tracking-widest animate-pulse">
                      Pending
                    </span>
                  ) : (
                    <button 
                      onClick={() => onNavigate("tracks", { id: track.id })}
                      className="px-4 py-2 bg-cyan-950/50 border border-cyan-500/20 hover:border-cyan-400 hover:bg-cyan-900/30 text-cyan-400 font-sans text-xs font-semibold rounded transition-all cursor-pointer flex items-center space-x-1"
                    >
                      <span>Get Started</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ==========================================
// 2. DYNAMIC COURSE TEMPLATE (Curriculum, Labs, Quizzes, Graduation)
// ==========================================
export function CourseDetailPage({ 
  user, 
  trackId, 
  onNavigate,
  onOpenAuth 
}: { 
  user: any; 
  trackId: string; 
  onNavigate: (page: string, params?: any) => void;
  onOpenAuth: () => void;
}) {
  const track = CYBER_TRACKS.find(t => t.id === trackId);
  const [enrolled, setEnrolled] = useState(false);
  const [pending, setPending] = useState(false);
  const [activeTab, setActiveTab] = useState<"curriculum" | "lab" | "quiz" | "resource">("curriculum");
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [autoRedirect, setAutoRedirect] = useState(true);

  const isPrerequisiteCheckRequired = track ? (track.id !== "cisco-cyber-basics" && track.id !== "cisco-network-basics") : false;
  const hasCompletedPrerequisites = user ? db.checkPrerequisitesCompleted(user.id) : false;
  const showPrerequisiteWarning = isPrerequisiteCheckRequired && !hasCompletedPrerequisites;
  const isPrerequisiteBlocked = false; // Do not hard-lock, only warn/highlight/recommend

  const getTechnicalLessonStudyGuide = (lesson: Lesson) => {
    const title = lesson.title.toLowerCase();
    
    // SOC / Log analysis
    if (title.includes("soc") || title.includes("log") || title.includes("siem") || title.includes("incident") || title.includes("triage")) {
      return {
        introduction: "Security Operations Center (SOC) teams monitor enterprise infrastructure 24/7 to identify anomalous activity, triage events, and contain security compromises. System logs are the primary telemetry used to identify malicious actions across networks.",
        keyConcepts: [
          "SIEM (Security Information and Event Management): Centralized platform to aggregate, parse, correlate, and visualize log events.",
          "Alert Triage Lifecycle: Detecting an alert, assessing asset severity, identifying False Positives, and escalating critical True Positives.",
          "Event Log Analysis: Inspecting process creations, authentication attempts (successful/failed logons), and unusual network flows."
        ],
        commands: [
          { cmd: "grep -i 'failed' /var/log/auth.log", desc: "Filters linux authentication logs to list failed login attempts." },
          { cmd: "tail -f /var/log/syslog", desc: "Streams system message logs in real-time." },
          { cmd: "cat /var/log/nginx/access.log | awk '{print $1}' | sort | uniq -c", desc: "Aggregates access counts by source IP address to isolate DDoS spikes." }
        ],
        stepByStep: [
          "1. Check the source IP address in public threat intelligence feeds (e.g. VirusTotal, AbuseIPDB).",
          "2. Inspect other log signals originating from the same IP within a ±15 minute window.",
          "3. Isolate affected nodes or terminate suspicious process IDs (PIDs) using admin commands.",
          "4. Draft a comprehensive incident log escalation record for blue team remediation."
        ]
      };
    }
    
    // Ethical Hacking / Nmap / Metasploit / Recon
    if (title.includes("ethical") || title.includes("hacking") || title.includes("recon") || title.includes("nmap") || title.includes("metasploit") || title.includes("exploit") || title.includes("compromise")) {
      return {
        introduction: "Ethical hacking utilizes penetration testing frameworks to proactively audit target architectures for vulnerabilities. Security teams run network scans, exploit missing software patches, and draft defensive recommendations before bad actors exploit them.",
        keyConcepts: [
          "OSINT (Open Source Intelligence): Harvesting public details from WHOIS registries, DNS files, and search tools.",
          "Active Port Scanning: Probing TCP/UDP sockets to map active operating systems, open ports, and live application versions.",
          "Exploitation Phase: Injecting custom scripts or payloads into vulnerable server services to establish shell access."
        ],
        commands: [
          { cmd: "nmap -sS -sV -O -F 10.10.88.5", desc: "Executes a stealth SYN scan with service version detection and OS mapping on fast ports." },
          { cmd: "msfconsole -q", desc: "Launches the Metasploit penetration framework console in quiet mode." },
          { cmd: "search usermap_script", desc: "Searches the Metasploit database for matching Samba exploit payloads." }
        ],
        stepByStep: [
          "1. Run Nmap to discover open sockets and identify target host services.",
          "2. Research identified service banners for CVE ratings or known public exploits.",
          "3. Load the matching module inside Metasploit, configure 'RHOSTS', and run 'exploit'.",
          "4. Retrieve system indicators (like flags) to confirm vulnerability impact."
        ]
      };
    }

    // Web Security / OWASP / PortSwigger
    if (title.includes("web") || title.includes("owasp") || title.includes("portswigger") || title.includes("injection") || title.includes("vulnerability") || title.includes("vapt")) {
      return {
        introduction: "Web application penetration testing targets security vulnerabilities in web code, APIs, and microservices. The OWASP Top 10 framework catalogs the most critical risks to modern public web platforms.",
        keyConcepts: [
          "Broken Access Control: Failure to restrict administrative page URLs or file directories to authorized credentials.",
          "SQL Injection (SQLi): Injecting malicious SQL statements into web inputs to manipulate backend databases.",
          "Cross-Site Scripting (XSS): Injecting client-side JavaScript payloads into web inputs that render in other users' browsers."
        ],
        commands: [
          { cmd: "sqlmap -u 'http://target.xyz/product.php?id=1' --dbs", desc: "Automates SQLi detection and databases extraction on target URLs." },
          { cmd: "dirb http://target.xyz /usr/share/wordlists/common.txt", desc: "Brute-forces web routes to discover unlinked admin directories and assets." },
          { cmd: "curl -i -X POST -d 'user=admin&pass=admin' http://target/login", desc: "Audits authentication request payloads via console command." }
        ],
        stepByStep: [
          "1. Use Burp Suite proxy to capture, review, and repeat web request and response headers.",
          "2. Input special control characters (like single-quotes or angle-brackets) into input boxes to test input validation sanitization.",
          "3. Leverage automation tools to securely verify if target endpoints permit arbitrary query outputs.",
          "4. Mitigate vulnerabilities by implementing parameterized queries and output sanitization."
        ]
      };
    }

    // Network Security / Firewalls / Packet Analysis / VPN
    if (title.includes("network") || title.includes("firewall") || title.includes("packet") || title.includes("wireshark") || title.includes("vpn") || title.includes("osi")) {
      return {
        introduction: "Network security implements layered defense lines (such as DMZs, stateful firewalls, VPNs, and packet analysers) to regulate corporate traffic, secure communication channels, and isolate critical nodes.",
        keyConcepts: [
          "OSI Model Architecture: Logical layers (Physical to Application) defining how data frames, packets, and segments cross systems.",
          "Stateful Inspection: Monitoring entire connection states (SYN, SYN-ACK, ACK) to enforce firewall rule compliance.",
          "IPsec VPN Tunnels: Encrypting and tunneling complete corporate payloads between remote nodes securely."
        ],
        commands: [
          { cmd: "tcpdump -i eth0 -n -c 100", desc: "Captures and displays the first 100 packet headers traversing interface eth0." },
          { cmd: "iptables -A INPUT -p tcp --dport 22 -j DROP", desc: "Configures the Linux firewall to drop all incoming SSH connections securely." },
          { cmd: "netstat -tuln", desc: "Lists all active listening TCP and UDP sockets with port IDs on the localhost." }
        ],
        stepByStep: [
          "1. Load a packet capture (PCAP) in Wireshark and filter on standard security protocols.",
          "2. Inspect packet header fields (e.g. source, destination, protocol flags) to spot anomalies.",
          "3. Update firewall filtering parameters to reject or drop traffic matching threat signatures.",
          "4. Validate secure configurations by testing connection paths from external subnets."
        ]
      };
    }

    // Forensics / Investigation / Disk / Memory / Evidence
    if (title.includes("forensics") || title.includes("investigation") || title.includes("evidence") || title.includes("disk") || title.includes("memory") || title.includes("volatility") || title.includes("autopsy")) {
      return {
        introduction: "Digital forensics investigates security breaches, reconstructing compromised systems to recover files, build logs, extract credentials, and establish legally valid chain of custody registers.",
        keyConcepts: [
          "Chain of Custody: Meticulous record-keeping tracking the collection, transfer, and analysis of physical and digital evidence.",
          "Bit-Stream Disk Imaging: Creating write-blocked sector-by-sector copies of hard drives to preserve evidence integrity.",
          "Memory Analysis: Carving active process tokens and network connections out of volatile RAM dumps."
        ],
        commands: [
          { cmd: "volatility -f raw_ram.dmp --profile=Win10x64_18362 pslist", desc: "Lists active and terminated processes found inside volatile RAM dumps." },
          { cmd: "dd if=/dev/sdb of=/evidence/usb_image.dd bs=4M conv=noerror,sync", desc: "Generates a bit-stream forensic image of an external USB drive." },
          { cmd: "md5sum /evidence/usb_image.dd", desc: "Calculates the cryptographic MD5 hash of evidence files to verify integrity." }
        ],
        stepByStep: [
          "1. Document evidence collection details, hashing files immediately to lock integrity values.",
          "2. Mount forensic images in read-only mode to prevent write modifications during audits.",
          "3. Analyze operating system artifacts, registry logs, file metadata, and deleted blocks.",
          "4. Prepare a comprehensive digital forensic report detailing findings and chain of custody timelines."
        ]
      };
    }

    // Default Fallback
    return {
      introduction: "This curriculum module teaches real-world practical cybersecurity frameworks. Explore detailed architectural designs, secure commands, threat hunting procedures, and interactive lab scenarios.",
      keyConcepts: [
        "Defense-in-Depth: Implementing layered security strategies across physical, technical, and administrative controls.",
        "Least Privilege Model: Restricting application and user access permissions strictly to resources essential for their core function.",
        "Vulnerability Management: Continuously scanning, identifying, assessing, and patching vulnerable corporate systems."
      ],
      commands: [
        { cmd: "ss -lntp", desc: "Displays active listening ports with the associated process names and user accounts." },
        { cmd: "uname -a", desc: "Prints complete system kernel build parameters to research matching local privilege exploits." },
        { cmd: "cat /etc/passwd", desc: "Reviews system user account registries to audit for unneeded or privileged accounts." }
      ],
      stepByStep: [
        "1. Understand the system layout, dependencies, and sensitive assets under investigation.",
        "2. Map security requirements to regulatory or performance compliance benchmarks.",
        "3. Test and configure systems utilizing defensive controls, firewalls, or strict access permissions.",
        "4. Audit system telemetry and generate reports validating overall architecture security."
      ]
    };
  };

  const getTryHackMeLabsForLesson = (lesson: Lesson, trackId: string) => {
    const title = lesson.title.toLowerCase();
    
    // Custom generated 3 level-wise free THM labs
    if (title.includes("network") || title.includes("routing") || title.includes("cisco") || title.includes("packet")) {
      return [
        {
          level: "Level 1: Entry-Level Fundamentals",
          title: "TryHackMe — Intro to Networking",
          desc: "Master the basics of OSI models, IP subnet addressing, and packet delivery flows inside a free interactive room.",
          url: "https://tryhackme.com/room/introtonetworking",
          badge: "Free Network Room"
        },
        {
          level: "Level 2: Intermediate Core Labs",
          title: "TryHackMe — Network Services",
          desc: "Interact with enterprise network services (SSH, FTP, Samba, SMB) side-by-side with networking theory.",
          url: "https://tryhackme.com/room/networkservices",
          badge: "Free Core Lab"
        },
        {
          level: "Level 3: Advanced Practical Scenarios",
          title: "TryHackMe — Wireshark Packet Analysis",
          desc: "Analyze standard PCAP packet capture files using Wireshark to isolate network intrusion traces.",
          url: "https://tryhackme.com/room/wireshark",
          badge: "Free Threat Hunting"
        }
      ];
    } else if (title.includes("soc") || title.includes("log") || title.includes("siem") || title.includes("incident") || title.includes("triage")) {
      return [
        {
          level: "Level 1: Entry-Level Fundamentals",
          title: "TryHackMe — Intro to SIEM",
          desc: "Understand Security Information and Event Management systems and analyze aggregate security logs practically.",
          url: "https://tryhackme.com/room/introsiem",
          badge: "Free SIEM Room"
        },
        {
          level: "Level 2: Intermediate Core Labs",
          title: "TryHackMe — Splunk Core Skills",
          desc: "Write active query logs inside Splunk enterprise console to parse authentication events and detect compromises.",
          url: "https://tryhackme.com/room/splunk101",
          badge: "Free Splunk Lab"
        },
        {
          level: "Level 3: Advanced Practical Scenarios",
          title: "TryHackMe — Investigative Incident Response",
          desc: "Triage raw JSON and CSV system log events to create structured corporate compromise timelines.",
          url: "https://tryhackme.com/room/investigatingsplunk",
          badge: "Free Response Lab"
        }
      ];
    } else if (title.includes("ethical") || title.includes("hacking") || title.includes("recon") || title.includes("nmap") || title.includes("metasploit") || title.includes("exploit") || title.includes("compromise") || title.includes("bandit") || title.includes("overthewire") || title.includes("privilege")) {
      return [
        {
          level: "Level 1: Entry-Level Fundamentals",
          title: "TryHackMe — Nmap Port Probing",
          desc: "Launch comprehensive network scan scripts inside TryHackMe's free attack box to map target topology.",
          url: "https://tryhackme.com/room/furthernmap",
          badge: "Free Nmap Room"
        },
        {
          level: "Level 2: Intermediate Core Labs",
          title: "TryHackMe — Metasploit Framework",
          desc: "Configure target options, select exploit payloads, and compromise outdated Samba modules inside a sandboxed VM.",
          url: "https://tryhackme.com/room/rpmetasploit",
          badge: "Free Metasploit Lab"
        },
        {
          level: "Level 3: Advanced Practical Scenarios",
          title: "TryHackMe — Vulnversity Root Hacking",
          desc: "Perform dynamic directory brute forcing, exploit file upload vulnerabilities, and execute privilege escalation to get root.",
          url: "https://tryhackme.com/room/vulnversity",
          badge: "Free Privilege Escalation"
        }
      ];
    } else if (title.includes("web") || title.includes("owasp") || title.includes("portswigger") || title.includes("injection") || title.includes("vulnerability") || title.includes("vapt")) {
      return [
        {
          level: "Level 1: Entry-Level Fundamentals",
          title: "TryHackMe — OWASP Top 10 Core",
          desc: "Learn fundamental web application vulnerabilities, including broken access control, security misconfigurations, and cryptographic failures.",
          url: "https://tryhackme.com/room/owasptop10",
          badge: "Free OWASP Room"
        },
        {
          level: "Level 2: Intermediate Core Labs",
          title: "TryHackMe — SQL Injection Lab",
          desc: "Bypass administrative login portals using clean SQL Injection payloads side-by-side with theoretical database logic.",
          url: "https://tryhackme.com/room/sqlisids",
          badge: "Free SQLi Lab"
        },
        {
          level: "Level 3: Advanced Practical Scenarios",
          title: "TryHackMe — Cross-Site Scripting (XSS)",
          desc: "Craft and execute Reflected, Stored, and DOM-based XSS attack payloads inside sandbox templates.",
          url: "https://tryhackme.com/room/axss",
          badge: "Free Scripting Lab"
        }
      ];
    } else if (title.includes("forensics") || title.includes("evidence") || title.includes("disk") || title.includes("memory") || title.includes("volatility") || title.includes("autopsy")) {
      return [
        {
          level: "Level 1: Entry-Level Fundamentals",
          title: "TryHackMe — Intro to Digital Forensics",
          desc: "Examine registry keys, parse process histories, and secure metadata properties under legal custody guidelines.",
          url: "https://tryhackme.com/room/introdigitalforensics",
          badge: "Free Forensics Room"
        },
        {
          level: "Level 2: Intermediate Core Labs",
          title: "TryHackMe — Volatility RAM Extraction",
          desc: "Use Volatility commands to recover volatile memory dumps and inspect active network sockets.",
          url: "https://tryhackme.com/room/bpvolatility",
          badge: "Free Volatility Lab"
        },
        {
          level: "Level 3: Advanced Practical Scenarios",
          title: "TryHackMe — Autopsy File Analysis",
          desc: "Import raw disk dumps into Autopsy to recover deleted documents, system indices, and malware traces.",
          url: "https://tryhackme.com/room/autopsy2022",
          badge: "Free Autopsy Lab"
        }
      ];
    } else {
      // Default fallback structured labs for generic cyber topics
      return [
        {
          level: "Level 1: Entry-Level Fundamentals",
          title: "TryHackMe — Intro to Cyber Defense",
          desc: "Explore blue team roles, security operations methodology, defensive tools, and compliance frameworks.",
          url: "https://tryhackme.com/room/introtoofensive",
          badge: "Free Defense Room"
        },
        {
          level: "Level 2: Intermediate Core Labs",
          title: "TryHackMe — Vulnerability Research",
          desc: "Research open-source intelligence databases, locate public CVE records, and map defense signatures.",
          url: "https://tryhackme.com/room/vulnerabilityresearch",
          badge: "Free Threat Intel"
        },
        {
          level: "Level 3: Advanced Practical Scenarios",
          title: "TryHackMe — Blueprint Threat Hunting",
          desc: "Detect, analyze, and neutralize advanced persistent threat actors mimicking system administration scripts.",
          url: "https://tryhackme.com/room/threatintel101",
          badge: "Free Threat Hunter"
        }
      ];
    }
  };

  const getLessonExternalUrl = (lesson: Lesson): string => {
    if (lesson.contentUrl && !lesson.contentUrl.includes("mov_bbb.mp4")) {
      return lesson.contentUrl;
    }

    const title = lesson.title.toLowerCase();
    
    // Check if it's an OverTheWire lesson
    if (title.includes("overthewire") || title.includes("otw") || title.includes("bandit")) {
      return "https://overthewire.org/wargames/bandit/";
    }
    
    // Check if it's a PortSwigger lesson
    if (title.includes("portswigger") || title.includes("web") || title.includes("owasp") || title.includes("vapt")) {
      return "https://portswigger.net/web-security/all-topics";
    }
    
    // Check if it's a TryHackMe lesson
    if (title.includes("tryhackme")) {
      if (title.includes("nmap")) return "https://tryhackme.com/room/furthernmap";
      if (title.includes("metasploit") || title.includes("exploit")) return "https://tryhackme.com/room/rpmetasploit";
      if (title.includes("wireshark") || title.includes("packet")) return "https://tryhackme.com/room/wireshark";
      if (title.includes("forensics")) return "https://tryhackme.com/room/introtoforensics";
      if (title.includes("soc") || title.includes("log") || title.includes("siem")) return "https://tryhackme.com/room/soclevel1";
      if (title.includes("cloud")) return "https://tryhackme.com/room/awscloudsecurity";
      return "https://tryhackme.com";
    }
    
    // Check if it's a HackTheBox lesson
    if (title.includes("hackthebox") || title.includes("htb")) {
      return "https://www.hackthebox.com";
    }
    
    // For general lectures / resource nodes: provide real, high-quality free virtual training portals instead of video-sharing sites
    if (lesson.type === "video" || lesson.type === "pdf") {
      if (title.includes("soc") || title.includes("log") || title.includes("siem") || title.includes("incident") || title.includes("triage")) {
        return "https://tryhackme.com/module/introduction-to-soc-level-1"; // Free SOC Analyst module
      }
      if (title.includes("ethical") || title.includes("hacking") || title.includes("recon") || title.includes("nmap") || title.includes("metasploit") || title.includes("exploit")) {
        return "https://tryhackme.com/module/jr-penetration-tester"; // Free Penetration Testing pathway
      }
      if (title.includes("web") || title.includes("owasp") || title.includes("injection") || title.includes("vulnerability") || title.includes("vapt")) {
        return "https://portswigger.net/web-security/all-topics"; // Premium free Web Academy
      }
      if (title.includes("network") || title.includes("firewall") || title.includes("packet") || title.includes("wireshark") || title.includes("vpn") || title.includes("osi")) {
        return "https://tryhackme.com/module/network-security"; // Free Network Defense module
      }
      if (title.includes("forensics") || title.includes("investigation") || title.includes("evidence") || title.includes("disk") || title.includes("memory") || title.includes("volatility")) {
        return "https://tryhackme.com/module/digital-forensics"; // Free Digital Forensics pathway
      }
      if (title.includes("grc") || title.includes("compliance") || title.includes("iso")) {
        return "https://tryhackme.com/room/grcreduction"; // Free GRC Lab Module
      }
      if (title.includes("cloud") || title.includes("aws")) {
        return "https://explore.skillbuilder.aws/learningpaths"; // Official free cloud pathways
      }
    }
    
    if (lesson.contentUrl && !lesson.contentUrl.includes("mov_bbb.mp4")) {
      return lesson.contentUrl;
    }
    
    return "https://tryhackme.com"; // default
  };

  const getLessonPlatformName = (lesson: Lesson): string => {
    const title = lesson.title.toLowerCase();
    
    // Check specific custom platforms
    if (title.includes("overthewire") || title.includes("otw") || title.includes("bandit")) {
      return "OverTheWire Bandit Portal";
    }
    if (title.includes("portswigger") || title.includes("web") || title.includes("owasp") || title.includes("injection") || title.includes("vapt")) {
      return "PortSwigger Web Academy";
    }
    if (title.includes("cloud") || title.includes("aws")) {
      return "AWS Skill Builder Security";
    }
    if (title.includes("grc") || title.includes("compliance") || title.includes("iso")) {
      return "TryHackMe GRC Laboratory";
    }
    if (title.includes("forensics") || title.includes("investigation") || title.includes("evidence") || title.includes("disk") || title.includes("memory") || title.includes("volatility")) {
      return "TryHackMe Digital Forensics";
    }
    if (title.includes("network") || title.includes("firewall") || title.includes("packet") || title.includes("wireshark") || title.includes("vpn") || title.includes("osi")) {
      return "TryHackMe Network Security";
    }
    if (title.includes("soc") || title.includes("log") || title.includes("siem") || title.includes("incident") || title.includes("triage")) {
      return "TryHackMe SOC Analyst Training";
    }
    if (title.includes("ethical") || title.includes("hacking") || title.includes("recon") || title.includes("nmap") || title.includes("metasploit") || title.includes("exploit")) {
      return "TryHackMe Jr. Pentester Path";
    }
    if (title.includes("tryhackme")) return "TryHackMe Laboratory";
    if (title.includes("hackthebox") || title.includes("htb")) return "HackTheBox Academy";
    return "PatchWire Virtual Sandbox";
  };

  // Lab Shell state
  const [terminalInput, setTerminalInput] = useState("");
  const [terminalHistory, setTerminalHistory] = useState<string[]>(["Welcome to PatchWire Cyber Lab Terminal simulator...", "Type help to see commands list.", ""]);
  const [labSuccess, setLabSuccess] = useState(false);
  const [flagSubmitted, setFlagSubmitted] = useState("");
  const [flagError, setFlagError] = useState("");

  // Quiz state
  const [quizAnswers, setQuizAnswers] = useState<{ [qId: string]: number }>({});
  const [quizGraded, setQuizGraded] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  const reloadData = () => {
    if (user && track) {
      const activeEnrolls = db.getEnrolledTracks(user.id).map(t => t.id);
      const pendingEnrolls = db.getPendingTrackIds(user.id);
      
      setEnrolled(activeEnrolls.includes(track.id));
      setPending(pendingEnrolls.includes(track.id));

      const prog = db.getProgress(user.id, track.id);
      setCompletedLessons(prog.completedLessons);
    }
  };

  useEffect(() => {
    // Reset all workspace states on track change
    setTerminalHistory(["Welcome to PatchWire Cyber Lab Terminal simulator...", "Type help to see commands list.", ""]);
    setQuizAnswers({});
    setQuizGraded(false);
    setLabSuccess(false);
    setFlagSubmitted("");
    setFlagError("");

    if (user && track) {
      const activeEnrolls = db.getEnrolledTracks(user.id).map(t => t.id);
      const pendingEnrolls = db.getPendingTrackIds(user.id);
      const isEnrolled = activeEnrolls.includes(track.id);
      
      setEnrolled(isEnrolled);
      setPending(pendingEnrolls.includes(track.id));

      const prog = db.getProgress(user.id, track.id);
      setCompletedLessons(prog.completedLessons);

      if (isEnrolled && track.modules.length > 0) {
        const allLessons = track.modules.flatMap(m => m.lessons);
        const firstIncomplete = allLessons.find(l => !prog.completedLessons.includes(l.id));
        const initialLesson = firstIncomplete || allLessons[0];
        setActiveLesson(initialLesson);
        if (initialLesson.type === "lab") {
          setActiveTab("lab");
        } else if (initialLesson.type === "quiz") {
          setActiveTab("quiz");
        } else {
          setActiveTab("resource");
        }
      } else {
        setActiveLesson(null);
      }
    } else {
      setEnrolled(false);
      setPending(false);
      setActiveLesson(null);
    }
  }, [user, trackId]);

  if (!track) {
    return (
      <div className="py-20 text-center">
        <p className="text-sm text-slate-500 font-mono">[ERROR_LOG_SYS: TARGET COURSE NULL]</p>
      </div>
    );
  }

  // Calculate total lessons
  let totalLessonsCount = 0;
  track.modules.forEach(m => {
    totalLessonsCount += m.lessons.length;
  });
  const completedCount = completedLessons.length;
  const progressPercent = totalLessonsCount > 0 ? Math.round((completedCount / totalLessonsCount) * 100) : 0;

  // Curated Lab Terminal reaction commands
  const handleTerminalCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput) return;
    const cleanCmd = terminalInput.trim().toLowerCase();
    let reply = "";

    if (cleanCmd === "help") {
      reply = "Commands available: help, clear, nmap, exploit, ls, cat, readflag";
    } else if (cleanCmd === "clear") {
      setTerminalHistory([]);
      setTerminalInput("");
      return;
    } else if (cleanCmd.startsWith("nmap")) {
      reply = "Scanning target nodes...\nPort 80 [HTTP] is open. Service: Apache Samba 3.0.20.\nPort 445 [SMB] is open. Service: Samba usermap_script.\nReconnaissance target flag is located in /var/www/flag.txt.";
    } else if (cleanCmd.startsWith("exploit") || cleanCmd.startsWith("msfconsole")) {
      reply = "Launching Metasploit payload...\nExploiting Samba module usermap_script...\nSession 1 opened securely!\nRoot shell achieved. Type 'readflag' to print flags.";
    } else if (cleanCmd === "ls") {
      reply = "flag.txt  root.txt  logs.db";
    } else if (cleanCmd === "readflag" || cleanCmd.startsWith("cat flag") || cleanCmd.startsWith("cat root")) {
      reply = `SYSTEM_FLAG: flag{${track.id}_compromised_node_99}`;
    } else {
      reply = `bash: command not found: ${cleanCmd}`;
    }

    setTerminalHistory([...terminalHistory, `operator@patchwire:~# ${terminalInput}`, reply, ""]);
    setTerminalInput("");
  };

  // Submit flag verification
  const handleFlagSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFlagError("");
    const correctFlag = `flag{${track.id}_compromised_node_99}`;
    if (flagSubmitted.trim() === correctFlag) {
      setLabSuccess(true);
      if (user && activeLesson) {
        db.completeLesson(user.id, track.id, activeLesson.id);
        setCompletedLessons(prev => [...prev, activeLesson.id]);
        db.createNotification(user.id, "Lab Completed Successfully!", `Incredible hack! You successfully compromised ${activeLesson.title} and submitted the correct flag. Earned 150 XP.`, "success");
      }
    } else {
      setFlagError("Flag verification failed. Check capital letters or characters!");
    }
  };

  // Graded quiz grading
  const handleQuizSubmit = (questions: QuizQuestion[]) => {
    let score = 0;
    questions.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswerIndex) {
        score++;
      }
    });

    const finalPercent = Math.round((score / questions.length) * 100);
    setQuizScore(finalPercent);
    setQuizGraded(true);

    if (user && activeLesson) {
      db.completeLesson(user.id, track.id, activeLesson.id, finalPercent);
      setCompletedLessons(prev => [...prev, activeLesson.id]);
    }
  };

  const selectLesson = (lesson: Lesson) => {
    if (!enrolled) return;
    setActiveLesson(lesson);
    setFlagError("");
    if (lesson.type === "lab") {
      setActiveTab("lab");
      setLabSuccess(false);
      setFlagSubmitted("");
    } else if (lesson.type === "quiz") {
      setActiveTab("quiz");
      setQuizGraded(false);
      setQuizAnswers({});
    } else {
      setActiveTab("resource");
      // Autocomplete standard reading nodes for convenience
      if (user) {
        db.completeLesson(user.id, track.id, lesson.id);
        setCompletedLessons(prev => {
          if (!prev.includes(lesson.id)) return [...prev, lesson.id];
          return prev;
        });
      }
    }

    if (autoRedirect && lesson.type !== "quiz") {
      const url = getLessonExternalUrl(lesson);
      setTimeout(() => {
        window.open(url, "_blank");
      }, 50);
    }
  };

  const handleToggleLessonCompletion = (lessonId: string) => {
    if (!user || !track) return;
    const completed = db.toggleLessonCompletion(user.id, track.id, lessonId);
    if (completed) {
      setCompletedLessons(prev => [...prev, lessonId]);
      db.createNotification(
        user.id,
        "Lesson Checked Off",
        `You marked "${track.title}" lesson node completed!`,
        "success"
      );
    } else {
      setCompletedLessons(prev => prev.filter(id => id !== lessonId));
    }
  };

  const handleGraduate = () => {
    if (user && track) {
      db.generateCertificate(user.id, user.name, track.id);
      onNavigate("profile");
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-10 text-left">
      
      {/* HEADER BANNER */}
      <div className="glass-panel p-6 md:p-8 rounded-3xl relative overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/20 flex flex-col md:flex-row items-start justify-between gap-6 border-b-2 border-cyan-400/25">
        <div className="space-y-4 max-w-2xl">
          <span className="px-2 py-0.5 bg-cyan-950 border border-cyan-400/30 rounded text-[9px] font-mono uppercase text-cyan-400 tracking-wider">
            {track.difficulty} Path
          </span>
          <h1 className="font-display font-bold text-2xl md:text-3xl text-white tracking-tight">{track.title}</h1>
          <p className="text-xs text-slate-300 font-sans leading-relaxed">{track.longDescription}</p>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400">
            <span className="flex items-center space-x-1">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>{track.duration}</span>
            </span>
            <span className="flex items-center space-x-1">
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span>{track.modules.length} Modules ({totalLessonsCount} nodes)</span>
            </span>
          </div>
        </div>

        {/* ENROLLMENT CTA / STATS */}
        <div className="glass-panel p-5 rounded-2xl w-full md:w-80 shrink-0 text-center space-y-4">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Certification Internship Cost</span>
            <span className="font-display font-bold text-2xl text-white">₹{track.price} <span className="text-sm text-cyan-400 font-mono">INR</span></span>
          </div>

          {!user ? (
            <button
              onClick={onOpenAuth}
              className="w-full py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-sans text-xs font-bold rounded-lg hover:from-cyan-500 hover:to-blue-500 shadow-md shadow-cyan-500/15"
            >
              Sign Up to Enroll
            </button>
          ) : enrolled ? (
            <div className="space-y-3">
              {/* Progress bar */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-400">Track Progress</span>
                  <span className="text-cyan-400 font-bold">{progressPercent}%</span>
                </div>
                <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-cyan-400 h-full rounded-full transition-all duration-300" style={{ width: `${progressPercent}%` }}></div>
                </div>
              </div>

              {/* Graduate certificate block */}
              {progressPercent === 100 ? (
                <div className="p-3 bg-cyan-950/40 border border-cyan-400/30 rounded-xl space-y-2 text-center">
                  <span className="font-display font-bold text-xs text-white uppercase block">Track 100% Complete!</span>
                  <button
                    onClick={handleGraduate}
                    className="w-full py-2 bg-gradient-to-r from-amber-500 to-rose-500 text-white font-sans text-xs font-bold rounded shadow"
                  >
                    Claim Verified Diploma
                  </button>
                </div>
              ) : (
                <div className="p-3 bg-cyan-950/10 border border-cyan-500/10 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-sans block">Complete all labs and quizzes to claim diploma.</span>
                </div>
              )}
            </div>
          ) : pending ? (
            <div className="p-4 bg-yellow-950/20 border border-yellow-500/30 rounded-xl text-center space-y-2">
              <span className="text-xs font-mono font-bold text-yellow-500 uppercase block animate-pulse">Payment Pending Verification</span>
              <p className="text-[10px] text-slate-400 font-sans leading-relaxed">Our finance ledger is reviewing your UTR receipt screenshot. Course unlocks dynamically once verified.</p>
            </div>
          ) : (
            <button
              onClick={() => onNavigate("checkout", { trackId: track.id })}
              className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-sans text-xs font-bold rounded-lg hover:from-cyan-400 hover:to-blue-500"
            >
              Buy Now & Start Internship
            </button>
          )}
        </div>
      </div>

      {/* RECOMMENDED PRE-REQUISITES ALERT (HIGHLIGHTED NOT LOCKED) */}
      {showPrerequisiteWarning && (
        <div className="p-6 rounded-3xl border border-amber-500/30 bg-amber-950/15 text-left space-y-4 shadow-[0_0_20px_rgba(245,158,11,0.05)]">
          <div className="flex items-start space-x-3">
            <ShieldAlert className="w-6 h-6 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-display font-black text-sm text-amber-400 tracking-tight uppercase flex items-center gap-1.5">
                <span>💡 Recommended Prerequisites (Cisco Foundational Tracks)</span>
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed font-sans max-w-3xl">
                Under PatchWire Cyber standards, completing <strong className="text-white">Cisco Networking Basics</strong> and <strong className="text-white">Cybersecurity Basics</strong> first is strongly recommended for absolute beginners. However, <strong className="text-cyan-400">direct learning is unlocked</strong> for you. You can start this track immediately or explore Cisco foundations concurrently.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-3 pl-9">
            <button
              onClick={() => onNavigate("course-detail", { id: "cisco-network-basics" })}
              className="px-4 py-2 bg-amber-950/40 border border-amber-500/20 hover:border-amber-400 hover:bg-amber-950/80 text-amber-400 hover:text-white font-mono text-[10px] font-bold rounded-lg transition-all uppercase cursor-pointer"
            >
              [ Complete Cisco Networking ]
            </button>
            <button
              onClick={() => onNavigate("course-detail", { id: "cisco-cyber-basics" })}
              className="px-4 py-2 bg-amber-950/40 border border-amber-500/20 hover:border-amber-400 hover:bg-amber-950/80 text-amber-400 hover:text-white font-mono text-[10px] font-bold rounded-lg transition-all uppercase cursor-pointer"
            >
              [ Complete Cisco Cyber ]
            </button>
          </div>
        </div>
      )}

      {/* CURRICULUM INTERFACE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* SYLLABUS LIST (4 COLS) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-900 pb-2">
            <h2 className="font-display font-bold text-lg text-white">Course Curriculum</h2>
            {enrolled && (
              <div className="flex items-center space-x-2" id="auto-redirect-toggle-container">
                <span className="text-[10px] text-slate-400 font-mono">Auto-Open Labs:</span>
                <button
                  type="button"
                  id="auto-redirect-toggle-btn"
                  onClick={() => setAutoRedirect(!autoRedirect)}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border border-slate-800 transition-colors duration-200 ease-in-out focus:outline-none ${
                    autoRedirect ? "bg-cyan-500" : "bg-slate-800"
                  }`}
                  title="Toggle automatic redirection when selecting nodes"
                >
                  <span
                    className={`pointer-events-none inline-block h-3 w-3 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      autoRedirect ? "translate-x-4 mt-0.5" : "translate-x-1 mt-0.5"
                    }`}
                  />
                </button>
              </div>
            )}
          </div>
          
          <div className="space-y-4">
            {track.modules.map((mod, idx) => (
              <div key={mod.id} className="p-4 bg-slate-900/30 border border-slate-800 rounded-2xl text-left space-y-3">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono text-cyan-400 uppercase">Module {idx + 1}</span>
                  <h3 className="font-display font-bold text-sm text-white">{mod.title}</h3>
                </div>

                <div className="divide-y divide-slate-800/40">
                  {mod.lessons.map((les) => {
                    const isCompleted = completedLessons.includes(les.id);
                    const isActive = activeLesson?.id === les.id;

                    return (
                      <div
                        key={les.id}
                        className={`w-full py-2 flex items-center justify-between transition-all border-b border-slate-900/10 text-xs ${
                          isActive ? "bg-cyan-950/20 px-2 rounded-xl border border-cyan-500/20" : ""
                        }`}
                      >
                        <button
                          disabled={!enrolled || isPrerequisiteBlocked}
                          onClick={() => selectLesson(les)}
                          className={`flex items-center space-x-2 truncate flex-grow text-left py-1 ${
                            isActive ? "text-cyan-400 font-semibold" : "text-slate-300 hover:text-white"
                          } ${(!enrolled || isPrerequisiteBlocked) ? "cursor-not-allowed opacity-60" : "cursor-pointer"}`}
                        >
                          {isPrerequisiteBlocked ? <Lock className="w-3.5 h-3.5 text-amber-500 shrink-0" /> : 
                           les.type === "video" ? <Play className="w-3.5 h-3.5 text-cyan-400 shrink-0" /> :
                           les.type === "lab" ? <Terminal className="w-3.5 h-3.5 text-cyan-400 shrink-0" /> :
                           les.type === "pdf" ? <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" /> :
                           <HelpCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                          <span className="truncate">{les.title}</span>
                        </button>

                        <div className="flex items-center space-x-2 shrink-0 pl-3">
                          {!enrolled ? (
                            <Lock className="w-3 h-3 text-slate-600" />
                          ) : isPrerequisiteBlocked ? (
                            <Lock className="w-3 h-3 text-amber-500" />
                          ) : (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleToggleLessonCompletion(les.id);
                              }}
                              className="focus:outline-none transition-colors p-1 hover:bg-slate-800 rounded cursor-pointer"
                              title={isCompleted ? "Mark incomplete" : "Mark completed"}
                            >
                              {isCompleted ? (
                                <div className="flex items-center space-x-1">
                                  <span className="text-[9px] text-emerald-400 font-mono font-bold uppercase hidden md:inline-block">Done</span>
                                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                                </div>
                              ) : (
                                <div className="flex items-center space-x-1">
                                  <span className="text-[9px] text-slate-500 font-mono hidden md:inline-block">{les.duration}</span>
                                  <div className="w-4 h-4 rounded border border-slate-600 hover:border-cyan-400 flex items-center justify-center shrink-0">
                                    {/* Empty checkbox */}
                                  </div>
                                </div>
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* LAB TERMINAL / ACTIVE LESSON VIEW (8 COLS) */}
        <div className="lg:col-span-8">
          <div className="glass-panel rounded-3xl p-6 min-h-[450px] relative overflow-hidden bg-slate-950/20">
            
            {isPrerequisiteBlocked ? (
              <div className="flex flex-col items-center justify-center text-center space-y-4 py-24">
                <Lock className="w-10 h-10 text-amber-500 animate-pulse" />
                <h3 className="font-display font-bold text-white text-base">Workspace Locked</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                  Prerequisite courses must be completed first. Please complete the <strong className="text-amber-400">Cisco Networking Basics</strong> and <strong className="text-amber-400">Cybersecurity Basics</strong> tracks to activate this workspace terminal.
                </p>
                <div className="flex gap-2 justify-center">
                  <button
                    onClick={() => onNavigate("course-detail", { id: "cisco-network-basics" })}
                    className="px-4 py-2 bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                  >
                    Networking Basics
                  </button>
                  <button
                    onClick={() => onNavigate("course-detail", { id: "cisco-cyber-basics" })}
                    className="px-4 py-2 bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                  >
                    Cybersecurity Basics
                  </button>
                </div>
              </div>
            ) : !enrolled ? (
              <div className="flex flex-col items-center justify-center text-center space-y-4 py-24">
                <Lock className="w-10 h-10 text-slate-600" />
                <h3 className="font-display font-bold text-white text-base">Terminal Env Locked</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                  Active practical shells, video streams, graded quizzes, and verification codes are locked. Enroll to gain system access.
                </p>
                <button
                  onClick={() => onNavigate("checkout", { trackId: track.id })}
                  className="px-5 py-2 bg-cyan-950 border border-cyan-400/30 text-cyan-400 hover:text-white hover:bg-cyan-900/30 text-xs font-semibold rounded transition-colors"
                >
                  Unlock Curriculum
                </button>
              </div>
            ) : !activeLesson ? (
              <div className="flex flex-col items-center justify-center text-center space-y-4 py-24">
                <Terminal className="w-10 h-10 text-slate-600" />
                <h3 className="font-display font-bold text-white text-base">Select Lesson</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                  Click on any curriculum node in the sidebar to configure the workspace.
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                
                {/* Active Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-900 pb-3 gap-2">
                  <div className="text-left space-y-0.5">
                    <span className="text-[9px] font-mono text-cyan-400 uppercase font-bold tracking-wider">// DYNAMIC LAB WORKSPACE // SIDE-BY-SIDE THEORY & PRACTICALS</span>
                    <h3 className="font-display font-bold text-sm text-white">{activeLesson.title}</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => setActiveTab(activeLesson.type === "quiz" ? "quiz" : "lab")}
                      className={`px-3 py-1 font-mono text-[9px] uppercase tracking-wider font-bold rounded border transition-all cursor-pointer ${
                        activeTab !== "quiz" 
                          ? "bg-cyan-950 text-cyan-400 border-cyan-400/30" 
                          : "bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300"
                      }`}
                    >
                      Workspace Console
                    </button>
                    {activeLesson.quizQuestions && (
                      <button
                        onClick={() => setActiveTab("quiz")}
                        className={`px-3 py-1 font-mono text-[9px] uppercase tracking-wider font-bold rounded border transition-all cursor-pointer ${
                          activeTab === "quiz" 
                            ? "bg-cyan-950 text-cyan-400 border-cyan-400/30" 
                            : "bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300"
                        }`}
                      >
                        Module Exam
                      </button>
                    )}
                  </div>
                </div>

                {showPrerequisiteWarning && (
                  <div className="p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl text-[10.5px] text-amber-300 font-sans leading-relaxed text-left flex items-start gap-2">
                    <span className="shrink-0">💡</span>
                    <div>
                      <strong>Cisco Foundations Recommended:</strong> Absolute beginners should ideally complete the <span className="text-white underline cursor-pointer hover:text-cyan-400" onClick={() => onNavigate("course-detail", { id: "cisco-network-basics" })}>Cisco Networking Essentials</span> and <span className="text-white underline cursor-pointer hover:text-cyan-400" onClick={() => onNavigate("course-detail", { id: "cisco-cyber-basics" })}>Cisco Cybersecurity Fundamentals</span> tracks first. Direct access is active for this track.
                    </div>
                  </div>
                )}

                {/* SIDE BY SIDE GRID CONTAINER */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-start text-left">
                  
                  {/* LEFT COLUMN: THEORY & STUDY GUIDE */}
                  <div className="space-y-5 bg-slate-950/40 p-5 rounded-2xl border border-slate-900 xl:max-h-[750px] xl:overflow-y-auto custom-scrollbar">
                    <div className="flex items-center justify-between border-b border-slate-900 pb-2.5">
                      <div className="flex items-center space-x-2">
                        <BookOpen className="w-4 h-4 text-cyan-400" />
                        <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-bold">// 1. THEORY & CONCEPTS STUDY GUIDE</span>
                      </div>
                      <span className="px-1.5 py-0.5 bg-slate-900 text-slate-500 rounded text-[8px] font-mono uppercase tracking-widest">TEXTBOOK</span>
                    </div>

                    {(() => {
                      const guide = getTechnicalLessonStudyGuide(activeLesson);
                      return (
                        <div className="space-y-5">
                          {/* A. Introduction */}
                          <div className="space-y-1.5">
                            <h4 className="text-xs font-bold text-white uppercase tracking-tight flex items-center gap-1">
                              <span className="text-cyan-400 font-mono">1.1</span> Core Introduction
                            </h4>
                            <p className="text-[11.5px] text-slate-300 leading-relaxed font-sans bg-slate-900/20 p-3 rounded-xl border border-slate-900">
                              {guide.introduction}
                            </p>
                          </div>

                          {/* B. Key Concepts */}
                          <div className="space-y-1.5">
                            <h4 className="text-xs font-bold text-white uppercase tracking-tight flex items-center gap-1">
                              <span className="text-cyan-400 font-mono">1.2</span> Architecture & Taxonomy
                            </h4>
                            <ul className="space-y-2 text-[11px] text-slate-300 pl-1 font-sans">
                              {guide.keyConcepts.map((concept, index) => {
                                const parts = concept.split(": ");
                                const titlePart = parts[0];
                                const descPart = parts.slice(1).join(": ");
                                return (
                                  <li key={index} className="leading-relaxed bg-slate-900/10 p-2.5 rounded-xl border border-slate-900/30">
                                    <strong className="text-cyan-400 font-mono text-[10.5px] uppercase tracking-wider block mb-0.5">{titlePart}</strong>
                                    <span className="text-slate-400">{descPart}</span>
                                  </li>
                                );
                              })}
                            </ul>
                          </div>

                          {/* C. Crucial Console Commands */}
                          <div className="space-y-1.5">
                            <h4 className="text-xs font-bold text-white uppercase tracking-tight flex items-center gap-1">
                              <span className="text-cyan-400 font-mono">1.3</span> Terminal Console Cheatsheet
                            </h4>
                            <div className="grid grid-cols-1 gap-2">
                              {guide.commands.map((cmdObj, index) => (
                                <div key={index} className="p-2.5 bg-slate-950 border border-slate-900 rounded-xl flex flex-col space-y-1 hover:border-cyan-500/20 transition-all group">
                                  <div className="flex items-center justify-between">
                                    <code className="text-cyan-300 font-mono text-[10px] font-bold select-all bg-slate-900/50 px-1.5 py-0.5 rounded border border-cyan-500/10 w-fit">
                                      {cmdObj.cmd}
                                    </code>
                                    <span className="text-[8px] font-mono text-slate-600 group-hover:text-cyan-400/40 uppercase tracking-widest">// CLICK_TO_COPY</span>
                                  </div>
                                  <span className="text-[10px] text-slate-400 font-sans leading-relaxed">{cmdObj.desc}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* D. Operational Steps */}
                          <div className="space-y-1.5">
                            <h4 className="text-xs font-bold text-white uppercase tracking-tight flex items-center gap-1">
                              <span className="text-cyan-400 font-mono">1.4</span> Standard Operational Workflow
                            </h4>
                            <div className="space-y-1.5 pl-1">
                              {guide.stepByStep.map((step, index) => (
                                <p key={index} className="text-[11px] text-slate-300 font-sans leading-relaxed bg-slate-900/10 p-2.5 rounded border border-slate-800/30">
                                  {step}
                                </p>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* RIGHT COLUMN: PRACTICAL EXPERIENCE, TERMINALS & 3 TRYHACKME LABS */}
                  <div className="space-y-5">
                    
                    {activeTab === "quiz" ? (
                      /* GRADED MCQS QUIZ PANEL */
                      <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-900 space-y-5">
                        <div className="flex items-center justify-between border-b border-slate-900 pb-2.5">
                          <div className="flex items-center space-x-2">
                            <HelpCircle className="w-4 h-4 text-cyan-400" />
                            <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-bold">// 2. DYNAMIC GRADED EXAM CORES</span>
                          </div>
                          <span className="px-1.5 py-0.5 bg-cyan-950 text-cyan-400 border border-cyan-400/20 rounded text-[8px] font-mono uppercase tracking-widest font-bold">GRADED</span>
                        </div>

                        {!quizGraded ? (
                          <div className="space-y-4">
                            {activeLesson.quizQuestions && activeLesson.quizQuestions.map((q, idx) => (
                              <div key={q.id} className="space-y-2.5">
                                <span className="text-[9px] font-mono text-cyan-400 block uppercase">Question {idx + 1} of {activeLesson.quizQuestions?.length}</span>
                                <h4 className="font-display font-bold text-xs text-white leading-relaxed">{q.question}</h4>
                                <div className="grid grid-cols-1 gap-2 pl-2">
                                  {q.options.map((opt, oIdx) => (
                                    <button
                                      type="button"
                                      key={oIdx}
                                      onClick={() => setQuizAnswers({ ...quizAnswers, [q.id]: oIdx })}
                                      className={`text-left p-3 rounded-lg border text-xs transition-all cursor-pointer ${
                                        quizAnswers[q.id] === oIdx 
                                          ? "bg-cyan-950/40 border-cyan-400 text-white" 
                                          : "bg-slate-900/40 border-slate-800 text-slate-400 hover:border-cyan-500/10"
                                      }`}
                                    >
                                      {opt}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            ))}

                            <button 
                              onClick={() => handleQuizSubmit(activeLesson.quizQuestions!)}
                              className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg cursor-pointer transition-colors shadow shadow-cyan-500/20"
                            >
                              Submit Examination Answers
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-6">
                            <div className="p-4 bg-cyan-950/40 border border-cyan-400/20 rounded-2xl text-center space-y-2">
                              <span className="text-[10px] font-mono text-cyan-400 uppercase block">Grading Complete</span>
                              <h4 className="font-display font-bold text-lg text-white">Your Score: {quizScore}%</h4>
                              <p className="text-xs text-slate-400">Earned 150 XP. Review the explanations below.</p>
                              {completedLessons.length >= totalLessonsCount && (
                                <div className="pt-2">
                                  <button
                                    onClick={handleGraduate}
                                    className="w-full py-2 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-white font-sans text-xs font-bold rounded-lg shadow cursor-pointer transition-all flex items-center justify-center space-x-1"
                                  >
                                    <span>🎓 Complete Internship & Enroll in Next Level</span>
                                    <ArrowRight className="w-3.5 h-3.5 animate-pulse" />
                                  </button>
                                </div>
                              )}
                            </div>

                            <div className="space-y-4 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar">
                              {activeLesson.quizQuestions && activeLesson.quizQuestions.map((q) => {
                                const userAns = quizAnswers[q.id];
                                const isCorrect = userAns === q.correctAnswerIndex;

                                return (
                                  <div key={q.id} className="p-4 bg-slate-900/40 border border-slate-800 rounded-xl space-y-2 text-xs">
                                    <h5 className="font-bold text-white">{q.question}</h5>
                                    <div className="space-y-1">
                                      <p className="text-[11px] text-slate-400">Your Answer: <span className={isCorrect ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>{q.options[userAns] || "None"}</span></p>
                                      <p className="text-[11px] text-slate-400">Correct Answer: <span className="text-emerald-400 font-bold">{q.options[q.correctAnswerIndex]}</span></p>
                                    </div>
                                    <p className="text-[10px] text-cyan-400/80 leading-relaxed font-sans mt-2 pl-2 border-l border-cyan-500/20">{q.explanation}</p>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      /* DYNAMIC PRACTICAL LAB PANEL */
                      <div className="space-y-5">
                        
                        {/* THE 3 TRYHACKME STRUCTURED LABS */}
                        <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-900 space-y-4">
                          <div className="flex items-center justify-between border-b border-slate-900 pb-2.5">
                            <div className="flex items-center space-x-2">
                              <Terminal className="w-4 h-4 text-cyan-400" />
                              <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-bold">// 2. TRYHACKME PRACTICALS (3 FREE LABS)</span>
                            </div>
                            <span className="px-1.5 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-500/20 rounded text-[8px] font-mono uppercase tracking-widest font-bold">LEVEL-WISE</span>
                          </div>

                          <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                            Complete the following three structured, level-wise TryHackMe target machines. Spin up the free attack boxes, execute commands, and secure the system flag:
                          </p>

                          <div className="space-y-3">
                            {getTryHackMeLabsForLesson(activeLesson, track.id).map((lab, lidx) => (
                              <div key={lidx} className="p-3 bg-slate-950 border border-slate-900 hover:border-cyan-500/20 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 transition-all">
                                <div className="space-y-1 text-left">
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <span className="text-[8.5px] font-mono text-cyan-400 uppercase tracking-wider font-bold bg-cyan-950/40 px-1.5 py-0.5 rounded border border-cyan-400/10">
                                      {lab.level}
                                    </span>
                                    <span className="text-[8px] font-mono text-emerald-400 font-bold bg-emerald-950/40 px-1 py-0.5 rounded border border-emerald-500/10">
                                      {lab.badge}
                                    </span>
                                  </div>
                                  <h4 className="font-display font-bold text-xs text-white">{lab.title}</h4>
                                  <p className="text-[10.5px] text-slate-400 font-sans leading-relaxed max-w-md">{lab.desc}</p>
                                </div>
                                <a
                                  href={lab.url}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="px-3 py-1.5 bg-cyan-950 border border-cyan-400/30 hover:border-cyan-400 text-cyan-400 hover:text-white font-mono text-[9px] uppercase font-bold rounded-lg text-center whitespace-nowrap transition-colors shrink-0 cursor-pointer"
                                >
                                  [ Launch Lab ]
                                </a>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* SANDBOX CLI SIMULATOR */}
                        <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-900 space-y-3">
                          <div className="flex items-center justify-between border-b border-slate-900 pb-2">
                            <span className="text-[9px] font-mono text-cyan-400 uppercase font-bold tracking-widest">// LOCAL TERMINAL SANDBOX CLI</span>
                            <span className="text-[8px] font-mono text-slate-600 uppercase">SYS_ACTIVE_SHELL</span>
                          </div>

                          <div className="p-4 bg-black border border-cyan-500/10 rounded-xl font-mono text-[10.5px] h-44 overflow-y-auto space-y-1 flex flex-col justify-end text-cyan-500 custom-scrollbar">
                            <div className="flex-grow overflow-y-auto select-text">
                              {terminalHistory.map((line, i) => (
                                <div key={i} className="whitespace-pre-wrap">{line}</div>
                              ))}
                            </div>
                            <form onSubmit={handleTerminalCommand} className="flex items-center space-x-1.5 border-t border-cyan-500/10 pt-1 mt-1">
                              <span className="shrink-0 text-cyan-600">operator@patchwire:~#</span>
                              <input 
                                type="text" 
                                value={terminalInput}
                                onChange={(e) => setTerminalInput(e.target.value)}
                                placeholder="Type commands like: help, nmap, exploit, flag"
                                className="flex-grow bg-transparent focus:outline-none border-none text-cyan-400 font-mono"
                              />
                            </form>
                          </div>
                        </div>

                        {/* FLAG SUBMISSION INPUT */}
                        <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-900 space-y-3">
                          <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider flex items-center gap-1.5">
                            <span className="text-cyan-400">🏁 VERIFY SYSTEM FLAGS</span>
                          </h4>

                          {labSuccess ? (
                            <div className="p-3.5 bg-emerald-950/20 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-semibold flex items-center space-x-1.5">
                              <CheckCircle className="w-4 h-4 animate-bounce shrink-0" />
                              <span>System flag accepted! Node compromised successfully. Earned +150 XP.</span>
                            </div>
                          ) : (
                            <div className="space-y-2">
                              <form onSubmit={handleFlagSubmit} className="flex items-center gap-2">
                                <input 
                                  type="text" 
                                  required
                                  value={flagSubmitted}
                                  onChange={(e) => { setFlagSubmitted(e.target.value); setFlagError(""); }}
                                  placeholder="e.g. flag{ethical_hacking_compromised_node_99}"
                                  className="flex-grow bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2 text-xs text-white focus:outline-none font-mono"
                                />
                                <button 
                                  type="submit"
                                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-semibold rounded cursor-pointer shrink-0 transition-colors"
                                >
                                  Submit Flag
                                </button>
                              </form>
                              {flagError && (
                                <div className="p-2 bg-rose-950/20 border border-rose-500/25 text-rose-300 text-[10px] font-mono rounded-lg">
                                  [SYS_ERR: {flagError}]
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                      </div>
                    )}

                  </div>

                </div>

              </div>
            )}

          </div>
        </div>

      </div>
    </div>
  );
}

// ==========================================
// 3. CHECKOUT / UPI QR CODE PAYMENT PAGE
// ==========================================
export function CheckoutPage({ 
  user, 
  trackId, 
  onNavigate 
}: { 
  user: any; 
  trackId: string; 
  onNavigate: (page: string, params?: any) => void;
}) {
  const track = CYBER_TRACKS.find(t => t.id === trackId);
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Access Code checkout state
  const [checkoutMethod, setCheckoutMethod] = useState<"upi" | "code">("upi");
  const [accessCodeInput, setAccessCodeInput] = useState("");
  const [codeClaimError, setCodeClaimError] = useState("");
  const [codeClaimSuccess, setCodeClaimSuccess] = useState("");

  if (!track) {
    return (
      <div className="py-20 text-center text-xs text-slate-500 font-mono">
        [ERROR: INELIGIBLE_CHECKOUT_PATH]
      </div>
    );
  }

  // Simulated screenshot selector that outputs fake base64 mock receipt
  const triggerFakeScreenshot = () => {
    setScreenshot("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=60");
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!utr) return;
    setLoading(true);

    setTimeout(() => {
      // Create payment record
      db.createPayment(track.id, track.price, utr.trim().toUpperCase(), screenshot || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400");
      setLoading(false);
      setSubmitted(true);
    }, 1000);
  };

  const handleRedeemCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessCodeInput.trim()) return;
    setCodeClaimError("");
    setCodeClaimSuccess("");
    setLoading(true);

    setTimeout(() => {
      const result = db.claimAccessCode(user.id, accessCodeInput);
      setLoading(false);
      if (result.success) {
        setCodeClaimSuccess(result.message || "Access Granted!");
        setTimeout(() => {
          onNavigate("dashboard");
        }, 2000);
      } else {
        setCodeClaimError(result.message);
      }
    }, 1000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12 text-left">
      <div className="text-center space-y-3">
        <h1 className="font-display font-bold text-3xl text-white">Unlock <span className="text-cyan-400">{track.title}</span></h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto leading-relaxed">
          Acquire the sandbox terminal license using a digital UPI transfer or redeem a standard operations authorization code.
        </p>
      </div>

      {/* CHECKOUT METHODS TOGGLER */}
      <div className="flex justify-center max-w-md mx-auto bg-slate-950 p-1 border border-slate-900 rounded-xl">
        <button
          type="button"
          onClick={() => setCheckoutMethod("upi")}
          className={`flex-1 py-2 rounded-lg text-xs font-mono transition-all cursor-pointer ${
            checkoutMethod === "upi"
              ? "bg-cyan-950/40 text-cyan-400 border border-cyan-500/20 font-bold"
              : "text-slate-400 hover:text-white"
          }`}
        >
          UPI Transaction Verification
        </button>
        <button
          type="button"
          onClick={() => setCheckoutMethod("code")}
          className={`flex-1 py-2 rounded-lg text-xs font-mono transition-all cursor-pointer ${
            checkoutMethod === "code"
              ? "bg-cyan-950/40 text-cyan-400 border border-cyan-500/20 font-bold"
              : "text-slate-400 hover:text-white"
          }`}
        >
          Redeem Access Code
        </button>
      </div>

      {checkoutMethod === "code" ? (
        <div className="max-w-md mx-auto">
          <div className="glass-panel p-8 rounded-2xl space-y-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-1 bg-cyan-400"></div>
            
            <form onSubmit={handleRedeemCode} className="space-y-4 text-left">
              <h3 className="font-display font-bold text-base text-white">Enter Operation Voucher</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                If you have been issued a platform voucher code or scholarship key, type it below to activate instant curriculum access.
              </p>

              {codeClaimSuccess && (
                <div className="p-3.5 bg-emerald-950/30 border border-emerald-500/20 text-emerald-300 text-xs rounded-lg font-sans flex items-center space-x-2 animate-pulse">
                  <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>{codeClaimSuccess} Redirecting to dashboard...</span>
                </div>
              )}

              {codeClaimError && (
                <div className="p-3.5 bg-rose-950/30 border border-rose-500/20 text-rose-300 text-xs rounded-lg font-sans flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>{codeClaimError}</span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400 uppercase">Access Code</label>
                <input 
                  type="text" 
                  required
                  value={accessCodeInput}
                  onChange={(e) => setAccessCodeInput(e.target.value.toUpperCase())}
                  placeholder="e.g. CYBER-START-99"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-3 text-xs text-white focus:outline-none uppercase font-mono tracking-widest placeholder:text-slate-600"
                />
              </div>

              <button
                type="submit"
                disabled={loading || !accessCodeInput.trim() || !!codeClaimSuccess}
                className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans font-bold text-xs rounded-lg shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2 disabled:opacity-40"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Authorizing voucher claim...</span>
                  </>
                ) : (
                  <span>Redeem & Activate License</span>
                )}
              </button>
            </form>
          </div>
        </div>
      ) : submitted ? (
        <div className="max-w-xl mx-auto glass-panel p-8 rounded-3xl text-center space-y-5 scanline-container">
          <div className="w-12 h-12 rounded-full bg-cyan-950 border border-cyan-400 flex items-center justify-center mx-auto text-cyan-400 animate-bounce">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-white">Verification Pending Approval</h3>
          <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
            Your UPI transaction ID <span className="text-cyan-400 font-bold font-mono uppercase">{utr}</span> has been logged. Our operations group is cross-verifying. Track unlocks dynamically in 1-2 hours.
          </p>
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onNavigate("dashboard")}
              className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-semibold rounded-lg"
            >
              Go to My Dashboard
            </button>
            <button
              onClick={() => onNavigate("tracks")}
              className="px-4 py-2.5 bg-slate-900 border border-slate-800 text-slate-400 text-xs rounded hover:text-white"
            >
              Browse Catalog
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-5xl mx-auto">
          
          {/* LEFT COLUMN: QR CODE & ACCOUNT DETS (5 COLS) */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            <div className="glass-panel p-6 rounded-2xl flex flex-col items-center justify-center text-center space-y-4">
              <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">[SECURE UPI GATEWAY GATE]</span>
              
              {/* Fake QR Asset */}
              <div className="p-4 bg-white rounded-2xl border-4 border-cyan-500/30">
                <QrCode className="w-40 h-40 text-slate-950" />
              </div>

              <div className="space-y-1 text-xs">
                <span className="text-slate-500 font-mono">UPI ID ADDRESS</span>
                <p className="font-mono font-bold text-white text-base">pay@patchwirecyber</p>
              </div>

              <div className="space-y-1 text-xs border-t border-slate-900 pt-3 w-full">
                <span className="text-slate-500 font-mono block">Required Payment Amount</span>
                <p className="font-display font-bold text-white text-xl">₹{track.price} <span className="text-xs text-cyan-400 font-mono">INR</span></p>
              </div>
            </div>

            <div className="p-4 bg-cyan-950/15 border border-cyan-500/10 rounded-xl text-left text-xs text-slate-400 leading-relaxed font-sans">
              <span className="text-cyan-400 font-bold block mb-1">Payment Instructions:</span>
              1. Open your UPI app (GPay, PhonePe, Paytm, BHIM).<br />
              2. Scan the QR code above or type address <span className="text-white font-mono">pay@patchwirecyber</span>.<br />
              3. Enter exact course value and execute payment.<br />
              4. Locate the 12-digit UPI Transaction ID / Reference (UTR).
            </div>
          </div>

          {/* RIGHT COLUMN: MANIFEST SUBMISSION FORM (7 COLS) */}
          <div className="lg:col-span-7">
            <div className="glass-panel p-8 rounded-2xl space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-1 bg-cyan-400"></div>
              
              <form onSubmit={handleSubmitPayment} className="space-y-4 text-left">
                <h3 className="font-display font-bold text-base text-white">Log Payment Manifest</h3>
                
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400 uppercase">UPI UTR Transaction ID (12 Digits)</label>
                  <input 
                    type="text" 
                    required
                    maxLength={12}
                    minLength={12}
                    value={utr}
                    onChange={(e) => setUtr(e.target.value)}
                    placeholder="e.g. 129988334455"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-3 text-xs text-white focus:outline-none uppercase font-mono tracking-widest"
                  />
                  <span className="text-[9px] text-slate-500 font-mono block uppercase">UTR must be exactly 12 numeric/alpha characters.</span>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-mono text-slate-400 uppercase">Screenshot Upload Receipt</label>
                  
                  {screenshot ? (
                    <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <ImageIcon className="w-5 h-5 text-cyan-400" />
                        <span className="text-xs text-slate-300 font-mono">receipt_compromise_99.png</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setScreenshot("")}
                        className="text-xs text-rose-400 hover:text-white"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div 
                      onClick={triggerFakeScreenshot}
                      className="border-2 border-dashed border-slate-800 hover:border-cyan-500/30 rounded-xl p-8 text-center cursor-pointer space-y-2 hover:bg-cyan-950/5 transition-colors"
                    >
                      <Upload className="w-8 h-8 text-slate-500 mx-auto" />
                      <span className="text-xs text-slate-400 block font-sans">Click to simulate Screenshot receipt upload</span>
                      <span className="text-[9px] text-slate-600 font-mono block">Supports PNG, JPG, JPEG</span>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={loading || !utr || !screenshot}
                  className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans font-bold text-xs rounded-lg shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2 disabled:opacity-40"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Logging secure ledger...</span>
                    </>
                  ) : (
                    <span>Submit Payment Receipt</span>
                  )}
                </button>
              </form>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}

// ==========================================
// 4. ADMIN PORTAL (Payment approvals, announcements)
// ==========================================
export function AdminPortalPage() {
  const [payments, setPayments] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<"payments" | "announcements" | "access-codes">("payments");
  const [selectedPay, setSelectedPay] = useState<any | null>(null);

  // Announcement State
  const [annTitle, setAnnTitle] = useState("");
  const [annMsg, setAnnMsg] = useState("");
  const [annSubmitted, setAnnSubmitted] = useState(false);

  // Access Codes State
  const [accessCodes, setAccessCodes] = useState<any[]>([]);
  const [newCode, setNewCode] = useState("");
  const [selectedTrack, setSelectedTrack] = useState("");
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  const reloadPayments = () => {
    setPayments(db.getPayments());
  };

  const reloadAccessCodes = () => {
    setAccessCodes(db.getAccessCodes());
  };

  useEffect(() => {
    reloadPayments();
    reloadAccessCodes();
  }, []);

  const handleApprove = (pId: string) => {
    db.updatePaymentStatus(pId, PaymentStatus.APPROVED);
    reloadPayments();
    setSelectedPay(null);
  };

  const handleReject = (pId: string) => {
    db.updatePaymentStatus(pId, PaymentStatus.REJECTED);
    reloadPayments();
    setSelectedPay(null);
  };

  const handleAnnounce = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle || !annMsg) return;
    db.createAnnouncement(annTitle, annMsg);
    setAnnTitle("");
    setAnnMsg("");
    setAnnSubmitted(true);
    setTimeout(() => setAnnSubmitted(false), 3000);
  };

  const handleCreateCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode || !selectedTrack) return;
    db.createAccessCode(newCode, selectedTrack);
    setNewCode("");
    setSelectedTrack("");
    reloadAccessCodes();
  };

  const handleGenerateRandomCode = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code = "PWC-";
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewCode(code);
  };

  const handleToggleCodeStatus = (cId: string) => {
    db.toggleAccessCodeStatus(cId);
    reloadAccessCodes();
  };

  const handleDeleteCode = (cId: string) => {
    if (confirm("Are you sure you want to delete this access code?")) {
      db.deleteAccessCode(cId);
      reloadAccessCodes();
    }
  };

  const handleCopyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  const getTrackTitle = (trackId: string) => {
    if (trackId === "ultimate-pack") return "Ultimate Pack Bundle";
    if (trackId === "soc-grc-bundle") return "SOC + GRC Bundle";
    if (trackId === "red-team-bundle") return "Red Team Bundle";
    return CYBER_TRACKS.find(t => t.id === trackId)?.title || trackId;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-10 text-left">
      <div className="flex items-center space-x-2">
        <ShieldAlert className="w-6 h-6 text-cyan-400 animate-pulse" />
        <h1 className="font-display font-bold text-2xl text-white">HQ <span className="text-cyan-400">Operations</span> Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* SIDEBAR TABS (3 COLS) */}
        <div className="lg:col-span-3 flex flex-col space-y-1">
          <button
            onClick={() => setActiveTab("payments")}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-mono transition-all cursor-pointer ${
              activeTab === "payments" 
                ? "bg-cyan-950/50 text-cyan-400 border border-cyan-500/30" 
                : "text-slate-400 hover:text-white hover:bg-slate-900/40"
            }`}
          >
            Verify UPI Receipts ({payments.filter(p => p.status === PaymentStatus.PENDING).length})
          </button>
          <button
            onClick={() => setActiveTab("announcements")}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-mono transition-all cursor-pointer ${
              activeTab === "announcements" 
                ? "bg-cyan-950/50 text-cyan-400 border border-cyan-500/30" 
                : "text-slate-400 hover:text-white hover:bg-slate-900/40"
            }`}
          >
            Push Announcements
          </button>
          <button
            onClick={() => setActiveTab("access-codes")}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-mono transition-all cursor-pointer ${
              activeTab === "access-codes" 
                ? "bg-cyan-950/50 text-cyan-400 border border-cyan-500/30" 
                : "text-slate-400 hover:text-white hover:bg-slate-900/40"
            }`}
          >
            Manage Access Codes ({accessCodes.length})
          </button>
        </div>

        {/* WORKSPACE CONTENT (9 COLS) */}
        <div className="lg:col-span-9 space-y-6">
          
          {/* A. MANAGE UPI PAYMENTS */}
          {activeTab === "payments" && (
            <div className="space-y-6">
              <h2 className="font-display font-bold text-lg text-white border-b border-slate-900 pb-2">Pending UPI Verifications</h2>
              
              {payments.filter(p => p.status === PaymentStatus.PENDING).length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-10 font-mono">[FINANCE_LEDGER_CLEAN: ALL PAYMENTS TRIAGED]</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {payments.filter(p => p.status === PaymentStatus.PENDING).map((pay) => (
                    <div 
                      key={pay.id} 
                      className="glass-panel p-5 rounded-2xl flex flex-col justify-between space-y-4 hover:border-cyan-400/20 transition-all cursor-pointer"
                      onClick={() => setSelectedPay(pay)}
                    >
                      <div className="space-y-1">
                        <span className="text-[9px] font-mono text-yellow-500 uppercase tracking-widest">PENDING_LEDGER_CHECK</span>
                        <h4 className="font-display font-bold text-sm text-slate-200">{pay.trackTitle}</h4>
                        <div className="space-y-0.5 text-[10px] font-mono text-slate-400">
                          <p>User: {pay.userName} ({pay.userEmail})</p>
                          <p>UTR Hash: <span className="text-cyan-400 uppercase">{pay.utr}</span></p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-slate-900/40 text-[10px] font-mono">
                        <span className="text-slate-500">Amt: ₹{pay.amount}</span>
                        <span className="text-cyan-400 font-bold uppercase hover:underline">Verify Receipt &rarr;</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* DETAILED LEDGER CHECK OVERLAY MODAL */}
              {selectedPay && (
                <div className="glass-panel p-6 rounded-3xl max-w-2xl border-cyan-400/30 space-y-6 bg-slate-950/95 relative scanline-container">
                  <button 
                    onClick={() => setSelectedPay(null)}
                    className="absolute top-4 right-4 text-slate-500 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  <h3 className="font-display font-bold text-sm text-white uppercase tracking-wider">Validate UPI Receipt Record</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start text-xs font-mono">
                    <div className="space-y-3 pl-2 border-l border-cyan-500/20">
                      <p><span className="text-slate-500">Applicant:</span> <span className="text-white">{selectedPay.userName}</span></p>
                      <p><span className="text-slate-500">Target Track:</span> <span className="text-white">{selectedPay.trackTitle}</span></p>
                      <p><span className="text-slate-500">Claim Amount:</span> <span className="text-cyan-400 font-bold">₹{selectedPay.amount}</span></p>
                      <p><span className="text-slate-500">UTR Code:</span> <span className="text-white uppercase">{selectedPay.utr}</span></p>
                    </div>

                    {/* Screenshot Preview */}
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-500 uppercase tracking-widest block">Uploaded screenshot</span>
                      <div className="h-44 w-full rounded-xl border border-slate-800 overflow-hidden bg-slate-900 flex items-center justify-center">
                        <img 
                          src={selectedPay.screenshotUrl} 
                          alt="upi receipt" 
                          className="w-full h-full object-cover" 
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-4 border-t border-slate-900">
                    <button
                      onClick={() => handleApprove(selectedPay.id)}
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-sans text-xs font-bold rounded-lg cursor-pointer"
                    >
                      Approve & Unlock Course
                    </button>
                    <button
                      onClick={() => handleReject(selectedPay.id)}
                      className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-sans text-xs font-bold rounded-lg cursor-pointer"
                    >
                      Reject Payment
                    </button>
                    <button
                      onClick={() => setSelectedPay(null)}
                      className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-400 text-xs rounded-lg"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* B. PUSH GLOBAL ANNOUNCEMENTS */}
          {activeTab === "announcements" && (
            <div className="space-y-6">
              <h2 className="font-display font-bold text-lg text-white border-b border-slate-900 pb-2">Publish Platform Announcements</h2>
              
              <div className="glass-panel p-6 rounded-2xl">
                {annSubmitted && (
                  <div className="p-3 bg-emerald-950/20 border border-emerald-500/20 text-emerald-300 text-xs rounded-lg font-sans mb-4 flex items-center space-x-1.5">
                    <CheckCircle className="w-4 h-4 animate-bounce" />
                    <span>Global secure notification emitted successfully to all student streams.</span>
                  </div>
                )}
                
                <form onSubmit={handleAnnounce} className="space-y-4 text-left font-sans">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Announcement Title</label>
                    <input 
                      type="text" 
                      required
                      value={annTitle}
                      onChange={(e) => setAnnTitle(e.target.value)}
                      placeholder="e.g. Critical Server Node maintenance scheduled"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Message Content</label>
                    <textarea
                      rows={4}
                      required
                      value={annMsg}
                      onChange={(e) => setAnnMsg(e.target.value)}
                      placeholder="Broadcasting details regarding lab releases, CTF completions..."
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-bold rounded-lg flex items-center space-x-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Emit Announcement</span>
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* C. MANAGE ACCESS CODES */}
          {activeTab === "access-codes" && (
            <div className="space-y-6">
              <h2 className="font-display font-bold text-lg text-white border-b border-slate-900 pb-2">Voucher & Access Code Generator</h2>
              
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Create Access Code Form */}
                <div className="lg:col-span-5 glass-panel p-6 rounded-2xl h-fit space-y-4">
                  <h3 className="font-display font-bold text-sm text-slate-200">Generate New Access Code</h3>
                  
                  <form onSubmit={handleCreateCode} className="space-y-4 text-left text-xs font-sans">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono text-slate-400 uppercase">Access Code string</label>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          required
                          value={newCode}
                          onChange={(e) => setNewCode(e.target.value.toUpperCase())}
                          placeholder="e.g. CYBER-PRO-2026"
                          className="flex-1 bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none font-mono uppercase tracking-wider placeholder:text-slate-600"
                        />
                        <button
                          type="button"
                          onClick={handleGenerateRandomCode}
                          className="px-3 py-2 bg-slate-900 border border-slate-800 hover:border-cyan-400/30 text-cyan-400 rounded-lg font-mono text-[10px]"
                        >
                          Auto
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono text-slate-400 uppercase">Grant Access To</label>
                      <select
                        required
                        value={selectedTrack}
                        onChange={(e) => setSelectedTrack(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-slate-300 focus:outline-none"
                      >
                        <option value="">-- Select Track or Bundle --</option>
                        <optgroup label="Value Bundles">
                          <option value="soc-grc-bundle">SOC + GRC Bundle (₹129)</option>
                          <option value="red-team-bundle">Red Team Bundle (₹249)</option>
                          <option value="ultimate-pack">Ultimate Cybersecurity Bundle (₹699)</option>
                        </optgroup>
                        <optgroup label="Basic Tracks">
                          {CYBER_TRACKS.filter(t => t.price <= 59).map(t => (
                            <option key={t.id} value={t.id}>{t.title} (₹{t.price})</option>
                          ))}
                        </optgroup>
                        <optgroup label="Professional Tracks">
                          {CYBER_TRACKS.filter(t => t.price > 59).map(t => (
                            <option key={t.id} value={t.id}>{t.title} (₹{t.price})</option>
                          ))}
                        </optgroup>
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={!newCode || !selectedTrack}
                      className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white font-sans text-xs font-bold rounded-lg flex items-center justify-center space-x-1.5 cursor-pointer"
                    >
                      <Key className="w-3.5 h-3.5" />
                      <span>Activate Code</span>
                    </button>
                  </form>
                </div>

                {/* List Existing Access Codes */}
                <div className="lg:col-span-7 space-y-4">
                  <h3 className="font-display font-bold text-sm text-slate-200">Active Access Codes Ledger</h3>
                  
                  {accessCodes.length === 0 ? (
                    <div className="glass-panel p-10 text-center text-xs text-slate-500 font-mono">
                      [NO_CODES_GENERATED]
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[450px] overflow-y-auto pr-1">
                      {accessCodes.map((code) => {
                        const isClaimed = !!code.usedBy;
                        const isDisabled = code.status === "disabled";
                        
                        return (
                          <div 
                            key={code.id} 
                            className={`glass-panel p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
                              isClaimed 
                                ? "border-slate-900 opacity-60 bg-slate-950/20" 
                                : isDisabled 
                                ? "border-rose-950/40 bg-rose-950/5" 
                                : "border-cyan-500/10 hover:border-cyan-500/20"
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <span className="font-mono font-bold text-xs text-cyan-400 tracking-wider uppercase bg-cyan-950/50 border border-cyan-400/20 px-2 py-0.5 rounded">
                                  {code.code}
                                </span>
                                <button
                                  onClick={() => handleCopyCode(code.code, code.id)}
                                  className="text-slate-500 hover:text-white transition-colors cursor-pointer"
                                  title="Copy code to clipboard"
                                >
                                  {copiedCodeId === code.id ? (
                                    <span className="text-[9px] font-mono text-emerald-400 uppercase">Copied!</span>
                                  ) : (
                                    <span className="text-[9px] font-mono text-slate-400 hover:underline">Copy</span>
                                  )}
                                </button>
                              </div>

                              <span className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded ${
                                isClaimed 
                                  ? "bg-slate-900 text-slate-400" 
                                  : isDisabled 
                                  ? "bg-rose-950 text-rose-400" 
                                  : "bg-emerald-950 text-emerald-400 border border-emerald-400/20"
                              }`}>
                                {isClaimed ? "Redeemed" : isDisabled ? "Inactive" : "Active"}
                              </span>
                            </div>

                            <div className="text-[11px] space-y-1 text-slate-300 font-sans">
                              <p>
                                <span className="text-slate-500 font-mono text-[9px] uppercase mr-2">Unlocks:</span>
                                <span className="text-slate-200 font-semibold">{getTrackTitle(code.trackId)}</span>
                              </p>
                              {isClaimed && (
                                <p className="text-[10px] text-slate-500 font-mono">
                                  Claimed by UUID <span className="text-slate-400">{code.usedBy}</span> at {new Date(code.usedAt!).toLocaleDateString()}
                                </p>
                              )}
                            </div>

                            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-900/40">
                              {!isClaimed && (
                                <button
                                  onClick={() => handleToggleCodeStatus(code.id)}
                                  className="text-[10px] font-mono text-cyan-400 hover:underline cursor-pointer"
                                >
                                  {isDisabled ? "Activate" : "Deactivate"}
                                </button>
                              )}
                              <button
                                onClick={() => handleDeleteCode(code.id)}
                                className="text-[10px] font-mono text-rose-400 hover:underline cursor-pointer"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
