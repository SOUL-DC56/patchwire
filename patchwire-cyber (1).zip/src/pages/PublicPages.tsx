import React, { useState, useEffect, useRef } from "react";
import { 
  ShieldCheck, ArrowRight, Terminal, Award, Users, BookOpen, 
  HelpCircle, Check, Mail, Send, MapPin, Phone, ShieldAlert, CheckCircle2, ChevronDown, ChevronUp,
  Clock, Sparkles, TrendingUp, Layers, Zap, Star, MessageSquare, Plus, ThumbsUp, X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CourseTrack, Review } from "../types";
import { CYBER_TRACKS } from "../data/tracks";
import { db } from "../lib/supabase";

// ==========================================
// 3D INTERACTIVE HOLOGRAPHIC TERMINAL
// ==========================================
function HolographicTerminal3D() {
  const [activeTab, setActiveTab] = useState<"offensive" | "defensive" | "logs" | "cracking">("offensive");
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Real-time cybersecurity events logs
  const [simulatedLogs, setSimulatedLogs] = useState<string[]>([
    "09:14:02 UTC - [SEC_OPS] Initializing containerized sandbox node...",
    "09:14:04 UTC - [RECON_SHIELD] TCP/IP Port scan detected from subnet 192.168.1.104",
    "09:14:05 UTC - [FIREWALL_ALERT] Unauthorized segment request on network 10.10.20.0/24",
    "09:14:06 UTC - [SYS_DEFENSE] Deploying automated active filtering countermeasures..."
  ]);

  // Keep logs streaming
  useEffect(() => {
    const events = [
      "FTP socket blocked on root node-04",
      "Cryptographic signature check successful on payload_sha256",
      "Buffer overflow mitigation integrity: [100% OK]",
      "Active network reconnaissance vector identified",
      "AES-256 session handshake confirmed via SSL/TLS",
      "Heuristics scan completed on system_daemon: ACTIVE",
      "Flag compiled and verified: flag{sandbox_pcca_pass_920}"
    ];
    
    const interval = setInterval(() => {
      const randomEvent = events[Math.floor(Math.random() * events.length)];
      const timestamp = new Date().toISOString().split("T")[1].substring(0, 8);
      setSimulatedLogs(prev => {
        const next = [...prev, `${timestamp} UTC - [TELEMETRY] ${randomEvent}`];
        if (next.length > 5) next.shift();
        return next;
      });
    }, 4000);
    
    return () => clearInterval(interval);
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const el = containerRef.current;
    const rect = el.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    // Relative coordinates to element center
    const x = e.clientX - rect.left - width / 2;
    const y = e.clientY - rect.top - height / 2;
    
    // Smooth tilt factor
    const maxTiltX = 14; 
    const maxTiltY = 14; 
    
    setRotateX(-(y / (height / 2)) * maxTiltX);
    setRotateY((x / (width / 2)) * maxTiltY);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setIsHovered(false);
  };

  return (
    <div 
      ref={containerRef}
      className="w-full max-w-5xl mx-auto mt-12 sm:mt-16 perspective-1000 select-none px-2 sm:px-4 cursor-crosshair group"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onMouseEnter={() => setIsHovered(true)}
    >
      <div
        className="relative rounded-3xl border border-cyan-500/25 bg-slate-950/70 shadow-[0_0_50px_rgba(6,182,212,0.12)] overflow-hidden transition-all duration-300 ease-out"
        style={{
          transformStyle: "preserve-3d",
          transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(${isHovered ? 1.015 : 1})`,
        }}
      >
        {/* Holographic glowing canvas aura */}
        <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-3xl blur-2xl opacity-40 group-hover:opacity-75 transition-opacity duration-300 pointer-events-none" />
        
        {/* Fine scanning grid lines */}
        <div className="absolute inset-0 bg-scanlines opacity-5 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/40 via-transparent to-slate-950/80 pointer-events-none" />

        {/* TERMINAL HEADER SECTION */}
        <div 
          className="border-b border-slate-900/80 px-4 sm:px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-950/90 relative"
          style={{ transform: "translateZ(30px)", transformStyle: "preserve-3d" }}
        >
          <div className="flex items-center space-x-3">
            <div className="flex space-x-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500/60 border border-red-500/40"></span>
              <span className="w-3 h-3 rounded-full bg-yellow-500/60 border border-yellow-500/40"></span>
              <span className="w-3 h-3 rounded-full bg-green-500/60 border border-green-500/40"></span>
            </div>
            <div className="h-4 w-[1px] bg-slate-800"></div>
            <div className="flex items-center space-x-2 text-left">
              <Terminal className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className="font-mono text-[10px] text-slate-300 uppercase tracking-widest">patchwire_cyber_range_cli_v1.0.9</span>
            </div>
          </div>

          {/* Holographic Workspace Control Tabs */}
          <div className="flex flex-wrap gap-1 p-1 bg-slate-900/60 rounded-xl border border-slate-850/80">
            {(["offensive", "defensive", "logs", "cracking"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1.5 rounded-lg font-mono text-[9px] uppercase tracking-wider transition-all cursor-pointer ${
                  activeTab === tab 
                    ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-bold shadow-[0_0_15px_rgba(6,182,212,0.15)]" 
                    : "border border-transparent text-slate-500 hover:text-slate-300 hover:bg-slate-900"
                }`}
              >
                {tab === "offensive" && "Offensive Range"}
                {tab === "defensive" && "Defensive Blue"}
                {tab === "logs" && "Live Telemetry"}
                {tab === "cracking" && "Hash Decryptor"}
              </button>
            ))}
          </div>
        </div>

        {/* WORKSPACE CONTENT AREA */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-4 sm:p-6 min-h-[350px]">
          {/* TELEMETRY READOUTS PANEL (LEFT COLUMN) */}
          <div 
            className="lg:col-span-4 space-y-4"
            style={{ transform: "translateZ(25px)", transformStyle: "preserve-3d" }}
          >
            <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-2xl relative overflow-hidden text-left">
              <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></div>
              <span className="font-mono text-[9px] uppercase tracking-widest text-slate-500 block">[ SYSTEM STATUS REPORT ]</span>
              <div className="space-y-3 mt-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-sans">Lab Status</span>
                  <span className="text-emerald-400 font-mono uppercase font-bold text-[10px]">STABLE (100%)</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-sans">Active Targets</span>
                  <span className="text-cyan-400 font-mono">14 Virtual Nodes</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-sans">Sandbox Port</span>
                  <span className="text-slate-300 font-mono">3000 (INGRESS)</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-sans">Verification Engine</span>
                  <span className="text-yellow-500 font-mono text-[10px]">CRYPTOGRAPHIC</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-2xl text-left">
              <span className="font-mono text-[9px] uppercase tracking-widest text-slate-500 block">[ LIVE SUBNET TARGETS ]</span>
              <div className="mt-4 flex items-center justify-between border border-slate-900 p-3 rounded-xl bg-slate-900/10">
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></div>
                  <span className="font-mono text-[10px] text-cyan-400">10.10.88.10</span>
                </div>
                <span className="text-[9px] font-mono text-slate-500 uppercase">Target Host</span>
                <span className="text-[10px] font-mono text-emerald-400">[ONLINE]</span>
              </div>
              <div className="mt-2 flex items-center justify-between border border-slate-900 p-3 rounded-xl bg-slate-900/10">
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></div>
                  <span className="font-mono text-[10px] text-cyan-400">10.10.88.11</span>
                </div>
                <span className="text-[9px] font-mono text-slate-500 uppercase">Exploit Sandbox</span>
                <span className="text-[10px] font-mono text-emerald-400">[ONLINE]</span>
              </div>
            </div>
          </div>

          {/* ACTIVE GRAPHICAL VIEWPORT COLUMN */}
          <div 
            className="lg:col-span-8 bg-slate-950/90 border border-slate-900 rounded-2xl p-4 sm:p-5 relative overflow-hidden flex flex-col justify-between text-left"
            style={{ transform: "translateZ(45px)", transformStyle: "preserve-3d" }}
          >
            {/* Ambient cybergrid background */}
            <div className="absolute inset-0 bg-cyber-grid opacity-10 pointer-events-none" />

            <div className="space-y-4 flex-grow relative z-10">
              {activeTab === "offensive" && (
                <div className="space-y-3 font-mono text-xs text-slate-300">
                  <span className="text-[10px] text-red-400/95 tracking-wider font-bold block">[ OFFENSIVE PENETRATION SHELL ]</span>
                  <div className="space-y-1.5 bg-slate-900/30 border border-slate-900 p-3.5 rounded-xl font-mono text-[11px] leading-relaxed">
                    <p className="text-cyan-400">pw_shell &gt; <span className="text-white">nmap -sV -A -T4 10.10.88.10</span></p>
                    <p className="text-slate-500">Starting Nmap 7.92 ( https://nmap.org ) at 2026-07-04 09:14 UTC</p>
                    <p className="text-slate-400">Nmap scan report for target.patchwire.io (10.10.88.10)</p>
                    <p className="text-slate-400">Host is up (0.00045s latency).</p>
                    <p className="text-slate-300">Not shown: 997 closed tcp ports</p>
                    <p className="text-emerald-400">PORT     STATE SERVICE VERSION</p>
                    <p className="text-emerald-400">22/tcp   open  ssh     OpenSSH 8.2p1 Ubuntu</p>
                    <p className="text-emerald-400">80/tcp   open  http    Apache httpd 2.4.41</p>
                    <p className="text-yellow-500">8080/tcp open  http    Samba server (Vulnerable: CVE-2021-44228)</p>
                  </div>
                  <div className="flex items-center space-x-2 text-[10px] text-cyan-400">
                    <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                    <span>TARGET SYSTEM IDENTIFIED — READY FOR PROTOCOL EXPLOIT</span>
                  </div>
                </div>
              )}

              {activeTab === "defensive" && (
                <div className="space-y-3 font-mono text-xs text-slate-300">
                  <span className="text-[10px] text-blue-400/95 tracking-wider font-bold block">[ BLUE-TEAM SIEM MITIGATION ENGINE ]</span>
                  <div className="space-y-1.5 bg-slate-900/30 border border-slate-900 p-3.5 rounded-xl font-mono text-[11px] leading-relaxed">
                    <p className="text-blue-400">pw_siem &gt; <span className="text-white">analyze_incident --id INC-8821</span></p>
                    <p className="text-slate-500">Incident Severity Level: <span className="text-red-500 font-bold animate-pulse">CRITICAL INTRUSION DETECTED</span></p>
                    <p className="text-slate-300">Signature Match: <span className="text-yellow-500">DoublePulsar Backdoor Injection Probe</span></p>
                    <p className="text-slate-400">Target IP Address: <span className="text-white">10.10.200.41</span></p>
                    <p className="text-emerald-400">Defensive Action: Firewall egress rules fully re-routed to sandbox blackhole.</p>
                    <p className="text-emerald-400">Result: Countermeasure Successful. Host packet stream fully filtered.</p>
                  </div>
                  <div className="flex items-center space-x-2 text-[10px] text-blue-400">
                    <span className="inline-block w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                    <span>DEFENSIVE HONEYPOT SECURE SYSTEM RUNNING ON NODE-05</span>
                  </div>
                </div>
              )}

              {activeTab === "logs" && (
                <div className="space-y-3 font-mono text-xs text-slate-300">
                  <span className="text-[10px] text-emerald-400/95 tracking-wider font-bold block">[ REAL-TIME INCIDENT EVENTS STREAM ]</span>
                  <div className="space-y-1.5 bg-slate-900/30 border border-slate-900 p-3.5 rounded-xl font-mono text-[10px] h-[155px] overflow-hidden flex flex-col justify-end">
                    {simulatedLogs.map((log, index) => (
                      <p key={index} className="text-emerald-400/90 hover:text-white transition-colors border-l-2 border-emerald-500/20 pl-2 text-left">
                        {log}
                      </p>
                    ))}
                  </div>
                  <span className="text-[9px] text-slate-500 block text-right">Awaiting incoming telemetry streams...</span>
                </div>
              )}

              {activeTab === "cracking" && (
                <div className="space-y-3 font-mono text-xs text-slate-300">
                  <span className="text-[10px] text-yellow-500/95 tracking-wider font-bold block">[ SHA-256 PARALLEL CRYPTO DECRYPTOR ]</span>
                  <div className="space-y-3 bg-slate-900/30 border border-slate-900 p-4 rounded-xl font-mono text-[11px] leading-relaxed">
                    <p className="text-yellow-500">pw_crypto &gt; <span className="text-white">crack_hash 8f4e2c98d6b1fc994a5e01...</span></p>
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>Parallel Brute-force Status</span>
                        <span className="text-yellow-400 animate-pulse font-bold">89.4% Solved</span>
                      </div>
                      <div className="w-full bg-slate-950 h-2 border border-slate-800 rounded-full overflow-hidden">
                        <div className="bg-gradient-to-r from-yellow-500 to-amber-500 h-full w-[89.4%] animate-pulse"></div>
                      </div>
                    </div>
                    <p className="text-slate-400">Active Hash Rate: <span className="text-white">4,821,000 hashes/sec</span></p>
                    <p className="text-emerald-400 font-bold">Collision Target Identified: "secops_student_pcca_pass"</p>
                  </div>
                </div>
              )}
            </div>

            <div 
              className="mt-4 pt-4 border-t border-slate-900/80 flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10"
              style={{ transform: "translateZ(15px)" }}
            >
              <span className="text-[9px] text-slate-500 font-mono">CRYPTOGRAPHIC TELEMETRY TUNNEL ENCRYPTED</span>
              <div className="flex items-center space-x-1.5">
                <span className="text-[9px] font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-500/20 px-2 py-0.5 rounded uppercase font-bold">SHA-256 SECURE</span>
                <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/20 px-2 py-0.5 rounded uppercase font-bold">TLS 1.3</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 1. HOME PAGE
// ==========================================
export function HomePage({ onNavigate }: { onNavigate: (page: string, params?: any) => void }) {
  const [reviewsList, setReviewsList] = useState<Review[]>(() => db.getReviews());
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [newReviewName, setNewReviewName] = useState("");
  const [newReviewTrack, setNewReviewTrack] = useState("Ethical Hacking Basics");
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewContent, setNewReviewContent] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewName.trim() || !newReviewContent.trim()) return;
    
    const submitted = db.submitReview(
      newReviewName,
      newReviewTrack,
      newReviewRating,
      newReviewContent
    );
    
    setReviewsList([submitted, ...reviewsList]);
    setNewReviewName("");
    setNewReviewContent("");
    setNewReviewRating(5);
    setSuccessMessage("Review cryptographically signed and published to our career wall!");
    setTimeout(() => {
      setSuccessMessage("");
      setShowReviewModal(false);
    }, 2500);
  };

  const stats = [
    { value: "13+", label: "Cyber Security Career Tracks", icon: BookOpen },
    { value: "140+", label: "Immersive Practical Labs", icon: Terminal }
  ];

  return (
    <div className="space-y-20 pb-20 text-left">
      {/* HERO SECTION */}
      <section className="relative pt-12 md:pt-24 pb-16 flex flex-col items-center justify-center text-center px-4 scanline-container overflow-hidden rounded-3xl mx-2 md:mx-6 border border-cyan-500/10 bg-slate-950/40">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(6,182,212,0.12),transparent_70%)] pointer-events-none"></div>
        
        {/* Hacker Alert Badge */}
        <motion.div 
          initial={{ opacity: 0, y: -15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="inline-flex items-center space-x-2 px-3 py-1 bg-cyan-950/50 border border-cyan-500/30 rounded-full mb-6"
        >
          <Terminal className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          <span className="font-mono text-[10px] uppercase tracking-widest text-cyan-400">SECURE TRAINING MODE: ACTIVE</span>
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: "easeOut" }}
          className="font-display font-bold text-4xl md:text-6xl text-white tracking-tight leading-tight max-w-4xl mx-auto"
        >
          Next-Gen <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 animate-cyber-pulse">Cybersecurity</span> Virtual Internships
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
          className="font-sans text-slate-400 text-base md:text-lg max-w-2xl mx-auto mt-6 leading-relaxed"
        >
          Master highly practical offensive and defensive skills. Break real systems, analyze log streams, hunt ransomware, and graduate with certified enterprise-grade cyber experience.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10"
        >
          <button
            onClick={() => onNavigate("tracks")}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-sans font-semibold rounded-lg hover:from-cyan-400 hover:to-blue-500 hover:shadow-lg hover:shadow-cyan-500/15 transition-all cursor-pointer flex items-center justify-center space-x-2 group"
          >
            <span>Explore Practical Tracks</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
          </button>
          
          <button
            onClick={() => onNavigate("pricing")}
            className="w-full sm:w-auto px-8 py-3.5 glass-panel border border-cyan-500/20 hover:border-cyan-400/50 text-cyan-400 hover:text-white font-sans font-semibold rounded-lg hover:bg-cyan-950/10 transition-all cursor-pointer"
          >
            View Pricing Plans
          </button>
        </motion.div>

        {/* INTERACTIVE 3D HOLOGRAPHIC TERMINAL CONTAINER */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: "spring", damping: 22, stiffness: 65, delay: 0.4 }}
          className="w-full"
        >
          <HolographicTerminal3D />
        </motion.div>
      </section>

      {/* STATS SECTION */}
      <section className="max-w-3xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
        {stats.map((stat, idx) => (
          <motion.div 
            key={idx} 
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5, delay: idx * 0.15 }}
            whileHover={{ y: -6, scale: 1.025, borderColor: "rgba(6, 182, 212, 0.3)" }}
            className="glass-panel p-6 rounded-2xl flex flex-col items-center justify-center text-center relative overflow-hidden transition-all duration-300"
          >
            <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-cyan-400/40"></div>
            <div className="p-3 bg-cyan-950/40 rounded-xl border border-cyan-500/20 mb-4">
              <stat.icon className="w-6 h-6 text-cyan-400" />
            </div>
            <span className="font-display font-bold text-3xl md:text-4xl text-white">{stat.value}</span>
            <span className="text-xs font-mono uppercase text-slate-400 tracking-wider mt-1">{stat.label}</span>
          </motion.div>
        ))}
      </section>

      {/* WHAT WE ARE & WHY WE CHARGE */}
      <section className="max-w-7xl mx-auto px-4 py-4">
        <div className="glass-panel p-8 rounded-3xl border border-cyan-500/10 bg-slate-950/20 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-cyan-500 to-blue-600"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center animate-fade-in text-left">
            <div className="lg:col-span-5 space-y-4">
              <span className="font-mono text-[10px] uppercase text-cyan-400 tracking-widest block">[ CORE ARCHITECTURE ]</span>
              <h2 className="font-display font-bold text-2xl md:text-3xl text-white">
                What We Are & <span className="text-cyan-400">Why We Charge</span>
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                PatchWire Cyber is India's premium virtual cyber range and hands-on laboratory platform. We do not teach with passive slides; we build secure sandboxed operating terminals, custom-compiled target applications, and automated flag verification engines.
              </p>
              <div className="p-4 bg-slate-900/30 border border-slate-800 rounded-xl space-y-2">
                <span className="text-[10px] text-yellow-500 font-mono font-bold block">⚠️ LAB STABILITY & STUDENT SECURITY:</span>
                <p className="text-[11px] text-slate-400">
                  By utilizing an independent micro-investment model (with foundational tracks as low as ₹9), we remain fully self-sufficient. This lets us host stable container environments and maintain a high-availability learning sandbox for every ambitious student.
                </p>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 bg-slate-900/20 border border-slate-900 rounded-2xl hover:border-cyan-500/20 transition-all space-y-3">
                <div className="p-2.5 bg-cyan-950/40 rounded-xl border border-cyan-500/20 w-fit">
                  <Zap className="w-4 h-4 text-cyan-400" />
                </div>
                <h4 className="font-display font-bold text-sm text-white">Live Browser Sandboxes</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Your subscription fee directly finances our live virtual terminals, giving you active command lines, packet decoders, and secure vulnerability simulation environments.
                </p>
              </div>

              <div className="p-5 bg-slate-900/20 border border-slate-900 rounded-2xl hover:border-cyan-500/20 transition-all space-y-3">
                <div className="p-2.5 bg-cyan-950/40 rounded-xl border border-cyan-500/20 w-fit">
                  <Award className="w-4 h-4 text-cyan-400" />
                </div>
                <h4 className="font-display font-bold text-sm text-white font-sans">Cryptographic Verification</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  We run a live cryptographic verification portal. Potential employers can instant-check your certificate IDs to confirm legitimate security achievements.
                </p>
              </div>

              <div className="p-5 bg-slate-900/20 border border-slate-900 rounded-2xl hover:border-cyan-500/20 transition-all space-y-3">
                <div className="p-2.5 bg-cyan-950/40 rounded-xl border border-cyan-500/20 w-fit">
                  <Users className="w-4 h-4 text-cyan-400" />
                </div>
                <h4 className="font-display font-bold text-sm text-white">On-Duty Support Engineers</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  We support actual certified security operators and blue-team instructors who manually verify UPI receipts and assist you through complex lab questions.
                </p>
              </div>

              <div className="p-5 bg-slate-900/20 border border-slate-900 rounded-2xl hover:border-cyan-500/20 transition-all space-y-3">
                <div className="p-2.5 bg-cyan-950/40 rounded-xl border border-cyan-500/20 w-fit">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                </div>
                <h4 className="font-display font-bold text-sm text-white font-sans">Strict Privacy Controls</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Your micro-investment ensures that PatchWire remains 100% ad-free, trackless, secure, and respectful of your data privacy.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* DYNAMIC TRACKS SPOTLIGHT */}
      <section className="max-w-7xl mx-auto px-4 space-y-8">
        <div className="text-center md:text-left">
          <h2 className="font-display font-bold text-2xl md:text-3xl text-white tracking-tight">
            Spotlight <span className="text-cyan-400">Programs</span>
          </h2>
          <p className="text-slate-400 text-sm mt-2 max-w-xl">
            Choose from offensive penetration testing, defensive SOC logistics, malware reverse engineering, or cloud auditing.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {CYBER_TRACKS.slice(0, 3).map((track) => (
            <div 
              key={track.id}
              className="glass-panel rounded-2xl overflow-hidden hover:border-cyan-400/40 hover:-translate-y-1.5 transition-all flex flex-col h-full group"
            >
              {/* Image banner */}
              <div className="h-44 relative overflow-hidden bg-slate-900">
                <img 
                  src={track.bannerImage} 
                  alt={track.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 brightness-90"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                <div className="absolute top-3 right-3 px-2 py-0.5 bg-cyan-950/80 border border-cyan-400/30 rounded text-[10px] font-mono uppercase text-cyan-400 tracking-wider">
                  {track.difficulty}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex flex-col flex-grow space-y-4">
                <h3 className="font-display font-bold text-lg text-white group-hover:text-cyan-400 transition-colors">
                  {track.title}
                </h3>
                <p className="text-slate-400 text-xs font-sans leading-relaxed flex-grow">
                  {track.description}
                </p>

                {/* Skills tags */}
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {track.skills.slice(0, 3).map((skill, i) => (
                    <span key={i} className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-[10px] text-slate-300 font-mono">
                      #{skill}
                    </span>
                  ))}
                </div>

                {/* Price and Action */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-900">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-500 font-mono uppercase">Enrollment Price</span>
                    <span className="font-display font-bold text-white text-base">₹{track.price} <span className="text-xs text-cyan-400 font-mono">INR</span></span>
                  </div>
                  <button 
                    onClick={() => onNavigate("tracks", { id: track.id })}
                    className="px-4 py-2 bg-cyan-950/50 border border-cyan-500/20 hover:border-cyan-400 hover:bg-cyan-900/30 text-cyan-400 font-sans text-xs font-semibold rounded transition-all cursor-pointer flex items-center space-x-1"
                  >
                    <span>View Track</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center pt-4">
          <button 
            onClick={() => onNavigate("tracks")}
            className="px-6 py-2.5 bg-slate-900 border border-slate-800 hover:border-cyan-500/30 text-slate-300 hover:text-cyan-400 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
          >
            Browse All 13 Cyber Tracks
          </button>
        </div>
      </section>

      {/* STUDENT TESTIMONIALS & REVIEWS SECTION */}
      <section className="max-w-7xl mx-auto px-4 py-8 space-y-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="text-left space-y-2">
            <span className="font-mono text-[10px] uppercase text-cyan-400 tracking-widest block">[ CRITICAL VERDICT WALL ]</span>
            <h2 className="font-display font-bold text-2xl md:text-3xl text-white tracking-tight">
              Verified Student <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 animate-cyber-pulse">Testimonials</span>
            </h2>
            <p className="text-slate-400 text-sm max-w-xl">
              Authentic feedback from working professionals and students who transformed their capabilities in our simulated sandboxes.
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-900/30 border border-slate-850 p-4 rounded-2xl">
            <div className="text-left">
              <div className="flex items-center space-x-1">
                <span className="font-display font-bold text-xl text-white">4.9</span>
                <span className="text-xs text-slate-500 font-sans">/ 5.0</span>
                <div className="flex items-center space-x-0.5 ml-1.5">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  ))}
                </div>
              </div>
              <p className="text-[10px] font-mono text-slate-400 mt-1 uppercase">based on verified feedback</p>
            </div>
            <div className="h-8 w-[1px] bg-slate-800"></div>
            <button
              onClick={() => setShowReviewModal(true)}
              className="px-4 py-2 bg-cyan-950/60 border border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-900/20 text-cyan-400 text-xs font-mono uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center space-x-2 shadow-lg shadow-cyan-950/50 hover:shadow-cyan-900/10"
            >
              <Plus className="w-3.5 h-3.5 text-cyan-400" />
              <span>Write A Review</span>
            </button>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviewsList.map((review, idx) => (
            <motion.div 
              key={review.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: Math.min(idx * 0.12, 0.6) }}
              whileHover={{ y: -6, scale: 1.025, borderColor: "rgba(6, 182, 212, 0.3)", boxShadow: "0 10px 30px -10px rgba(6, 182, 212, 0.15)" }}
              className="glass-panel p-6 rounded-2xl border border-slate-850 flex flex-col justify-between relative bg-slate-950/20 group transition-all duration-300"
            >
              {/* Corner accent */}
              <div className="absolute top-2 right-2 w-1 h-1 rounded-full bg-cyan-500/30"></div>
              
              <div className="space-y-4">
                {/* Header info */}
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 bg-cyan-950/40 border border-cyan-500/20 rounded text-[9px] font-mono text-cyan-400 uppercase tracking-widest flex items-center space-x-1">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                    <span>VERIFIED ENROLLMENT</span>
                  </span>
                  <div className="flex items-center space-x-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`w-3 h-3 ${i < review.rating ? "text-amber-400 fill-amber-400" : "text-slate-800"}`} />
                    ))}
                  </div>
                </div>

                <p className="text-xs text-slate-300 italic leading-relaxed font-sans text-left">
                  "{review.content}"
                </p>
              </div>

              {/* Author info */}
              <div className="flex items-center space-x-3.5 pt-4 border-t border-slate-900 mt-6 text-left">
                <img 
                  src={review.avatarUrl || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${encodeURIComponent(review.studentName)}`} 
                  alt={review.studentName}
                  className="w-9 h-9 rounded-xl border border-slate-800 bg-slate-900"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-grow">
                  <h4 className="font-display font-bold text-xs text-white uppercase tracking-wide">{review.studentName}</h4>
                  <span className="text-[10px] text-cyan-400/90 font-mono block mt-0.5">{review.studentTrack}</span>
                </div>
                <div className="text-[9px] text-slate-500 font-mono uppercase">
                  {new Date(review.date).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* REVIEW MODAL OVERLAY */}
        {showReviewModal && (
          <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="glass-panel-heavy max-w-lg w-full rounded-3xl border border-cyan-500/20 bg-slate-950 relative overflow-hidden p-8 space-y-6 animate-fade-in scanline-container">
              
              {/* Header */}
              <div className="flex items-center justify-between">
                <div className="space-y-1 text-left">
                  <span className="font-mono text-[9px] text-cyan-400 uppercase tracking-widest">[ SECURITY TESTIMONIAL PORTAL ]</span>
                  <h3 className="font-display font-bold text-xl text-white">Publish Student Review</h3>
                </div>
                <button 
                  onClick={() => setShowReviewModal(false)}
                  className="p-1.5 bg-slate-900 hover:bg-slate-850 rounded-xl border border-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Success Notification */}
              {successMessage ? (
                <div className="p-8 text-center space-y-4 bg-slate-900/20 border border-cyan-500/20 rounded-2xl">
                  <div className="w-12 h-12 bg-cyan-950/50 border border-cyan-400 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6 text-cyan-400" />
                  </div>
                  <h4 className="font-display font-bold text-white text-base">Transmission Authenticated</h4>
                  <p className="text-xs text-slate-400 leading-relaxed max-w-sm mx-auto">
                    {successMessage}
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmitReview} className="space-y-4">
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Your Name</label>
                    <input 
                      type="text" 
                      required
                      value={newReviewName}
                      onChange={(e) => setNewReviewName(e.target.value)}
                      placeholder="e.g. Piyush Pattnaik"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl p-3 text-xs text-white focus:outline-none font-sans"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono text-slate-400 uppercase">Your Track</label>
                      <select
                        value={newReviewTrack}
                        onChange={(e) => setNewReviewTrack(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl p-3 text-xs text-white focus:outline-none"
                      >
                        <option value="Ethical Hacking Basics">Ethical Hacking Basics</option>
                        <option value="SOC Basics">SOC Basics</option>
                        <option value="Network Security Basics">Network Security Basics</option>
                        <option value="SOC Analyst">SOC Analyst</option>
                        <option value="VAPT Professional">VAPT Professional</option>
                        <option value="Digital Forensics">Digital Forensics</option>
                        <option value="Cloud Security Advanced">Cloud Security Advanced</option>
                        <option value="Ultimate Pack Bundle">Ultimate Pack Bundle</option>
                        <option value="SOC + GRC Bundle">SOC + GRC Bundle</option>
                        <option value="Red Team Bundle">Red Team Bundle</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono text-slate-400 uppercase">Terminal Rating</label>
                      <div className="flex items-center space-x-1 p-2 bg-slate-950 border border-slate-800 rounded-xl h-[46px]">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <button
                            type="button"
                            key={i}
                            onClick={() => setNewReviewRating(i + 1)}
                            className="p-1 hover:scale-125 transition-transform cursor-pointer"
                          >
                            <Star 
                              className={`w-5 h-5 ${
                                i < newReviewRating 
                                  ? "text-amber-400 fill-amber-400 filter drop-shadow-[0_0_4px_rgba(245,158,11,0.5)]" 
                                  : "text-slate-800"
                              }`} 
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Your Testimonial</label>
                    <textarea
                      rows={4}
                      required
                      value={newReviewContent}
                      onChange={(e) => setNewReviewContent(e.target.value)}
                      placeholder="Share your practical experience with our sandboxed lab environment, lessons, or career guidance..."
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-xl p-3 text-xs text-white focus:outline-none font-sans"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit & Cryptographically Sign</span>
                  </button>
                </form>
              )}

              <div className="text-center font-mono text-[9px] text-slate-600">
                SECURE RECORD TRANSACTION GUID: {Math.random().toString(36).substring(2, 12).toUpperCase()}
              </div>

            </div>
          </div>
        )}
      </section>
    </div>
  );
}

// ==========================================
// 2. PRICING PAGE
// ==========================================
export function PricingPage({ onNavigate }: { onNavigate: (page: string, params?: any) => void }) {
  const [activeCategory, setActiveCategory] = useState<"basic" | "professional" | "bundles">("basic");

  const basicTracks = [
    {
      id: "soc-basics",
      title: "SOC Basics",
      desc: "Learn the fundamentals of Security Operations Center work, including log analysis, alert triage, and incident basics.",
      duration: "4 weeks",
      skills: ["Log Analysis", "Alert Triage", "SIEM Basics", "Incident Reports"],
      price: 29,
      labs: "16 Free Labs"
    },
    {
      id: "ethical-hacking-basics",
      title: "Ethical Hacking Basics",
      desc: "Get started with ethical hacking concepts, penetration testing methodology, and basic tools like Nmap and Metasploit.",
      duration: "4 weeks",
      skills: ["Recon Techniques", "Nmap & Metasploit", "Web Basics", "CTF Practice"],
      price: 29,
      labs: "16 Free Labs"
    },
    {
      id: "network-security-basics",
      title: "Network Security Basics",
      desc: "Understand network protocols, firewalls, VPNs, and common network attacks. Perfect starting point for any cyber career.",
      duration: "4 weeks",
      skills: ["OSI Model", "Firewall Config", "VPN Setup", "Packet Analysis"],
      price: 29,
      labs: "16 Free Labs"
    },
    {
      id: "cloud-security-basics",
      title: "Cloud Security Basics",
      desc: "Introduction to cloud security concepts, AWS/Azure basics, IAM, and the shared responsibility model.",
      duration: "4 weeks",
      skills: ["AWS & Azure Basics", "IAM Fundamentals", "S3 Security", "Cloud Labs"],
      price: 59,
      labs: "16 Free Labs"
    },
    {
      id: "basic-soc-internship",
      title: "Basic SOC Internship",
      desc: "Entry-level Security Operations Center internship covering log monitoring, alert triage, and incident basics.",
      duration: "4 weeks",
      skills: ["Log Monitoring", "Alert Triage", "SIEM Basics", "Practical Labs"],
      price: 19,
      labs: "16 Free Labs"
    },
    {
      id: "basic-forensics-internship",
      title: "Basic Digital Forensics Internship",
      desc: "Entry-level digital forensics internship. Learn evidence handling, file system basics, and beginner investigation techniques.",
      duration: "4 weeks",
      skills: ["Evidence Handling", "File System Analysis", "Chain of Custody", "Practical Labs"],
      price: 19,
      labs: "16 Free Labs"
    },
    {
      id: "digital-forensics-basics",
      title: "Digital Forensics Basics",
      desc: "Entry-level digital forensics program. Learn the fundamentals of evidence collection, file system analysis, and beginner investigation techniques.",
      duration: "4 weeks",
      skills: ["Evidence Collection", "File System Analysis", "Memory Forensics Intro", "Chain of Custody"],
      price: 9,
      labs: "16 Free Labs"
    }
  ];

  const professionalTracks = [
    {
      id: "soc-analyst",
      title: "SOC Analyst",
      badge: "Most Popular",
      desc: "Master SOC operations with real-world SIEM tools, threat hunting, incident response, and advanced log correlation across enterprise environments.",
      duration: "8 weeks",
      skills: ["SIEM Mastery", "Threat Hunting", "IR Procedures", "Malware Analysis"],
      price: 99,
      labs: "32 Free Labs"
    },
    {
      id: "vapt",
      title: "VAPT",
      badge: "Highest Rated",
      desc: "Comprehensive Vulnerability Assessment and Penetration Testing program. Covers web, network, and mobile app pentesting with real-world engagements.",
      duration: "12 weeks",
      skills: ["Web App Pentesting", "Network VAPT", "Burp Suite Pro", "Report Writing"],
      price: 199,
      labs: "48 Free Labs"
    },
    {
      id: "grc",
      title: "GRC",
      desc: "Governance, Risk and Compliance track covering ISO 27001, GDPR, NIST frameworks, risk assessments, and audit preparation.",
      duration: "8 weeks",
      skills: ["ISO 27001", "GDPR Compliance", "NIST Framework", "Risk Assessments"],
      price: 49,
      labs: "32 Free Labs"
    },
    {
      id: "digital-forensics",
      title: "Digital Forensics",
      desc: "Learn digital forensics investigation techniques using industry tools like Autopsy, Volatility, and FTK for memory, disk, and network forensics.",
      duration: "12 weeks",
      skills: ["Memory Forensics", "Disk Analysis", "Network Forensics", "Chain of Custody"],
      price: 69,
      labs: "48 Free Labs"
    },
    {
      id: "cloud-security-advanced",
      title: "Cloud Security Advanced",
      desc: "Advanced cloud security covering AWS, Azure, and GCP security architectures, CSPM, CASB, DevSecOps, and cloud compliance frameworks.",
      duration: "16 weeks",
      skills: ["AWS/Azure/GCP Security", "CSPM & CASB", "DevSecOps", "Cloud Forensics"],
      price: 399,
      labs: "64 Free Labs"
    }
  ];

  const bundles = [
    {
      id: "soc-grc-bundle",
      title: "SOC + GRC Bundle",
      badge: "Best Value",
      desc: "Get deep defense readiness + compliance structure. Perfect combo for enterprise Security Operations.",
      duration: "10 weeks",
      price: 129,
      originalPrice: 148,
      features: [
        "SOC Analyst Track included",
        "GRC Track included",
        "Bundled Labs & Quizzes",
        "Priority Verification Support",
        "Both Verification Certificates",
        "Both Enrollment Letters"
      ],
      labs: "4-Week Lab Curriculum (16 Free Labs)",
      coreTrackId: "soc-analyst"
    },
    {
      id: "red-team-bundle",
      title: "Red Team Bundle",
      badge: "Power Pack",
      desc: "Offensive + blue-team forensics masterclass. Compromise systems then trace and document the security artifacts.",
      duration: "14 weeks",
      price: 249,
      originalPrice: 268,
      features: [
        "VAPT Track included",
        "Digital Forensics Track included",
        "Advanced Red Team Labs",
        "24/7 Sandbox Terminal Access",
        "Both Verification Certificates",
        "Both Enrollment Letters"
      ],
      labs: "4-Week Lab Curriculum (16 Free Labs)",
      coreTrackId: "vapt"
    },
    {
      id: "ultimate-pack",
      title: "Ultimate Pack",
      badge: "Full Stack Security",
      desc: "The ultimate cybersecurity bundle: SOC, VAPT, GRC, Digital Forensics, and Cloud Security. Everything you need to become a complete security professional.",
      duration: "24 weeks total",
      price: 699,
      originalPrice: 984,
      features: [
        "All 5 Advanced Tracks",
        "All Labs & Resources Included",
        "Career Placement Support",
        "All Certificates & Enrollment Letters",
        "Lifetime Community Access",
        "Prioritized Manual Payments Review"
      ],
      labs: "24-Week Lab Curriculum (96 Free Labs)",
      coreTrackId: "cloud-security-advanced"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-12 text-left">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="font-display font-bold text-3xl md:text-5xl text-white">
          Transparent, <span className="text-cyan-400">Micro-Investment</span> Pricing
        </h1>
        <p className="text-slate-400 text-sm max-w-2xl mx-auto leading-relaxed">
          Start for as low as ₹9. Unlock hands-on sandbox environments, theoretical lectures, practical labs, and claim verified digital diplomas.
        </p>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap justify-center gap-3 border-b border-slate-900 pb-6">
        <button
          onClick={() => setActiveCategory("basic")}
          className={`px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border ${
            activeCategory === "basic"
              ? "bg-cyan-950/60 border-cyan-400 text-cyan-400 shadow shadow-cyan-500/10"
              : "border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
          }`}
        >
          <Sparkles className="w-4 h-4 inline-block mr-1.5 shrink-0 align-middle" />
          Basic Tracks (₹9 - ₹59)
        </button>
        <button
          onClick={() => setActiveCategory("professional")}
          className={`px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border ${
            activeCategory === "professional"
              ? "bg-cyan-950/60 border-cyan-400 text-cyan-400 shadow shadow-cyan-500/10"
              : "border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
          }`}
        >
          <TrendingUp className="w-4 h-4 inline-block mr-1.5 shrink-0 align-middle" />
          Professional Tracks (₹49 - ₹399)
        </button>
        <button
          onClick={() => setActiveCategory("bundles")}
          className={`px-5 py-2.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer border ${
            activeCategory === "bundles"
              ? "bg-cyan-950/60 border-cyan-400 text-cyan-400 shadow shadow-cyan-500/10"
              : "border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
          }`}
        >
          <Layers className="w-4 h-4 inline-block mr-1.5 shrink-0 align-middle" />
          Value Bundles (₹129 - ₹699)
        </button>
      </div>

      {/* Basic Tracks Section */}
      {activeCategory === "basic" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {basicTracks.map((track) => (
            <div 
              key={track.id}
              className="glass-panel rounded-2xl p-6 border border-slate-800 hover:border-cyan-500/20 transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] font-mono uppercase text-slate-400">
                    {track.duration}
                  </span>
                  <span className="text-[10px] text-cyan-400 font-mono">
                    {track.labs}
                  </span>
                </div>

                <div className="space-y-2">
                  <h3 className="font-display font-bold text-base text-white hover:text-cyan-400 transition-colors">
                    {track.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed min-h-[60px]">
                    {track.desc}
                  </p>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {track.skills.map((skill, sIdx) => (
                    <span key={sIdx} className="px-2 py-0.5 bg-slate-950 border border-slate-900 rounded text-[9px] text-slate-300 font-mono">
                      #{skill}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-slate-900 mt-6 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-[9px] text-slate-500 font-mono uppercase">Investment Fee</span>
                  <span className="font-display font-bold text-lg text-white">₹{track.price} <span className="text-xs text-cyan-400 font-mono">INR</span></span>
                </div>
                <button
                  onClick={() => onNavigate("checkout", { trackId: track.id })}
                  className="px-4 py-2 bg-cyan-950 border border-cyan-500/20 hover:border-cyan-400 text-cyan-400 hover:bg-cyan-900/30 font-sans text-xs font-semibold rounded-lg transition-all cursor-pointer"
                >
                  Enroll Now
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Professional Tracks Section */}
      {activeCategory === "professional" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {professionalTracks.map((track) => (
            <div 
              key={track.id}
              className={`glass-panel rounded-2xl p-6 border transition-all flex flex-col justify-between relative ${
                track.badge ? "border-cyan-500/30 bg-cyan-950/5" : "border-slate-800"
              }`}
            >
              {track.badge && (
                <span className="absolute top-0 right-6 -translate-y-1/2 px-2.5 py-0.5 bg-cyan-500 text-slate-950 font-mono text-[9px] uppercase font-bold rounded">
                  {track.badge}
                </span>
              )}

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] font-mono uppercase text-slate-400">
                    {track.duration}
                  </span>
                  <span className="text-[10px] text-cyan-400 font-mono">
                    {track.labs}
                  </span>
                </div>

                <div className="space-y-2">
                  <h3 className="font-display font-bold text-base text-white hover:text-cyan-400 transition-colors">
                    {track.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed min-h-[60px]">
                    {track.desc}
                  </p>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {track.skills.map((skill, sIdx) => (
                    <span key={sIdx} className="px-2 py-0.5 bg-slate-950 border border-slate-900 rounded text-[9px] text-slate-300 font-mono">
                      #{skill}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-slate-900 mt-6 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-[9px] text-slate-500 font-mono uppercase">Investment Fee</span>
                  <span className="font-display font-bold text-lg text-white">₹{track.price} <span className="text-xs text-cyan-400 font-mono">INR</span></span>
                </div>
                <button
                  onClick={() => onNavigate("checkout", { trackId: track.id })}
                  className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-sans text-xs font-semibold rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-all cursor-pointer"
                >
                  Enroll Now
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Bundles Section */}
      {activeCategory === "bundles" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bundles.map((bundle) => (
            <div 
              key={bundle.id}
              className="glass-panel rounded-2xl p-6 border border-cyan-500/20 hover:border-cyan-400/40 transition-all flex flex-col justify-between relative bg-slate-950/40"
            >
              <span className="absolute top-0 right-6 -translate-y-1/2 px-2.5 py-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-mono text-[9px] uppercase font-bold rounded">
                {bundle.badge}
              </span>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-[9px] font-mono uppercase text-slate-400">
                    {bundle.duration}
                  </span>
                  <span className="text-[9px] text-cyan-400 font-mono">
                    {bundle.labs}
                  </span>
                </div>

                <div className="space-y-2">
                  <h3 className="font-display font-bold text-base text-white">
                    {bundle.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed min-h-[50px]">
                    {bundle.desc}
                  </p>
                </div>

                <ul className="space-y-2 pt-2 border-t border-slate-900">
                  {bundle.features.map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start space-x-2 text-[11px] text-slate-300">
                      <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-6 border-t border-slate-900 mt-6 flex items-center justify-between">
                <div className="flex flex-col">
                  <div className="flex items-center space-x-1.5 text-[10px] text-slate-500 font-mono line-through">
                    <span>₹{bundle.originalPrice}</span>
                  </div>
                  <span className="font-display font-bold text-xl text-white">₹{bundle.price} <span className="text-xs text-cyan-400 font-mono">INR</span></span>
                </div>
                <button
                  onClick={() => onNavigate("checkout", { trackId: bundle.coreTrackId })}
                  className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-sans text-xs font-semibold rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-all cursor-pointer"
                >
                  Enroll Bundle
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Support Transparency Notice */}
      <div className="max-w-3xl mx-auto glass-panel border-cyan-500/10 p-6 rounded-2xl flex flex-col md:flex-row items-center gap-6">
        <div className="p-4 bg-cyan-950/40 rounded-xl border border-cyan-400/20 shrink-0">
          <ShieldCheck className="w-8 h-8 text-cyan-400" />
        </div>
        <div className="text-left space-y-2">
          <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">Transparency & Operations Note</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Fees cover hosting, platform maintenance, interactive sandboxes, verified digital certificates, payment gateway ledger charges, content updates, and student support. Contact <span className="text-cyan-400 font-mono">admin@patchwirecyber.co.in</span> for billing questions.
          </p>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 3. ABOUT PAGE
// ==========================================
export function AboutPage() {
  const philosophy = [
    {
      title: "Who We Are",
      text: "PatchWire Cyber is a dedicated, forward-thinking cybersecurity education initiative. We are a collection of red team operators, network defenders, and certification architects passionate about bridging the gap between scholastic theory and true tactical competence."
    },
    {
      title: "Our Mission & Vision",
      text: "To build the most practical, comprehensive, and cost-effective digital training framework. We aim to equip ambitious engineers in emerging technology sectors with secure defense methodologies, reducing systemic risk across globally networked infrastructures."
    },
    {
      title: "Hands-on Practical Training",
      text: "We reject slide-deck education. We believe expertise is formed when students decompile actual ransomware, scan unfiltered networks, intercept web request vectors, and reconstruct compromised databases. Every module ends with flag submissions in responsive mock targets."
    },
    {
      title: "Industry Focus",
      text: "Our tracks are modeled directly after authentic professional security mandates (PCI-DSS Audits, ISO 27001 mappings, NIST frameworks, OWASP compliance). We prepare students for ready transition into high-stress enterprise Security Operations."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-16 text-left">
      <div className="text-center space-y-4">
        <h1 className="font-display font-bold text-3xl md:text-5xl text-white">
          About <span className="text-cyan-400">PatchWire Cyber</span>
        </h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto leading-relaxed">
          Learn about our mission, vision, practical cyber methodologies, and elite curriculum architecture.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
        {philosophy.map((item, idx) => (
          <div key={idx} className="glass-panel p-8 rounded-2xl space-y-4 hover:border-cyan-400/25 transition-all">
            <h3 className="font-display font-bold text-lg text-cyan-400 border-l-2 border-cyan-500 pl-3">
              {item.title}
            </h3>
            <p className="text-xs text-slate-300 font-sans leading-relaxed">
              {item.text}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 4. CONTACT PAGE
// ==========================================
export function ContactPage() {
  const [formData, setFormData] = useState({ name: "", email: "", category: "Support", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setSubmitted(true);
  };

  const contactOptions = [
    { icon: Mail, label: "Company Main Email", val: "admin@patchwirecyber.co.in" },
    { icon: Mail, label: "Support Desk Email", val: "patchwire.support@gmail.com" },
    { icon: Mail, label: "Founder Personal Email", val: "piyushpattnaik3@gmail.com" },
    { icon: Phone, label: "WhatsApp Secure Chat (No Calls)", val: "+91 7653905357" },
    { icon: MapPin, label: "SecOps Operations HQ", val: "Remote Location (Work From Home), India" }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-16 text-left">
      <div className="text-center space-y-4">
        <h1 className="font-display font-bold text-3xl md:text-5xl text-white">
          Establish <span className="text-cyan-400">Communication</span>
        </h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto leading-relaxed">
          Contact our operations group for billing inquiries, institutional access, or support questions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 max-w-5xl mx-auto">
        
        {/* Contact info column */}
        <div className="lg:col-span-5 flex flex-col space-y-6">
          <div className="glass-panel p-6 rounded-2xl flex flex-col space-y-6">
            <h3 className="font-display font-bold text-lg text-white">Operations Channels</h3>
            
            {contactOptions.map((opt, idx) => (
              <div key={idx} className="flex items-start space-x-3.5">
                <div className="p-2.5 bg-cyan-950/40 border border-cyan-500/20 rounded-lg shrink-0">
                  <opt.icon className="w-5 h-5 text-cyan-400" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-mono text-slate-500 uppercase">{opt.label}</span>
                  <span className="text-sm text-slate-200 mt-0.5">{opt.val}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="glass-panel border-rose-500/10 p-5 rounded-2xl bg-rose-950/10 text-left">
            <h4 className="font-display font-bold text-xs text-rose-300 uppercase tracking-widest flex items-center space-x-1.5 mb-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Response Protocol SLA</span>
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              All platform ticketing communications are triaged and resolved by active on-duty instructors within 12-24 hours. UTR/Payment screenshot validations take priority (typically 1-2 hours).
            </p>
          </div>
        </div>

        {/* Contact Form column */}
        <div className="lg:col-span-7">
          <div className="glass-panel p-8 rounded-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-1 bg-cyan-400"></div>
            
            {submitted ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-12 h-12 bg-cyan-950/50 border border-cyan-400 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6 text-cyan-400" />
                </div>
                <h3 className="font-display font-bold text-lg text-white">Transmission Received</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  Your communication has been cryptographically signed and routed to our support queues. Expect response shortly on <span className="text-cyan-400 font-semibold">{formData.email}</span>.
                </p>
                <button
                  onClick={() => { setSubmitted(false); setFormData({ name: "", email: "", category: "Support", message: "" }); }}
                  className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-300 text-xs font-semibold rounded hover:border-cyan-500/20"
                >
                  New Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="font-display font-bold text-lg text-white">Secure Contact Form</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Your Name</label>
                    <input 
                      type="text" 
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Alex Mercer"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 uppercase">Your Email</label>
                    <input 
                      type="email" 
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. alex@mercer.cy"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400 uppercase">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                  >
                    <option value="Support">Standard Platform Support</option>
                    <option value="Billing">Manual Payment Billing</option>
                    <option value="Enterprise">Academic / Corporate Bundle</option>
                    <option value="Vulnerability">Lab / Cyber Feedback</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-400 uppercase">Message Content</label>
                  <textarea
                    rows={4}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Describe your issue or custom request..."
                    className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500/50 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-sans font-bold text-xs rounded-lg shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Transmit Form Data</span>
                </button>
              </form>
            )}

          </div>
        </div>

      </div>
    </div>
  );
}

// ==========================================
// 5. FAQ PAGE
// ==========================================
export function FAQPage() {
  const faqs = [
    {
      q: "How does the manual UPI transaction system work?",
      a: "Since we do not run automated merchant keys in sandbox environments, we employ a secured manual validation. You select a track, copy our official UPI code and Scan QR, execute the payment in your preferred app (GPay/PhonePe), type in your 12-digit UTR reference ID, upload a screenshot, and submit. Our support administrators verify the ledger log and unlock your track instantly."
    },
    {
      q: "Are these certificates verified and shareable?",
      a: "Yes! Every graduate earns an official Digital Certificate with a unique cryptographic verification ID (e.g., PWC-2026-8842) and a scannable QR verification link. Employers can check certificate IDs directly on our verified certificate portal page to confirm security achievements."
    },
    {
      q: "Do I get real server shells inside the labs?",
      a: "Our virtual practical labs run safe, detailed terminal simulators and instructions. They simulate real cyber tools like Nmap, Wireshark, Metasploit, or Burp Suite. You execute active scans, parameter tamperings, or binary reversing right in the browser, capture correct hex keys/flags, and submit them for automated grading."
    },
    {
      q: "Is there a refund policy?",
      a: "Due to the digital nature of our hands-on sandboxes, curriculum materials, downloadables, and instant access allocation, we have a strict no-refund policy. All sales are final. Please review the track curriculum and preview details before making any payment."
    }
  ];

  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-16 text-left">
      <div className="text-center space-y-4">
        <h1 className="font-display font-bold text-3xl md:text-5xl text-white">
          Frequently Answered <span className="text-cyan-400">Queries</span>
        </h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto leading-relaxed">
          Solve standard questions regarding manual ledgers, verification certificates, lab configurations, and billing regulations.
        </p>
      </div>

      <div className="max-w-3xl mx-auto space-y-4">
        {faqs.map((faq, idx) => {
          const isOpen = openIdx === idx;
          return (
            <div key={idx} className="glass-panel rounded-xl overflow-hidden border border-slate-800 hover:border-cyan-500/20 transition-colors">
              <button
                onClick={() => setOpenIdx(isOpen ? null : idx)}
                className="w-full flex items-center justify-between p-5 text-left font-display font-semibold text-slate-200 hover:text-white transition-colors cursor-pointer"
              >
                <span>{faq.q}</span>
                {isOpen ? <ChevronUp className="w-4 h-4 text-cyan-400 shrink-0 ml-4" /> : <ChevronDown className="w-4 h-4 text-cyan-400 shrink-0 ml-4" />}
              </button>
              
              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs text-slate-400 font-sans leading-relaxed border-t border-slate-900 bg-slate-950/20">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ==========================================
// 6. LEGAL AGREEMENT PAGES
// ==========================================
export function LegalPages() {
  const [activeTab, setActiveTab] = useState("disclaimer");

  const sections = [
    {
      id: "disclaimer",
      title: "Platform Disclaimer",
      content: `PatchWire Cyber provides specialized high-stress cybersecurity practical labs for strictly educational, credentialing, and authorized testing purposes only.

Users must absolutely NEVER launch scanning, sniffing, exploits, or brute-force programs against third-party network ranges, corporate assets, or individual servers without authenticated, written, pre-signed authorization from the ultimate asset holders.

Any unauthorized compromise represents a direct violation of international cyber legislations (including the US Computer Fraud and Abuse Act (CFAA), the UK Computer Misuse Act 1990, and Section 43/66 of the Indian Information Technology Act, 2000). PatchWire Cyber disclaims all liability for civil damages, statutory fines, or criminal prosecutions arising from student actions outside our sandboxed domains.`
    },
    {
      id: "privacy",
      title: "Privacy Policy",
      content: `We collect minimal, cryptographically secure account data (email, name, UPI screenshot uploads, transaction hashes, course completion dates) required to deliver dynamic certificates and platform authentication.

We never share or broker user rosters, quiz grades, or manual payment records with external ad networks. Screenshot assets are purged from manual memory systems upon status verification. Transaction hashes are stored purely for accounting compliance.`
    },
    {
      id: "terms",
      title: "Terms & Conditions",
      content: `1. Account Use: One registration represents one secure seat. Shared account tokens or logging access credentials results in systematic lockouts without refund.
2. Lab Rules: Attempting to leak backend server codes, disrupt virtual lab container routines, or exploit platform infrastructure represents an instant ban from community and training pathways.
3. Graduations: Verified certificates are only awarded upon absolute 100% completion of course syllabus nodes, labs, and graded quizzes.`
    },
    {
      id: "refund",
      title: "Refund Policy",
      content: `All purchases are final and absolutely non-refundable.

Due to the instant accessibility of our virtual laboratory environments, sandboxed terminal simulators, downloadable certification modules, and verified academic credentials, PatchWire Cyber enforces a strict NO-REFUND policy. Once a course track is purchased or accessed, no chargebacks, manual reversals, or UPI refunds can be processed under any circumstances. We encourage students to fully examine track specifications and try free preview modules prior to transaction execution.`
    },
    {
      id: "acceptable",
      title: "Acceptable Use Policy",
      content: `Students are expected to maintain collegiate, collaborative, and professional ethics across our Community channels (#general-discussion, #lab-help, etc.).

Strictly Forbidden:
- Sharing actual solutions (or flags) of active labs (use guiding hints instead!).
- Posting cracked binaries or commercial malicious files inside chat blocks.
- Engaging in harassing, offensive, or derogatory communication.`
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-12 text-left">
      <div className="text-center space-y-4">
        <h1 className="font-display font-bold text-3xl md:text-5xl text-white">
          Legal <span className="text-cyan-400">Documentation</span>
        </h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto leading-relaxed">
          Review our legal codes, user-conduct guidelines, privacy disclosures, and ethical compliance standards.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 max-w-5xl mx-auto">
        {/* Sidebar Tabs */}
        <div className="md:col-span-4 flex flex-col space-y-1">
          {sections.map((sec) => (
            <button
              key={sec.id}
              onClick={() => setActiveTab(sec.id)}
              className={`w-full text-left px-4 py-3 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                activeTab === sec.id 
                  ? "bg-cyan-950/50 text-cyan-400 border border-cyan-500/30 font-bold" 
                  : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              {sec.title}
            </button>
          ))}
        </div>

        {/* Content Box */}
        <div className="md:col-span-8 glass-panel p-8 rounded-2xl relative overflow-hidden bg-slate-950/20">
          <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500"></div>
          {sections.map((sec) => {
            if (sec.id !== activeTab) return null;
            return (
              <div key={sec.id} className="space-y-6">
                <h2 className="font-display font-bold text-xl text-white">{sec.title}</h2>
                <div className="text-xs text-slate-300 font-sans leading-relaxed whitespace-pre-line space-y-4">
                  {sec.content}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
