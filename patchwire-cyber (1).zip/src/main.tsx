import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import ErrorBoundary from './components/ErrorBoundary.tsx';
import './index.css';

// Ensure the body has the proper base styling instantly to prevent FOUC / flicker
if (typeof document !== 'undefined') {
  document.body.className = "bg-slate-950 text-slate-300";
}

// Verify that the 'root' div exists in the DOM at the time of mounting.
// If not found, dynamically initialize it to guarantee a proper mount anchor.
let rootElement = document.getElementById('root');
if (!rootElement) {
  console.warn("Target container 'root' was not found in DOM during mounting phase. Generating dynamically.");
  rootElement = document.createElement('div');
  rootElement.id = 'root';
  document.body.appendChild(rootElement);
}

createRoot(rootElement).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);

